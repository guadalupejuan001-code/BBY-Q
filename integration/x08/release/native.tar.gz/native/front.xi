#!reverse-pc-machine-v1
load8 r0 9110000000000000000
cmp r0 87
jne refuse
load8 r0 9110000000000000001
cmp r0 2
jne refuse
load8 r0 9110000000000000002
load8 r1 9110000000000000003
mul r1 256
add r0 r1
cmp r0 4096
jgt refuse
set r7 9110000000004000000
set r0 8192
label scratch
load8 r3 $r7
cmp r3 0
jne refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne refuse
add r7 1
sub r0 16
cmp r0 0
jgt scratch
jmp x08_entry
label refuse
set r0 0
mod r0 0

label x08_entry
load8 r0 9120000000000000000
cmp r0 88
jne x8_corrupt
load8 r0 9120000000000000001
cmp r0 1
jne x8_corrupt
store8 9120000000000000002 1
jmp x6_text_v2
label x6_routes
store8 8200000000000000064 0
store8 8200000000000000065 0
store8 8200000000000000067 0
load8 r0 8300000000000000016
cmp r0 2
jne x6_cancel_old_code
store8 8300000000000000016 4
label x6_cancel_old_code
load8 r0 9090000000000000002
cmp r0 2
jne x6_match_routes
store8 9090000000000000002 1

label x6_match_routes
jmp x8_routes
label x8_routes
load8 r0 9120000000000000000
cmp r0 88
jne x7_routes
load8 r9 9100000000000100018
load8 r14 9100000000000100019
mul r14 256
add r9 r14
mov r14 r9
mod r14 256
store8 9120000000000100018 r14
mov r14 r9
div r14 256
mod r14 256
store8 9120000000000100019 r14
set r0 0
mov r14 r0
mod r14 256
store8 9120000000000100016 r14
mov r14 r0
div r14 256
mod r14 256
store8 9120000000000100017 r14
store8 9120000000000100100 0
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 40
cmp r6 r9
jgt x8_miss_1
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 101
je x8_case_2
cmp r3 69
jne x8_miss_1
label x8_case_2
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 115
je x8_case_3
cmp r3 83
jne x8_miss_1
label x8_case_3
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 99
je x8_case_4
cmp r3 67
jne x8_miss_1
label x8_case_4
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 114
je x8_case_5
cmp r3 82
jne x8_miss_1
label x8_case_5
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 105
je x8_case_6
cmp r3 73
jne x8_miss_1
label x8_case_6
mov r7 r8
add r7 r4
add r7 5
load8 r3 $r7
cmp r3 98
je x8_case_7
cmp r3 66
jne x8_miss_1
label x8_case_7
mov r7 r8
add r7 r4
add r7 6
load8 r3 $r7
cmp r3 101
je x8_case_8
cmp r3 69
jne x8_miss_1
label x8_case_8
mov r7 r8
add r7 r4
add r7 7
load8 r3 $r7
cmp r3 32
jne x8_miss_1
mov r7 r8
add r7 r4
add r7 8
load8 r3 $r7
cmp r3 121
je x8_case_9
cmp r3 89
jne x8_miss_1
label x8_case_9
mov r7 r8
add r7 r4
add r7 9
load8 r3 $r7
cmp r3 32
jne x8_miss_1
mov r7 r8
add r7 r4
add r7 10
load8 r3 $r7
cmp r3 101
je x8_case_10
cmp r3 69
jne x8_miss_1
label x8_case_10
mov r7 r8
add r7 r4
add r7 11
load8 r3 $r7
cmp r3 106
je x8_case_11
cmp r3 74
jne x8_miss_1
label x8_case_11
mov r7 r8
add r7 r4
add r7 12
load8 r3 $r7
cmp r3 101
je x8_case_12
cmp r3 69
jne x8_miss_1
label x8_case_12
mov r7 r8
add r7 r4
add r7 13
load8 r3 $r7
cmp r3 99
je x8_case_13
cmp r3 67
jne x8_miss_1
label x8_case_13
mov r7 r8
add r7 r4
add r7 14
load8 r3 $r7
cmp r3 117
je x8_case_14
cmp r3 85
jne x8_miss_1
label x8_case_14
mov r7 r8
add r7 r4
add r7 15
load8 r3 $r7
cmp r3 116
je x8_case_15
cmp r3 84
jne x8_miss_1
label x8_case_15
mov r7 r8
add r7 r4
add r7 16
load8 r3 $r7
cmp r3 97
je x8_case_16
cmp r3 65
jne x8_miss_1
label x8_case_16
mov r7 r8
add r7 r4
add r7 17
load8 r3 $r7
cmp r3 32
jne x8_miss_1
mov r7 r8
add r7 r4
add r7 18
load8 r3 $r7
cmp r3 101
je x8_case_17
cmp r3 69
jne x8_miss_1
label x8_case_17
mov r7 r8
add r7 r4
add r7 19
load8 r3 $r7
cmp r3 110
je x8_case_18
cmp r3 78
jne x8_miss_1
label x8_case_18
mov r7 r8
add r7 r4
add r7 20
load8 r3 $r7
cmp r3 32
jne x8_miss_1
mov r7 r8
add r7 r4
add r7 21
load8 r3 $r7
cmp r3 120
je x8_case_19
cmp r3 88
jne x8_miss_1
label x8_case_19
mov r7 r8
add r7 r4
add r7 22
load8 r3 $r7
cmp r3 105
je x8_case_20
cmp r3 73
jne x8_miss_1
label x8_case_20
mov r7 r8
add r7 r4
add r7 23
load8 r3 $r7
cmp r3 32
jne x8_miss_1
mov r7 r8
add r7 r4
add r7 24
load8 r3 $r7
cmp r3 117
je x8_case_21
cmp r3 85
jne x8_miss_1
label x8_case_21
mov r7 r8
add r7 r4
add r7 25
load8 r3 $r7
cmp r3 110
je x8_case_22
cmp r3 78
jne x8_miss_1
label x8_case_22
mov r7 r8
add r7 r4
add r7 26
load8 r3 $r7
cmp r3 32
jne x8_miss_1
mov r7 r8
add r7 r4
add r7 27
load8 r3 $r7
cmp r3 112
je x8_case_23
cmp r3 80
jne x8_miss_1
label x8_case_23
mov r7 r8
add r7 r4
add r7 28
load8 r3 $r7
cmp r3 114
je x8_case_24
cmp r3 82
jne x8_miss_1
label x8_case_24
mov r7 r8
add r7 r4
add r7 29
load8 r3 $r7
cmp r3 111
je x8_case_25
cmp r3 79
jne x8_miss_1
label x8_case_25
mov r7 r8
add r7 r4
add r7 30
load8 r3 $r7
cmp r3 103
je x8_case_26
cmp r3 71
jne x8_miss_1
label x8_case_26
mov r7 r8
add r7 r4
add r7 31
load8 r3 $r7
cmp r3 114
je x8_case_27
cmp r3 82
jne x8_miss_1
label x8_case_27
mov r7 r8
add r7 r4
add r7 32
load8 r3 $r7
cmp r3 97
je x8_case_28
cmp r3 65
jne x8_miss_1
label x8_case_28
mov r7 r8
add r7 r4
add r7 33
load8 r3 $r7
cmp r3 109
je x8_case_29
cmp r3 77
jne x8_miss_1
label x8_case_29
mov r7 r8
add r7 r4
add r7 34
load8 r3 $r7
cmp r3 97
je x8_case_30
cmp r3 65
jne x8_miss_1
label x8_case_30
mov r7 r8
add r7 r4
add r7 35
load8 r3 $r7
cmp r3 32
jne x8_miss_1
mov r7 r8
add r7 r4
add r7 36
load8 r3 $r7
cmp r3 113
je x8_case_31
cmp r3 81
jne x8_miss_1
label x8_case_31
mov r7 r8
add r7 r4
add r7 37
load8 r3 $r7
cmp r3 117
je x8_case_32
cmp r3 85
jne x8_miss_1
label x8_case_32
mov r7 r8
add r7 r4
add r7 38
load8 r3 $r7
cmp r3 101
je x8_case_33
cmp r3 69
jne x8_miss_1
label x8_case_33
mov r7 r8
add r7 r4
add r7 39
load8 r3 $r7
cmp r3 32
jne x8_miss_1
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_code_normalize
label x8_miss_1
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 39
cmp r6 r9
jgt x8_miss_34
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 103
je x8_case_35
cmp r3 71
jne x8_miss_34
label x8_case_35
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 101
je x8_case_36
cmp r3 69
jne x8_miss_34
label x8_case_36
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 110
je x8_case_37
cmp r3 78
jne x8_miss_34
label x8_case_37
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 101
je x8_case_38
cmp r3 69
jne x8_miss_34
label x8_case_38
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 114
je x8_case_39
cmp r3 82
jne x8_miss_34
label x8_case_39
mov r7 r8
add r7 r4
add r7 5
load8 r3 $r7
cmp r3 97
je x8_case_40
cmp r3 65
jne x8_miss_34
label x8_case_40
mov r7 r8
add r7 r4
add r7 6
load8 r3 $r7
cmp r3 32
jne x8_miss_34
mov r7 r8
add r7 r4
add r7 7
load8 r3 $r7
cmp r3 121
je x8_case_41
cmp r3 89
jne x8_miss_34
label x8_case_41
mov r7 r8
add r7 r4
add r7 8
load8 r3 $r7
cmp r3 32
jne x8_miss_34
mov r7 r8
add r7 r4
add r7 9
load8 r3 $r7
cmp r3 101
je x8_case_42
cmp r3 69
jne x8_miss_34
label x8_case_42
mov r7 r8
add r7 r4
add r7 10
load8 r3 $r7
cmp r3 106
je x8_case_43
cmp r3 74
jne x8_miss_34
label x8_case_43
mov r7 r8
add r7 r4
add r7 11
load8 r3 $r7
cmp r3 101
je x8_case_44
cmp r3 69
jne x8_miss_34
label x8_case_44
mov r7 r8
add r7 r4
add r7 12
load8 r3 $r7
cmp r3 99
je x8_case_45
cmp r3 67
jne x8_miss_34
label x8_case_45
mov r7 r8
add r7 r4
add r7 13
load8 r3 $r7
cmp r3 117
je x8_case_46
cmp r3 85
jne x8_miss_34
label x8_case_46
mov r7 r8
add r7 r4
add r7 14
load8 r3 $r7
cmp r3 116
je x8_case_47
cmp r3 84
jne x8_miss_34
label x8_case_47
mov r7 r8
add r7 r4
add r7 15
load8 r3 $r7
cmp r3 97
je x8_case_48
cmp r3 65
jne x8_miss_34
label x8_case_48
mov r7 r8
add r7 r4
add r7 16
load8 r3 $r7
cmp r3 32
jne x8_miss_34
mov r7 r8
add r7 r4
add r7 17
load8 r3 $r7
cmp r3 101
je x8_case_49
cmp r3 69
jne x8_miss_34
label x8_case_49
mov r7 r8
add r7 r4
add r7 18
load8 r3 $r7
cmp r3 110
je x8_case_50
cmp r3 78
jne x8_miss_34
label x8_case_50
mov r7 r8
add r7 r4
add r7 19
load8 r3 $r7
cmp r3 32
jne x8_miss_34
mov r7 r8
add r7 r4
add r7 20
load8 r3 $r7
cmp r3 120
je x8_case_51
cmp r3 88
jne x8_miss_34
label x8_case_51
mov r7 r8
add r7 r4
add r7 21
load8 r3 $r7
cmp r3 105
je x8_case_52
cmp r3 73
jne x8_miss_34
label x8_case_52
mov r7 r8
add r7 r4
add r7 22
load8 r3 $r7
cmp r3 32
jne x8_miss_34
mov r7 r8
add r7 r4
add r7 23
load8 r3 $r7
cmp r3 117
je x8_case_53
cmp r3 85
jne x8_miss_34
label x8_case_53
mov r7 r8
add r7 r4
add r7 24
load8 r3 $r7
cmp r3 110
je x8_case_54
cmp r3 78
jne x8_miss_34
label x8_case_54
mov r7 r8
add r7 r4
add r7 25
load8 r3 $r7
cmp r3 32
jne x8_miss_34
mov r7 r8
add r7 r4
add r7 26
load8 r3 $r7
cmp r3 112
je x8_case_55
cmp r3 80
jne x8_miss_34
label x8_case_55
mov r7 r8
add r7 r4
add r7 27
load8 r3 $r7
cmp r3 114
je x8_case_56
cmp r3 82
jne x8_miss_34
label x8_case_56
mov r7 r8
add r7 r4
add r7 28
load8 r3 $r7
cmp r3 111
je x8_case_57
cmp r3 79
jne x8_miss_34
label x8_case_57
mov r7 r8
add r7 r4
add r7 29
load8 r3 $r7
cmp r3 103
je x8_case_58
cmp r3 71
jne x8_miss_34
label x8_case_58
mov r7 r8
add r7 r4
add r7 30
load8 r3 $r7
cmp r3 114
je x8_case_59
cmp r3 82
jne x8_miss_34
label x8_case_59
mov r7 r8
add r7 r4
add r7 31
load8 r3 $r7
cmp r3 97
je x8_case_60
cmp r3 65
jne x8_miss_34
label x8_case_60
mov r7 r8
add r7 r4
add r7 32
load8 r3 $r7
cmp r3 109
je x8_case_61
cmp r3 77
jne x8_miss_34
label x8_case_61
mov r7 r8
add r7 r4
add r7 33
load8 r3 $r7
cmp r3 97
je x8_case_62
cmp r3 65
jne x8_miss_34
label x8_case_62
mov r7 r8
add r7 r4
add r7 34
load8 r3 $r7
cmp r3 32
jne x8_miss_34
mov r7 r8
add r7 r4
add r7 35
load8 r3 $r7
cmp r3 113
je x8_case_63
cmp r3 81
jne x8_miss_34
label x8_case_63
mov r7 r8
add r7 r4
add r7 36
load8 r3 $r7
cmp r3 117
je x8_case_64
cmp r3 85
jne x8_miss_34
label x8_case_64
mov r7 r8
add r7 r4
add r7 37
load8 r3 $r7
cmp r3 101
je x8_case_65
cmp r3 69
jne x8_miss_34
label x8_case_65
mov r7 r8
add r7 r4
add r7 38
load8 r3 $r7
cmp r3 32
jne x8_miss_34
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_code_normalize
label x8_miss_34
jmp x8_route_0
label x8_route_0
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 20
cmp r6 r9
jgt x8_miss_67
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 116
je x8_case_68
cmp r3 84
jne x8_miss_67
label x8_case_68
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 114
je x8_case_69
cmp r3 82
jne x8_miss_67
label x8_case_69
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 97
je x8_case_70
cmp r3 65
jne x8_miss_67
label x8_case_70
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 100
je x8_case_71
cmp r3 68
jne x8_miss_67
label x8_case_71
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 117
je x8_case_72
cmp r3 85
jne x8_miss_67
label x8_case_72
mov r7 r8
add r7 r4
add r7 5
load8 r3 $r7
cmp r3 99
je x8_case_73
cmp r3 67
jne x8_miss_67
label x8_case_73
mov r7 r8
add r7 r4
add r7 6
load8 r3 $r7
cmp r3 101
je x8_case_74
cmp r3 69
jne x8_miss_67
label x8_case_74
mov r7 r8
add r7 r4
add r7 7
load8 r3 $r7
cmp r3 32
jne x8_miss_67
mov r7 r8
add r7 r4
add r7 8
load8 r3 $r7
cmp r3 97
je x8_case_75
cmp r3 65
jne x8_miss_67
label x8_case_75
mov r7 r8
add r7 r4
add r7 9
load8 r3 $r7
cmp r3 108
je x8_case_76
cmp r3 76
jne x8_miss_67
label x8_case_76
mov r7 r8
add r7 r4
add r7 10
load8 r3 $r7
cmp r3 32
jne x8_miss_67
mov r7 r8
add r7 r4
add r7 11
load8 r3 $r7
cmp r3 105
je x8_case_77
cmp r3 73
jne x8_miss_67
label x8_case_77
mov r7 r8
add r7 r4
add r7 12
load8 r3 $r7
cmp r3 110
je x8_case_78
cmp r3 78
jne x8_miss_67
label x8_case_78
mov r7 r8
add r7 r4
add r7 13
load8 r3 $r7
cmp r3 103
je x8_case_79
cmp r3 71
jne x8_miss_67
label x8_case_79
mov r7 r8
add r7 r4
add r7 14
load8 r3 $r7
cmp r3 108
je x8_case_80
cmp r3 76
jne x8_miss_67
label x8_case_80
mov r7 r8
add r7 r4
add r7 15
load8 r3 $r7
cmp r3 195
jne x8_miss_67
mov r7 r8
add r7 r4
add r7 16
load8 r3 $r7
cmp r3 169
je x8_case_81
cmp r3 137
jne x8_miss_67
label x8_case_81
mov r7 r8
add r7 r4
add r7 17
load8 r3 $r7
cmp r3 115
je x8_case_82
cmp r3 83
jne x8_miss_67
label x8_case_82
mov r7 r8
add r7 r4
add r7 18
load8 r3 $r7
cmp r3 58
jne x8_miss_67
mov r7 r8
add r7 r4
add r7 19
load8 r3 $r7
cmp r3 32
jne x8_miss_67
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_to_en
label x8_miss_67
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 19
cmp r6 r9
jgt x8_miss_83
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 116
je x8_case_84
cmp r3 84
jne x8_miss_83
label x8_case_84
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 114
je x8_case_85
cmp r3 82
jne x8_miss_83
label x8_case_85
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 97
je x8_case_86
cmp r3 65
jne x8_miss_83
label x8_case_86
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 100
je x8_case_87
cmp r3 68
jne x8_miss_83
label x8_case_87
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 117
je x8_case_88
cmp r3 85
jne x8_miss_83
label x8_case_88
mov r7 r8
add r7 r4
add r7 5
load8 r3 $r7
cmp r3 99
je x8_case_89
cmp r3 67
jne x8_miss_83
label x8_case_89
mov r7 r8
add r7 r4
add r7 6
load8 r3 $r7
cmp r3 101
je x8_case_90
cmp r3 69
jne x8_miss_83
label x8_case_90
mov r7 r8
add r7 r4
add r7 7
load8 r3 $r7
cmp r3 32
jne x8_miss_83
mov r7 r8
add r7 r4
add r7 8
load8 r3 $r7
cmp r3 97
je x8_case_91
cmp r3 65
jne x8_miss_83
label x8_case_91
mov r7 r8
add r7 r4
add r7 9
load8 r3 $r7
cmp r3 108
je x8_case_92
cmp r3 76
jne x8_miss_83
label x8_case_92
mov r7 r8
add r7 r4
add r7 10
load8 r3 $r7
cmp r3 32
jne x8_miss_83
mov r7 r8
add r7 r4
add r7 11
load8 r3 $r7
cmp r3 105
je x8_case_93
cmp r3 73
jne x8_miss_83
label x8_case_93
mov r7 r8
add r7 r4
add r7 12
load8 r3 $r7
cmp r3 110
je x8_case_94
cmp r3 78
jne x8_miss_83
label x8_case_94
mov r7 r8
add r7 r4
add r7 13
load8 r3 $r7
cmp r3 103
je x8_case_95
cmp r3 71
jne x8_miss_83
label x8_case_95
mov r7 r8
add r7 r4
add r7 14
load8 r3 $r7
cmp r3 108
je x8_case_96
cmp r3 76
jne x8_miss_83
label x8_case_96
mov r7 r8
add r7 r4
add r7 15
load8 r3 $r7
cmp r3 101
je x8_case_97
cmp r3 69
jne x8_miss_83
label x8_case_97
mov r7 r8
add r7 r4
add r7 16
load8 r3 $r7
cmp r3 115
je x8_case_98
cmp r3 83
jne x8_miss_83
label x8_case_98
mov r7 r8
add r7 r4
add r7 17
load8 r3 $r7
cmp r3 58
jne x8_miss_83
mov r7 r8
add r7 r4
add r7 18
load8 r3 $r7
cmp r3 32
jne x8_miss_83
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_to_en
label x8_miss_83
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 22
cmp r6 r9
jgt x8_miss_99
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 116
je x8_case_100
cmp r3 84
jne x8_miss_99
label x8_case_100
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 114
je x8_case_101
cmp r3 82
jne x8_miss_99
label x8_case_101
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 97
je x8_case_102
cmp r3 65
jne x8_miss_99
label x8_case_102
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 110
je x8_case_103
cmp r3 78
jne x8_miss_99
label x8_case_103
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 115
je x8_case_104
cmp r3 83
jne x8_miss_99
label x8_case_104
mov r7 r8
add r7 r4
add r7 5
load8 r3 $r7
cmp r3 108
je x8_case_105
cmp r3 76
jne x8_miss_99
label x8_case_105
mov r7 r8
add r7 r4
add r7 6
load8 r3 $r7
cmp r3 97
je x8_case_106
cmp r3 65
jne x8_miss_99
label x8_case_106
mov r7 r8
add r7 r4
add r7 7
load8 r3 $r7
cmp r3 116
je x8_case_107
cmp r3 84
jne x8_miss_99
label x8_case_107
mov r7 r8
add r7 r4
add r7 8
load8 r3 $r7
cmp r3 101
je x8_case_108
cmp r3 69
jne x8_miss_99
label x8_case_108
mov r7 r8
add r7 r4
add r7 9
load8 r3 $r7
cmp r3 32
jne x8_miss_99
mov r7 r8
add r7 r4
add r7 10
load8 r3 $r7
cmp r3 116
je x8_case_109
cmp r3 84
jne x8_miss_99
label x8_case_109
mov r7 r8
add r7 r4
add r7 11
load8 r3 $r7
cmp r3 111
je x8_case_110
cmp r3 79
jne x8_miss_99
label x8_case_110
mov r7 r8
add r7 r4
add r7 12
load8 r3 $r7
cmp r3 32
jne x8_miss_99
mov r7 r8
add r7 r4
add r7 13
load8 r3 $r7
cmp r3 101
je x8_case_111
cmp r3 69
jne x8_miss_99
label x8_case_111
mov r7 r8
add r7 r4
add r7 14
load8 r3 $r7
cmp r3 110
je x8_case_112
cmp r3 78
jne x8_miss_99
label x8_case_112
mov r7 r8
add r7 r4
add r7 15
load8 r3 $r7
cmp r3 103
je x8_case_113
cmp r3 71
jne x8_miss_99
label x8_case_113
mov r7 r8
add r7 r4
add r7 16
load8 r3 $r7
cmp r3 108
je x8_case_114
cmp r3 76
jne x8_miss_99
label x8_case_114
mov r7 r8
add r7 r4
add r7 17
load8 r3 $r7
cmp r3 105
je x8_case_115
cmp r3 73
jne x8_miss_99
label x8_case_115
mov r7 r8
add r7 r4
add r7 18
load8 r3 $r7
cmp r3 115
je x8_case_116
cmp r3 83
jne x8_miss_99
label x8_case_116
mov r7 r8
add r7 r4
add r7 19
load8 r3 $r7
cmp r3 104
je x8_case_117
cmp r3 72
jne x8_miss_99
label x8_case_117
mov r7 r8
add r7 r4
add r7 20
load8 r3 $r7
cmp r3 58
jne x8_miss_99
mov r7 r8
add r7 r4
add r7 21
load8 r3 $r7
cmp r3 32
jne x8_miss_99
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_to_en
label x8_miss_99
jmp x8_route_66
label x8_route_66
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 21
cmp r6 r9
jgt x8_miss_119
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 116
je x8_case_120
cmp r3 84
jne x8_miss_119
label x8_case_120
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 114
je x8_case_121
cmp r3 82
jne x8_miss_119
label x8_case_121
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 97
je x8_case_122
cmp r3 65
jne x8_miss_119
label x8_case_122
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 100
je x8_case_123
cmp r3 68
jne x8_miss_119
label x8_case_123
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 117
je x8_case_124
cmp r3 85
jne x8_miss_119
label x8_case_124
mov r7 r8
add r7 r4
add r7 5
load8 r3 $r7
cmp r3 99
je x8_case_125
cmp r3 67
jne x8_miss_119
label x8_case_125
mov r7 r8
add r7 r4
add r7 6
load8 r3 $r7
cmp r3 101
je x8_case_126
cmp r3 69
jne x8_miss_119
label x8_case_126
mov r7 r8
add r7 r4
add r7 7
load8 r3 $r7
cmp r3 32
jne x8_miss_119
mov r7 r8
add r7 r4
add r7 8
load8 r3 $r7
cmp r3 97
je x8_case_127
cmp r3 65
jne x8_miss_119
label x8_case_127
mov r7 r8
add r7 r4
add r7 9
load8 r3 $r7
cmp r3 108
je x8_case_128
cmp r3 76
jne x8_miss_119
label x8_case_128
mov r7 r8
add r7 r4
add r7 10
load8 r3 $r7
cmp r3 32
jne x8_miss_119
mov r7 r8
add r7 r4
add r7 11
load8 r3 $r7
cmp r3 101
je x8_case_129
cmp r3 69
jne x8_miss_119
label x8_case_129
mov r7 r8
add r7 r4
add r7 12
load8 r3 $r7
cmp r3 115
je x8_case_130
cmp r3 83
jne x8_miss_119
label x8_case_130
mov r7 r8
add r7 r4
add r7 13
load8 r3 $r7
cmp r3 112
je x8_case_131
cmp r3 80
jne x8_miss_119
label x8_case_131
mov r7 r8
add r7 r4
add r7 14
load8 r3 $r7
cmp r3 97
je x8_case_132
cmp r3 65
jne x8_miss_119
label x8_case_132
mov r7 r8
add r7 r4
add r7 15
load8 r3 $r7
cmp r3 195
jne x8_miss_119
mov r7 r8
add r7 r4
add r7 16
load8 r3 $r7
cmp r3 177
je x8_case_133
cmp r3 145
jne x8_miss_119
label x8_case_133
mov r7 r8
add r7 r4
add r7 17
load8 r3 $r7
cmp r3 111
je x8_case_134
cmp r3 79
jne x8_miss_119
label x8_case_134
mov r7 r8
add r7 r4
add r7 18
load8 r3 $r7
cmp r3 108
je x8_case_135
cmp r3 76
jne x8_miss_119
label x8_case_135
mov r7 r8
add r7 r4
add r7 19
load8 r3 $r7
cmp r3 58
jne x8_miss_119
mov r7 r8
add r7 r4
add r7 20
load8 r3 $r7
cmp r3 32
jne x8_miss_119
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_to_es
label x8_miss_119
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 20
cmp r6 r9
jgt x8_miss_136
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 116
je x8_case_137
cmp r3 84
jne x8_miss_136
label x8_case_137
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 114
je x8_case_138
cmp r3 82
jne x8_miss_136
label x8_case_138
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 97
je x8_case_139
cmp r3 65
jne x8_miss_136
label x8_case_139
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 100
je x8_case_140
cmp r3 68
jne x8_miss_136
label x8_case_140
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 117
je x8_case_141
cmp r3 85
jne x8_miss_136
label x8_case_141
mov r7 r8
add r7 r4
add r7 5
load8 r3 $r7
cmp r3 99
je x8_case_142
cmp r3 67
jne x8_miss_136
label x8_case_142
mov r7 r8
add r7 r4
add r7 6
load8 r3 $r7
cmp r3 101
je x8_case_143
cmp r3 69
jne x8_miss_136
label x8_case_143
mov r7 r8
add r7 r4
add r7 7
load8 r3 $r7
cmp r3 32
jne x8_miss_136
mov r7 r8
add r7 r4
add r7 8
load8 r3 $r7
cmp r3 97
je x8_case_144
cmp r3 65
jne x8_miss_136
label x8_case_144
mov r7 r8
add r7 r4
add r7 9
load8 r3 $r7
cmp r3 108
je x8_case_145
cmp r3 76
jne x8_miss_136
label x8_case_145
mov r7 r8
add r7 r4
add r7 10
load8 r3 $r7
cmp r3 32
jne x8_miss_136
mov r7 r8
add r7 r4
add r7 11
load8 r3 $r7
cmp r3 101
je x8_case_146
cmp r3 69
jne x8_miss_136
label x8_case_146
mov r7 r8
add r7 r4
add r7 12
load8 r3 $r7
cmp r3 115
je x8_case_147
cmp r3 83
jne x8_miss_136
label x8_case_147
mov r7 r8
add r7 r4
add r7 13
load8 r3 $r7
cmp r3 112
je x8_case_148
cmp r3 80
jne x8_miss_136
label x8_case_148
mov r7 r8
add r7 r4
add r7 14
load8 r3 $r7
cmp r3 97
je x8_case_149
cmp r3 65
jne x8_miss_136
label x8_case_149
mov r7 r8
add r7 r4
add r7 15
load8 r3 $r7
cmp r3 110
je x8_case_150
cmp r3 78
jne x8_miss_136
label x8_case_150
mov r7 r8
add r7 r4
add r7 16
load8 r3 $r7
cmp r3 111
je x8_case_151
cmp r3 79
jne x8_miss_136
label x8_case_151
mov r7 r8
add r7 r4
add r7 17
load8 r3 $r7
cmp r3 108
je x8_case_152
cmp r3 76
jne x8_miss_136
label x8_case_152
mov r7 r8
add r7 r4
add r7 18
load8 r3 $r7
cmp r3 58
jne x8_miss_136
mov r7 r8
add r7 r4
add r7 19
load8 r3 $r7
cmp r3 32
jne x8_miss_136
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_to_es
label x8_miss_136
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 22
cmp r6 r9
jgt x8_miss_153
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 116
je x8_case_154
cmp r3 84
jne x8_miss_153
label x8_case_154
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 114
je x8_case_155
cmp r3 82
jne x8_miss_153
label x8_case_155
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 97
je x8_case_156
cmp r3 65
jne x8_miss_153
label x8_case_156
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 110
je x8_case_157
cmp r3 78
jne x8_miss_153
label x8_case_157
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 115
je x8_case_158
cmp r3 83
jne x8_miss_153
label x8_case_158
mov r7 r8
add r7 r4
add r7 5
load8 r3 $r7
cmp r3 108
je x8_case_159
cmp r3 76
jne x8_miss_153
label x8_case_159
mov r7 r8
add r7 r4
add r7 6
load8 r3 $r7
cmp r3 97
je x8_case_160
cmp r3 65
jne x8_miss_153
label x8_case_160
mov r7 r8
add r7 r4
add r7 7
load8 r3 $r7
cmp r3 116
je x8_case_161
cmp r3 84
jne x8_miss_153
label x8_case_161
mov r7 r8
add r7 r4
add r7 8
load8 r3 $r7
cmp r3 101
je x8_case_162
cmp r3 69
jne x8_miss_153
label x8_case_162
mov r7 r8
add r7 r4
add r7 9
load8 r3 $r7
cmp r3 32
jne x8_miss_153
mov r7 r8
add r7 r4
add r7 10
load8 r3 $r7
cmp r3 116
je x8_case_163
cmp r3 84
jne x8_miss_153
label x8_case_163
mov r7 r8
add r7 r4
add r7 11
load8 r3 $r7
cmp r3 111
je x8_case_164
cmp r3 79
jne x8_miss_153
label x8_case_164
mov r7 r8
add r7 r4
add r7 12
load8 r3 $r7
cmp r3 32
jne x8_miss_153
mov r7 r8
add r7 r4
add r7 13
load8 r3 $r7
cmp r3 115
je x8_case_165
cmp r3 83
jne x8_miss_153
label x8_case_165
mov r7 r8
add r7 r4
add r7 14
load8 r3 $r7
cmp r3 112
je x8_case_166
cmp r3 80
jne x8_miss_153
label x8_case_166
mov r7 r8
add r7 r4
add r7 15
load8 r3 $r7
cmp r3 97
je x8_case_167
cmp r3 65
jne x8_miss_153
label x8_case_167
mov r7 r8
add r7 r4
add r7 16
load8 r3 $r7
cmp r3 110
je x8_case_168
cmp r3 78
jne x8_miss_153
label x8_case_168
mov r7 r8
add r7 r4
add r7 17
load8 r3 $r7
cmp r3 105
je x8_case_169
cmp r3 73
jne x8_miss_153
label x8_case_169
mov r7 r8
add r7 r4
add r7 18
load8 r3 $r7
cmp r3 115
je x8_case_170
cmp r3 83
jne x8_miss_153
label x8_case_170
mov r7 r8
add r7 r4
add r7 19
load8 r3 $r7
cmp r3 104
je x8_case_171
cmp r3 72
jne x8_miss_153
label x8_case_171
mov r7 r8
add r7 r4
add r7 20
load8 r3 $r7
cmp r3 58
jne x8_miss_153
mov r7 r8
add r7 r4
add r7 21
load8 r3 $r7
cmp r3 32
jne x8_miss_153
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_to_es
label x8_miss_153
jmp x8_route_118
label x8_route_118
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 20
cmp r6 r9
jgt x8_miss_173
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 99
je x8_case_174
cmp r3 67
jne x8_miss_173
label x8_case_174
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 111
je x8_case_175
cmp r3 79
jne x8_miss_173
label x8_case_175
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 114
je x8_case_176
cmp r3 82
jne x8_miss_173
label x8_case_176
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 114
je x8_case_177
cmp r3 82
jne x8_miss_173
label x8_case_177
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 105
je x8_case_178
cmp r3 73
jne x8_miss_173
label x8_case_178
mov r7 r8
add r7 r4
add r7 5
load8 r3 $r7
cmp r3 103
je x8_case_179
cmp r3 71
jne x8_miss_173
label x8_case_179
mov r7 r8
add r7 r4
add r7 6
load8 r3 $r7
cmp r3 101
je x8_case_180
cmp r3 69
jne x8_miss_173
label x8_case_180
mov r7 r8
add r7 r4
add r7 7
load8 r3 $r7
cmp r3 32
jne x8_miss_173
mov r7 r8
add r7 r4
add r7 8
load8 r3 $r7
cmp r3 103
je x8_case_181
cmp r3 71
jne x8_miss_173
label x8_case_181
mov r7 r8
add r7 r4
add r7 9
load8 r3 $r7
cmp r3 114
je x8_case_182
cmp r3 82
jne x8_miss_173
label x8_case_182
mov r7 r8
add r7 r4
add r7 10
load8 r3 $r7
cmp r3 97
je x8_case_183
cmp r3 65
jne x8_miss_173
label x8_case_183
mov r7 r8
add r7 r4
add r7 11
load8 r3 $r7
cmp r3 109
je x8_case_184
cmp r3 77
jne x8_miss_173
label x8_case_184
mov r7 r8
add r7 r4
add r7 12
load8 r3 $r7
cmp r3 195
jne x8_miss_173
mov r7 r8
add r7 r4
add r7 13
load8 r3 $r7
cmp r3 161
je x8_case_185
cmp r3 129
jne x8_miss_173
label x8_case_185
mov r7 r8
add r7 r4
add r7 14
load8 r3 $r7
cmp r3 116
je x8_case_186
cmp r3 84
jne x8_miss_173
label x8_case_186
mov r7 r8
add r7 r4
add r7 15
load8 r3 $r7
cmp r3 105
je x8_case_187
cmp r3 73
jne x8_miss_173
label x8_case_187
mov r7 r8
add r7 r4
add r7 16
load8 r3 $r7
cmp r3 99
je x8_case_188
cmp r3 67
jne x8_miss_173
label x8_case_188
mov r7 r8
add r7 r4
add r7 17
load8 r3 $r7
cmp r3 97
je x8_case_189
cmp r3 65
jne x8_miss_173
label x8_case_189
mov r7 r8
add r7 r4
add r7 18
load8 r3 $r7
cmp r3 58
jne x8_miss_173
mov r7 r8
add r7 r4
add r7 19
load8 r3 $r7
cmp r3 32
jne x8_miss_173
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_grammar
label x8_miss_173
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 19
cmp r6 r9
jgt x8_miss_190
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 99
je x8_case_191
cmp r3 67
jne x8_miss_190
label x8_case_191
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 111
je x8_case_192
cmp r3 79
jne x8_miss_190
label x8_case_192
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 114
je x8_case_193
cmp r3 82
jne x8_miss_190
label x8_case_193
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 114
je x8_case_194
cmp r3 82
jne x8_miss_190
label x8_case_194
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 105
je x8_case_195
cmp r3 73
jne x8_miss_190
label x8_case_195
mov r7 r8
add r7 r4
add r7 5
load8 r3 $r7
cmp r3 103
je x8_case_196
cmp r3 71
jne x8_miss_190
label x8_case_196
mov r7 r8
add r7 r4
add r7 6
load8 r3 $r7
cmp r3 101
je x8_case_197
cmp r3 69
jne x8_miss_190
label x8_case_197
mov r7 r8
add r7 r4
add r7 7
load8 r3 $r7
cmp r3 32
jne x8_miss_190
mov r7 r8
add r7 r4
add r7 8
load8 r3 $r7
cmp r3 103
je x8_case_198
cmp r3 71
jne x8_miss_190
label x8_case_198
mov r7 r8
add r7 r4
add r7 9
load8 r3 $r7
cmp r3 114
je x8_case_199
cmp r3 82
jne x8_miss_190
label x8_case_199
mov r7 r8
add r7 r4
add r7 10
load8 r3 $r7
cmp r3 97
je x8_case_200
cmp r3 65
jne x8_miss_190
label x8_case_200
mov r7 r8
add r7 r4
add r7 11
load8 r3 $r7
cmp r3 109
je x8_case_201
cmp r3 77
jne x8_miss_190
label x8_case_201
mov r7 r8
add r7 r4
add r7 12
load8 r3 $r7
cmp r3 97
je x8_case_202
cmp r3 65
jne x8_miss_190
label x8_case_202
mov r7 r8
add r7 r4
add r7 13
load8 r3 $r7
cmp r3 116
je x8_case_203
cmp r3 84
jne x8_miss_190
label x8_case_203
mov r7 r8
add r7 r4
add r7 14
load8 r3 $r7
cmp r3 105
je x8_case_204
cmp r3 73
jne x8_miss_190
label x8_case_204
mov r7 r8
add r7 r4
add r7 15
load8 r3 $r7
cmp r3 99
je x8_case_205
cmp r3 67
jne x8_miss_190
label x8_case_205
mov r7 r8
add r7 r4
add r7 16
load8 r3 $r7
cmp r3 97
je x8_case_206
cmp r3 65
jne x8_miss_190
label x8_case_206
mov r7 r8
add r7 r4
add r7 17
load8 r3 $r7
cmp r3 58
jne x8_miss_190
mov r7 r8
add r7 r4
add r7 18
load8 r3 $r7
cmp r3 32
jne x8_miss_190
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_grammar
label x8_miss_190
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 9
cmp r6 r9
jgt x8_miss_207
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 99
je x8_case_208
cmp r3 67
jne x8_miss_207
label x8_case_208
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 111
je x8_case_209
cmp r3 79
jne x8_miss_207
label x8_case_209
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 114
je x8_case_210
cmp r3 82
jne x8_miss_207
label x8_case_210
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 114
je x8_case_211
cmp r3 82
jne x8_miss_207
label x8_case_211
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 105
je x8_case_212
cmp r3 73
jne x8_miss_207
label x8_case_212
mov r7 r8
add r7 r4
add r7 5
load8 r3 $r7
cmp r3 103
je x8_case_213
cmp r3 71
jne x8_miss_207
label x8_case_213
mov r7 r8
add r7 r4
add r7 6
load8 r3 $r7
cmp r3 101
je x8_case_214
cmp r3 69
jne x8_miss_207
label x8_case_214
mov r7 r8
add r7 r4
add r7 7
load8 r3 $r7
cmp r3 58
jne x8_miss_207
mov r7 r8
add r7 r4
add r7 8
load8 r3 $r7
cmp r3 32
jne x8_miss_207
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_grammar
label x8_miss_207
jmp x8_route_172
label x8_route_172
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 21
cmp r6 r9
jgt x8_miss_216
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 101
je x8_case_217
cmp r3 69
jne x8_miss_216
label x8_case_217
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 110
je x8_case_218
cmp r3 78
jne x8_miss_216
label x8_case_218
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 115
je x8_case_219
cmp r3 83
jne x8_miss_216
label x8_case_219
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 101
je x8_case_220
cmp r3 69
jne x8_miss_216
label x8_case_220
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 195
jne x8_miss_216
mov r7 r8
add r7 r4
add r7 5
load8 r3 $r7
cmp r3 177
je x8_case_221
cmp r3 145
jne x8_miss_216
label x8_case_221
mov r7 r8
add r7 r4
add r7 6
load8 r3 $r7
cmp r3 97
je x8_case_222
cmp r3 65
jne x8_miss_216
label x8_case_222
mov r7 r8
add r7 r4
add r7 7
load8 r3 $r7
cmp r3 32
jne x8_miss_216
mov r7 r8
add r7 r4
add r7 8
load8 r3 $r7
cmp r3 116
je x8_case_223
cmp r3 84
jne x8_miss_216
label x8_case_223
mov r7 r8
add r7 r4
add r7 9
load8 r3 $r7
cmp r3 114
je x8_case_224
cmp r3 82
jne x8_miss_216
label x8_case_224
mov r7 r8
add r7 r4
add r7 10
load8 r3 $r7
cmp r3 97
je x8_case_225
cmp r3 65
jne x8_miss_216
label x8_case_225
mov r7 r8
add r7 r4
add r7 11
load8 r3 $r7
cmp r3 100
je x8_case_226
cmp r3 68
jne x8_miss_216
label x8_case_226
mov r7 r8
add r7 r4
add r7 12
load8 r3 $r7
cmp r3 117
je x8_case_227
cmp r3 85
jne x8_miss_216
label x8_case_227
mov r7 r8
add r7 r4
add r7 13
load8 r3 $r7
cmp r3 99
je x8_case_228
cmp r3 67
jne x8_miss_216
label x8_case_228
mov r7 r8
add r7 r4
add r7 14
load8 r3 $r7
cmp r3 99
je x8_case_229
cmp r3 67
jne x8_miss_216
label x8_case_229
mov r7 r8
add r7 r4
add r7 15
load8 r3 $r7
cmp r3 105
je x8_case_230
cmp r3 73
jne x8_miss_216
label x8_case_230
mov r7 r8
add r7 r4
add r7 16
load8 r3 $r7
cmp r3 195
jne x8_miss_216
mov r7 r8
add r7 r4
add r7 17
load8 r3 $r7
cmp r3 179
je x8_case_231
cmp r3 147
jne x8_miss_216
label x8_case_231
mov r7 r8
add r7 r4
add r7 18
load8 r3 $r7
cmp r3 110
je x8_case_232
cmp r3 78
jne x8_miss_216
label x8_case_232
mov r7 r8
add r7 r4
add r7 19
load8 r3 $r7
cmp r3 58
jne x8_miss_216
mov r7 r8
add r7 r4
add r7 20
load8 r3 $r7
cmp r3 32
jne x8_miss_216
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_teach_pair
label x8_miss_216
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 19
cmp r6 r9
jgt x8_miss_233
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 101
je x8_case_234
cmp r3 69
jne x8_miss_233
label x8_case_234
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 110
je x8_case_235
cmp r3 78
jne x8_miss_233
label x8_case_235
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 115
je x8_case_236
cmp r3 83
jne x8_miss_233
label x8_case_236
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 101
je x8_case_237
cmp r3 69
jne x8_miss_233
label x8_case_237
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 110
je x8_case_238
cmp r3 78
jne x8_miss_233
label x8_case_238
mov r7 r8
add r7 r4
add r7 5
load8 r3 $r7
cmp r3 97
je x8_case_239
cmp r3 65
jne x8_miss_233
label x8_case_239
mov r7 r8
add r7 r4
add r7 6
load8 r3 $r7
cmp r3 32
jne x8_miss_233
mov r7 r8
add r7 r4
add r7 7
load8 r3 $r7
cmp r3 116
je x8_case_240
cmp r3 84
jne x8_miss_233
label x8_case_240
mov r7 r8
add r7 r4
add r7 8
load8 r3 $r7
cmp r3 114
je x8_case_241
cmp r3 82
jne x8_miss_233
label x8_case_241
mov r7 r8
add r7 r4
add r7 9
load8 r3 $r7
cmp r3 97
je x8_case_242
cmp r3 65
jne x8_miss_233
label x8_case_242
mov r7 r8
add r7 r4
add r7 10
load8 r3 $r7
cmp r3 100
je x8_case_243
cmp r3 68
jne x8_miss_233
label x8_case_243
mov r7 r8
add r7 r4
add r7 11
load8 r3 $r7
cmp r3 117
je x8_case_244
cmp r3 85
jne x8_miss_233
label x8_case_244
mov r7 r8
add r7 r4
add r7 12
load8 r3 $r7
cmp r3 99
je x8_case_245
cmp r3 67
jne x8_miss_233
label x8_case_245
mov r7 r8
add r7 r4
add r7 13
load8 r3 $r7
cmp r3 99
je x8_case_246
cmp r3 67
jne x8_miss_233
label x8_case_246
mov r7 r8
add r7 r4
add r7 14
load8 r3 $r7
cmp r3 105
je x8_case_247
cmp r3 73
jne x8_miss_233
label x8_case_247
mov r7 r8
add r7 r4
add r7 15
load8 r3 $r7
cmp r3 111
je x8_case_248
cmp r3 79
jne x8_miss_233
label x8_case_248
mov r7 r8
add r7 r4
add r7 16
load8 r3 $r7
cmp r3 110
je x8_case_249
cmp r3 78
jne x8_miss_233
label x8_case_249
mov r7 r8
add r7 r4
add r7 17
load8 r3 $r7
cmp r3 58
jne x8_miss_233
mov r7 r8
add r7 r4
add r7 18
load8 r3 $r7
cmp r3 32
jne x8_miss_233
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_teach_pair
label x8_miss_233
jmp x8_route_215
label x8_route_215
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 10
cmp r6 r9
jgt x8_miss_251
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 114
je x8_case_252
cmp r3 82
jne x8_miss_251
label x8_case_252
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 101
je x8_case_253
cmp r3 69
jne x8_miss_251
label x8_case_253
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 115
je x8_case_254
cmp r3 83
jne x8_miss_251
label x8_case_254
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 117
je x8_case_255
cmp r3 85
jne x8_miss_251
label x8_case_255
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 109
je x8_case_256
cmp r3 77
jne x8_miss_251
label x8_case_256
mov r7 r8
add r7 r4
add r7 5
load8 r3 $r7
cmp r3 101
je x8_case_257
cmp r3 69
jne x8_miss_251
label x8_case_257
mov r7 r8
add r7 r4
add r7 6
load8 r3 $r7
cmp r3 32
jne x8_miss_251
mov r7 r8
add r7 r4
add r7 7
load8 r3 $r7
cmp r3 101
je x8_case_258
cmp r3 69
jne x8_miss_251
label x8_case_258
mov r7 r8
add r7 r4
add r7 8
load8 r3 $r7
cmp r3 110
je x8_case_259
cmp r3 78
jne x8_miss_251
label x8_case_259
mov r7 r8
add r7 r4
add r7 9
load8 r3 $r7
cmp r3 32
jne x8_miss_251
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_summary_count
label x8_miss_251
jmp x8_route_250
label x8_route_250
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 8
cmp r6 r9
jgt x8_miss_261
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 114
je x8_case_262
cmp r3 82
jne x8_miss_261
label x8_case_262
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 101
je x8_case_263
cmp r3 69
jne x8_miss_261
label x8_case_263
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 115
je x8_case_264
cmp r3 83
jne x8_miss_261
label x8_case_264
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 117
je x8_case_265
cmp r3 85
jne x8_miss_261
label x8_case_265
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 109
je x8_case_266
cmp r3 77
jne x8_miss_261
label x8_case_266
mov r7 r8
add r7 r4
add r7 5
load8 r3 $r7
cmp r3 101
je x8_case_267
cmp r3 69
jne x8_miss_261
label x8_case_267
mov r7 r8
add r7 r4
add r7 6
load8 r3 $r7
cmp r3 58
jne x8_miss_261
mov r7 r8
add r7 r4
add r7 7
load8 r3 $r7
cmp r3 10
jne x8_miss_261
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_summary
label x8_miss_261
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 9
cmp r6 r9
jgt x8_miss_268
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 114
je x8_case_269
cmp r3 82
jne x8_miss_268
label x8_case_269
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 101
je x8_case_270
cmp r3 69
jne x8_miss_268
label x8_case_270
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 115
je x8_case_271
cmp r3 83
jne x8_miss_268
label x8_case_271
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 117
je x8_case_272
cmp r3 85
jne x8_miss_268
label x8_case_272
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 109
je x8_case_273
cmp r3 77
jne x8_miss_268
label x8_case_273
mov r7 r8
add r7 r4
add r7 5
load8 r3 $r7
cmp r3 101
je x8_case_274
cmp r3 69
jne x8_miss_268
label x8_case_274
mov r7 r8
add r7 r4
add r7 6
load8 r3 $r7
cmp r3 58
jne x8_miss_268
mov r7 r8
add r7 r4
add r7 7
load8 r3 $r7
cmp r3 13
jne x8_miss_268
mov r7 r8
add r7 r4
add r7 8
load8 r3 $r7
cmp r3 10
jne x8_miss_268
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_summary
label x8_miss_268
jmp x8_route_260
label x8_route_260
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 9
cmp r6 r9
jgt x8_miss_276
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 99
je x8_case_277
cmp r3 67
jne x8_miss_276
label x8_case_277
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 111
je x8_case_278
cmp r3 79
jne x8_miss_276
label x8_case_278
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 109
je x8_case_279
cmp r3 77
jne x8_miss_276
label x8_case_279
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 112
je x8_case_280
cmp r3 80
jne x8_miss_276
label x8_case_280
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 97
je x8_case_281
cmp r3 65
jne x8_miss_276
label x8_case_281
mov r7 r8
add r7 r4
add r7 5
load8 r3 $r7
cmp r3 114
je x8_case_282
cmp r3 82
jne x8_miss_276
label x8_case_282
mov r7 r8
add r7 r4
add r7 6
load8 r3 $r7
cmp r3 97
je x8_case_283
cmp r3 65
jne x8_miss_276
label x8_case_283
mov r7 r8
add r7 r4
add r7 7
load8 r3 $r7
cmp r3 58
jne x8_miss_276
mov r7 r8
add r7 r4
add r7 8
load8 r3 $r7
cmp r3 10
jne x8_miss_276
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_compare
label x8_miss_276
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 10
cmp r6 r9
jgt x8_miss_284
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 99
je x8_case_285
cmp r3 67
jne x8_miss_284
label x8_case_285
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 111
je x8_case_286
cmp r3 79
jne x8_miss_284
label x8_case_286
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 109
je x8_case_287
cmp r3 77
jne x8_miss_284
label x8_case_287
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 112
je x8_case_288
cmp r3 80
jne x8_miss_284
label x8_case_288
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 97
je x8_case_289
cmp r3 65
jne x8_miss_284
label x8_case_289
mov r7 r8
add r7 r4
add r7 5
load8 r3 $r7
cmp r3 114
je x8_case_290
cmp r3 82
jne x8_miss_284
label x8_case_290
mov r7 r8
add r7 r4
add r7 6
load8 r3 $r7
cmp r3 97
je x8_case_291
cmp r3 65
jne x8_miss_284
label x8_case_291
mov r7 r8
add r7 r4
add r7 7
load8 r3 $r7
cmp r3 58
jne x8_miss_284
mov r7 r8
add r7 r4
add r7 8
load8 r3 $r7
cmp r3 13
jne x8_miss_284
mov r7 r8
add r7 r4
add r7 9
load8 r3 $r7
cmp r3 10
jne x8_miss_284
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_compare
label x8_miss_284
jmp x8_route_275
label x8_route_275
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 16
cmp r6 r9
jgt x8_miss_293
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 114
je x8_case_294
cmp r3 82
jne x8_miss_293
label x8_case_294
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 101
je x8_case_295
cmp r3 69
jne x8_miss_293
label x8_case_295
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 100
je x8_case_296
cmp r3 68
jne x8_miss_293
label x8_case_296
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 97
je x8_case_297
cmp r3 65
jne x8_miss_293
label x8_case_297
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 99
je x8_case_298
cmp r3 67
jne x8_miss_293
label x8_case_298
mov r7 r8
add r7 r4
add r7 5
load8 r3 $r7
cmp r3 116
je x8_case_299
cmp r3 84
jne x8_miss_293
label x8_case_299
mov r7 r8
add r7 r4
add r7 6
load8 r3 $r7
cmp r3 97
je x8_case_300
cmp r3 65
jne x8_miss_293
label x8_case_300
mov r7 r8
add r7 r4
add r7 7
load8 r3 $r7
cmp r3 32
jne x8_miss_293
mov r7 r8
add r7 r4
add r7 8
load8 r3 $r7
cmp r3 99
je x8_case_301
cmp r3 67
jne x8_miss_293
label x8_case_301
mov r7 r8
add r7 r4
add r7 9
load8 r3 $r7
cmp r3 111
je x8_case_302
cmp r3 79
jne x8_miss_293
label x8_case_302
mov r7 r8
add r7 r4
add r7 10
load8 r3 $r7
cmp r3 114
je x8_case_303
cmp r3 82
jne x8_miss_293
label x8_case_303
mov r7 r8
add r7 r4
add r7 11
load8 r3 $r7
cmp r3 114
je x8_case_304
cmp r3 82
jne x8_miss_293
label x8_case_304
mov r7 r8
add r7 r4
add r7 12
load8 r3 $r7
cmp r3 101
je x8_case_305
cmp r3 69
jne x8_miss_293
label x8_case_305
mov r7 r8
add r7 r4
add r7 13
load8 r3 $r7
cmp r3 111
je x8_case_306
cmp r3 79
jne x8_miss_293
label x8_case_306
mov r7 r8
add r7 r4
add r7 14
load8 r3 $r7
cmp r3 58
jne x8_miss_293
mov r7 r8
add r7 r4
add r7 15
load8 r3 $r7
cmp r3 10
jne x8_miss_293
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_mail
label x8_miss_293
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 17
cmp r6 r9
jgt x8_miss_307
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 114
je x8_case_308
cmp r3 82
jne x8_miss_307
label x8_case_308
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 101
je x8_case_309
cmp r3 69
jne x8_miss_307
label x8_case_309
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 100
je x8_case_310
cmp r3 68
jne x8_miss_307
label x8_case_310
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 97
je x8_case_311
cmp r3 65
jne x8_miss_307
label x8_case_311
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 99
je x8_case_312
cmp r3 67
jne x8_miss_307
label x8_case_312
mov r7 r8
add r7 r4
add r7 5
load8 r3 $r7
cmp r3 116
je x8_case_313
cmp r3 84
jne x8_miss_307
label x8_case_313
mov r7 r8
add r7 r4
add r7 6
load8 r3 $r7
cmp r3 97
je x8_case_314
cmp r3 65
jne x8_miss_307
label x8_case_314
mov r7 r8
add r7 r4
add r7 7
load8 r3 $r7
cmp r3 32
jne x8_miss_307
mov r7 r8
add r7 r4
add r7 8
load8 r3 $r7
cmp r3 99
je x8_case_315
cmp r3 67
jne x8_miss_307
label x8_case_315
mov r7 r8
add r7 r4
add r7 9
load8 r3 $r7
cmp r3 111
je x8_case_316
cmp r3 79
jne x8_miss_307
label x8_case_316
mov r7 r8
add r7 r4
add r7 10
load8 r3 $r7
cmp r3 114
je x8_case_317
cmp r3 82
jne x8_miss_307
label x8_case_317
mov r7 r8
add r7 r4
add r7 11
load8 r3 $r7
cmp r3 114
je x8_case_318
cmp r3 82
jne x8_miss_307
label x8_case_318
mov r7 r8
add r7 r4
add r7 12
load8 r3 $r7
cmp r3 101
je x8_case_319
cmp r3 69
jne x8_miss_307
label x8_case_319
mov r7 r8
add r7 r4
add r7 13
load8 r3 $r7
cmp r3 111
je x8_case_320
cmp r3 79
jne x8_miss_307
label x8_case_320
mov r7 r8
add r7 r4
add r7 14
load8 r3 $r7
cmp r3 58
jne x8_miss_307
mov r7 r8
add r7 r4
add r7 15
load8 r3 $r7
cmp r3 13
jne x8_miss_307
mov r7 r8
add r7 r4
add r7 16
load8 r3 $r7
cmp r3 10
jne x8_miss_307
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_mail
label x8_miss_307
jmp x8_route_292
label x8_route_292
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 12
cmp r6 r9
jgt x8_miss_322
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 108
je x8_case_323
cmp r3 76
jne x8_miss_322
label x8_case_323
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 101
je x8_case_324
cmp r3 69
jne x8_miss_322
label x8_case_324
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 101
je x8_case_325
cmp r3 69
jne x8_miss_322
label x8_case_325
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 32
jne x8_miss_322
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 112
je x8_case_326
cmp r3 80
jne x8_miss_322
label x8_case_326
mov r7 r8
add r7 r4
add r7 5
load8 r3 $r7
cmp r3 195
jne x8_miss_322
mov r7 r8
add r7 r4
add r7 6
load8 r3 $r7
cmp r3 161
je x8_case_327
cmp r3 129
jne x8_miss_322
label x8_case_327
mov r7 r8
add r7 r4
add r7 7
load8 r3 $r7
cmp r3 103
je x8_case_328
cmp r3 71
jne x8_miss_322
label x8_case_328
mov r7 r8
add r7 r4
add r7 8
load8 r3 $r7
cmp r3 105
je x8_case_329
cmp r3 73
jne x8_miss_322
label x8_case_329
mov r7 r8
add r7 r4
add r7 9
load8 r3 $r7
cmp r3 110
je x8_case_330
cmp r3 78
jne x8_miss_322
label x8_case_330
mov r7 r8
add r7 r4
add r7 10
load8 r3 $r7
cmp r3 97
je x8_case_331
cmp r3 65
jne x8_miss_322
label x8_case_331
mov r7 r8
add r7 r4
add r7 11
load8 r3 $r7
cmp r3 32
jne x8_miss_322
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_page
label x8_miss_322
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 11
cmp r6 r9
jgt x8_miss_332
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 108
je x8_case_333
cmp r3 76
jne x8_miss_332
label x8_case_333
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 101
je x8_case_334
cmp r3 69
jne x8_miss_332
label x8_case_334
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 101
je x8_case_335
cmp r3 69
jne x8_miss_332
label x8_case_335
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 32
jne x8_miss_332
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 112
je x8_case_336
cmp r3 80
jne x8_miss_332
label x8_case_336
mov r7 r8
add r7 r4
add r7 5
load8 r3 $r7
cmp r3 97
je x8_case_337
cmp r3 65
jne x8_miss_332
label x8_case_337
mov r7 r8
add r7 r4
add r7 6
load8 r3 $r7
cmp r3 103
je x8_case_338
cmp r3 71
jne x8_miss_332
label x8_case_338
mov r7 r8
add r7 r4
add r7 7
load8 r3 $r7
cmp r3 105
je x8_case_339
cmp r3 73
jne x8_miss_332
label x8_case_339
mov r7 r8
add r7 r4
add r7 8
load8 r3 $r7
cmp r3 110
je x8_case_340
cmp r3 78
jne x8_miss_332
label x8_case_340
mov r7 r8
add r7 r4
add r7 9
load8 r3 $r7
cmp r3 97
je x8_case_341
cmp r3 65
jne x8_miss_332
label x8_case_341
mov r7 r8
add r7 r4
add r7 10
load8 r3 $r7
cmp r3 32
jne x8_miss_332
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_page
label x8_miss_332
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 10
cmp r6 r9
jgt x8_miss_342
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 114
je x8_case_343
cmp r3 82
jne x8_miss_342
label x8_case_343
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 101
je x8_case_344
cmp r3 69
jne x8_miss_342
label x8_case_344
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 97
je x8_case_345
cmp r3 65
jne x8_miss_342
label x8_case_345
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 100
je x8_case_346
cmp r3 68
jne x8_miss_342
label x8_case_346
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 32
jne x8_miss_342
mov r7 r8
add r7 r4
add r7 5
load8 r3 $r7
cmp r3 112
je x8_case_347
cmp r3 80
jne x8_miss_342
label x8_case_347
mov r7 r8
add r7 r4
add r7 6
load8 r3 $r7
cmp r3 97
je x8_case_348
cmp r3 65
jne x8_miss_342
label x8_case_348
mov r7 r8
add r7 r4
add r7 7
load8 r3 $r7
cmp r3 103
je x8_case_349
cmp r3 71
jne x8_miss_342
label x8_case_349
mov r7 r8
add r7 r4
add r7 8
load8 r3 $r7
cmp r3 101
je x8_case_350
cmp r3 69
jne x8_miss_342
label x8_case_350
mov r7 r8
add r7 r4
add r7 9
load8 r3 $r7
cmp r3 32
jne x8_miss_342
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_page
label x8_miss_342
jmp x8_route_321
label x8_route_321
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 20
cmp r6 r9
jgt x8_miss_352
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 99
je x8_case_353
cmp r3 67
jne x8_miss_352
label x8_case_353
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 111
je x8_case_354
cmp r3 79
jne x8_miss_352
label x8_case_354
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 110
je x8_case_355
cmp r3 78
jne x8_miss_352
label x8_case_355
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 115
je x8_case_356
cmp r3 83
jne x8_miss_352
label x8_case_356
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 117
je x8_case_357
cmp r3 85
jne x8_miss_352
label x8_case_357
mov r7 r8
add r7 r4
add r7 5
load8 r3 $r7
cmp r3 108
je x8_case_358
cmp r3 76
jne x8_miss_352
label x8_case_358
mov r7 r8
add r7 r4
add r7 6
load8 r3 $r7
cmp r3 116
je x8_case_359
cmp r3 84
jne x8_miss_352
label x8_case_359
mov r7 r8
add r7 r4
add r7 7
load8 r3 $r7
cmp r3 97
je x8_case_360
cmp r3 65
jne x8_miss_352
label x8_case_360
mov r7 r8
add r7 r4
add r7 8
load8 r3 $r7
cmp r3 32
jne x8_miss_352
mov r7 r8
add r7 r4
add r7 9
load8 r3 $r7
cmp r3 66
jne x8_miss_352
mov r7 r8
add r7 r4
add r7 10
load8 r3 $r7
cmp r3 97
je x8_case_361
cmp r3 65
jne x8_miss_352
label x8_case_361
mov r7 r8
add r7 r4
add r7 11
load8 r3 $r7
cmp r3 98
je x8_case_362
cmp r3 66
jne x8_miss_352
label x8_case_362
mov r7 r8
add r7 r4
add r7 12
load8 r3 $r7
cmp r3 105
je x8_case_363
cmp r3 73
jne x8_miss_352
label x8_case_363
mov r7 r8
add r7 r4
add r7 13
load8 r3 $r7
cmp r3 108
je x8_case_364
cmp r3 76
jne x8_miss_352
label x8_case_364
mov r7 r8
add r7 r4
add r7 14
load8 r3 $r7
cmp r3 111
je x8_case_365
cmp r3 79
jne x8_miss_352
label x8_case_365
mov r7 r8
add r7 r4
add r7 15
load8 r3 $r7
cmp r3 110
je x8_case_366
cmp r3 78
jne x8_miss_352
label x8_case_366
mov r7 r8
add r7 r4
add r7 16
load8 r3 $r7
cmp r3 105
je x8_case_367
cmp r3 73
jne x8_miss_352
label x8_case_367
mov r7 r8
add r7 r4
add r7 17
load8 r3 $r7
cmp r3 97
je x8_case_368
cmp r3 65
jne x8_miss_352
label x8_case_368
mov r7 r8
add r7 r4
add r7 18
load8 r3 $r7
cmp r3 58
jne x8_miss_352
mov r7 r8
add r7 r4
add r7 19
load8 r3 $r7
cmp r3 32
jne x8_miss_352
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_search
label x8_miss_352
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 20
cmp r6 r9
jgt x8_miss_369
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 99
je x8_case_370
cmp r3 67
jne x8_miss_369
label x8_case_370
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 111
je x8_case_371
cmp r3 79
jne x8_miss_369
label x8_case_371
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 110
je x8_case_372
cmp r3 78
jne x8_miss_369
label x8_case_372
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 115
je x8_case_373
cmp r3 83
jne x8_miss_369
label x8_case_373
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 117
je x8_case_374
cmp r3 85
jne x8_miss_369
label x8_case_374
mov r7 r8
add r7 r4
add r7 5
load8 r3 $r7
cmp r3 108
je x8_case_375
cmp r3 76
jne x8_miss_369
label x8_case_375
mov r7 r8
add r7 r4
add r7 6
load8 r3 $r7
cmp r3 116
je x8_case_376
cmp r3 84
jne x8_miss_369
label x8_case_376
mov r7 r8
add r7 r4
add r7 7
load8 r3 $r7
cmp r3 97
je x8_case_377
cmp r3 65
jne x8_miss_369
label x8_case_377
mov r7 r8
add r7 r4
add r7 8
load8 r3 $r7
cmp r3 32
jne x8_miss_369
mov r7 r8
add r7 r4
add r7 9
load8 r3 $r7
cmp r3 98
je x8_case_378
cmp r3 66
jne x8_miss_369
label x8_case_378
mov r7 r8
add r7 r4
add r7 10
load8 r3 $r7
cmp r3 97
je x8_case_379
cmp r3 65
jne x8_miss_369
label x8_case_379
mov r7 r8
add r7 r4
add r7 11
load8 r3 $r7
cmp r3 98
je x8_case_380
cmp r3 66
jne x8_miss_369
label x8_case_380
mov r7 r8
add r7 r4
add r7 12
load8 r3 $r7
cmp r3 105
je x8_case_381
cmp r3 73
jne x8_miss_369
label x8_case_381
mov r7 r8
add r7 r4
add r7 13
load8 r3 $r7
cmp r3 108
je x8_case_382
cmp r3 76
jne x8_miss_369
label x8_case_382
mov r7 r8
add r7 r4
add r7 14
load8 r3 $r7
cmp r3 111
je x8_case_383
cmp r3 79
jne x8_miss_369
label x8_case_383
mov r7 r8
add r7 r4
add r7 15
load8 r3 $r7
cmp r3 110
je x8_case_384
cmp r3 78
jne x8_miss_369
label x8_case_384
mov r7 r8
add r7 r4
add r7 16
load8 r3 $r7
cmp r3 105
je x8_case_385
cmp r3 73
jne x8_miss_369
label x8_case_385
mov r7 r8
add r7 r4
add r7 17
load8 r3 $r7
cmp r3 97
je x8_case_386
cmp r3 65
jne x8_miss_369
label x8_case_386
mov r7 r8
add r7 r4
add r7 18
load8 r3 $r7
cmp r3 58
jne x8_miss_369
mov r7 r8
add r7 r4
add r7 19
load8 r3 $r7
cmp r3 32
jne x8_miss_369
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_search
label x8_miss_369
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 18
cmp r6 r9
jgt x8_miss_387
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 115
je x8_case_388
cmp r3 83
jne x8_miss_387
label x8_case_388
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 101
je x8_case_389
cmp r3 69
jne x8_miss_387
label x8_case_389
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 103
je x8_case_390
cmp r3 71
jne x8_miss_387
label x8_case_390
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 195
jne x8_miss_387
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 186
je x8_case_391
cmp r3 154
jne x8_miss_387
label x8_case_391
mov r7 r8
add r7 r4
add r7 5
load8 r3 $r7
cmp r3 110
je x8_case_392
cmp r3 78
jne x8_miss_387
label x8_case_392
mov r7 r8
add r7 r4
add r7 6
load8 r3 $r7
cmp r3 32
jne x8_miss_387
mov r7 r8
add r7 r4
add r7 7
load8 r3 $r7
cmp r3 66
jne x8_miss_387
mov r7 r8
add r7 r4
add r7 8
load8 r3 $r7
cmp r3 97
je x8_case_393
cmp r3 65
jne x8_miss_387
label x8_case_393
mov r7 r8
add r7 r4
add r7 9
load8 r3 $r7
cmp r3 98
je x8_case_394
cmp r3 66
jne x8_miss_387
label x8_case_394
mov r7 r8
add r7 r4
add r7 10
load8 r3 $r7
cmp r3 105
je x8_case_395
cmp r3 73
jne x8_miss_387
label x8_case_395
mov r7 r8
add r7 r4
add r7 11
load8 r3 $r7
cmp r3 108
je x8_case_396
cmp r3 76
jne x8_miss_387
label x8_case_396
mov r7 r8
add r7 r4
add r7 12
load8 r3 $r7
cmp r3 111
je x8_case_397
cmp r3 79
jne x8_miss_387
label x8_case_397
mov r7 r8
add r7 r4
add r7 13
load8 r3 $r7
cmp r3 110
je x8_case_398
cmp r3 78
jne x8_miss_387
label x8_case_398
mov r7 r8
add r7 r4
add r7 14
load8 r3 $r7
cmp r3 105
je x8_case_399
cmp r3 73
jne x8_miss_387
label x8_case_399
mov r7 r8
add r7 r4
add r7 15
load8 r3 $r7
cmp r3 97
je x8_case_400
cmp r3 65
jne x8_miss_387
label x8_case_400
mov r7 r8
add r7 r4
add r7 16
load8 r3 $r7
cmp r3 58
jne x8_miss_387
mov r7 r8
add r7 r4
add r7 17
load8 r3 $r7
cmp r3 32
jne x8_miss_387
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_search
label x8_miss_387
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 17
cmp r6 r9
jgt x8_miss_401
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 115
je x8_case_402
cmp r3 83
jne x8_miss_401
label x8_case_402
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 101
je x8_case_403
cmp r3 69
jne x8_miss_401
label x8_case_403
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 103
je x8_case_404
cmp r3 71
jne x8_miss_401
label x8_case_404
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 117
je x8_case_405
cmp r3 85
jne x8_miss_401
label x8_case_405
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 110
je x8_case_406
cmp r3 78
jne x8_miss_401
label x8_case_406
mov r7 r8
add r7 r4
add r7 5
load8 r3 $r7
cmp r3 32
jne x8_miss_401
mov r7 r8
add r7 r4
add r7 6
load8 r3 $r7
cmp r3 66
jne x8_miss_401
mov r7 r8
add r7 r4
add r7 7
load8 r3 $r7
cmp r3 97
je x8_case_407
cmp r3 65
jne x8_miss_401
label x8_case_407
mov r7 r8
add r7 r4
add r7 8
load8 r3 $r7
cmp r3 98
je x8_case_408
cmp r3 66
jne x8_miss_401
label x8_case_408
mov r7 r8
add r7 r4
add r7 9
load8 r3 $r7
cmp r3 105
je x8_case_409
cmp r3 73
jne x8_miss_401
label x8_case_409
mov r7 r8
add r7 r4
add r7 10
load8 r3 $r7
cmp r3 108
je x8_case_410
cmp r3 76
jne x8_miss_401
label x8_case_410
mov r7 r8
add r7 r4
add r7 11
load8 r3 $r7
cmp r3 111
je x8_case_411
cmp r3 79
jne x8_miss_401
label x8_case_411
mov r7 r8
add r7 r4
add r7 12
load8 r3 $r7
cmp r3 110
je x8_case_412
cmp r3 78
jne x8_miss_401
label x8_case_412
mov r7 r8
add r7 r4
add r7 13
load8 r3 $r7
cmp r3 105
je x8_case_413
cmp r3 73
jne x8_miss_401
label x8_case_413
mov r7 r8
add r7 r4
add r7 14
load8 r3 $r7
cmp r3 97
je x8_case_414
cmp r3 65
jne x8_miss_401
label x8_case_414
mov r7 r8
add r7 r4
add r7 15
load8 r3 $r7
cmp r3 58
jne x8_miss_401
mov r7 r8
add r7 r4
add r7 16
load8 r3 $r7
cmp r3 32
jne x8_miss_401
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_search
label x8_miss_401
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 10
cmp r6 r9
jgt x8_miss_415
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 99
je x8_case_416
cmp r3 67
jne x8_miss_415
label x8_case_416
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 111
je x8_case_417
cmp r3 79
jne x8_miss_415
label x8_case_417
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 110
je x8_case_418
cmp r3 78
jne x8_miss_415
label x8_case_418
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 115
je x8_case_419
cmp r3 83
jne x8_miss_415
label x8_case_419
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 117
je x8_case_420
cmp r3 85
jne x8_miss_415
label x8_case_420
mov r7 r8
add r7 r4
add r7 5
load8 r3 $r7
cmp r3 108
je x8_case_421
cmp r3 76
jne x8_miss_415
label x8_case_421
mov r7 r8
add r7 r4
add r7 6
load8 r3 $r7
cmp r3 116
je x8_case_422
cmp r3 84
jne x8_miss_415
label x8_case_422
mov r7 r8
add r7 r4
add r7 7
load8 r3 $r7
cmp r3 97
je x8_case_423
cmp r3 65
jne x8_miss_415
label x8_case_423
mov r7 r8
add r7 r4
add r7 8
load8 r3 $r7
cmp r3 58
jne x8_miss_415
mov r7 r8
add r7 r4
add r7 9
load8 r3 $r7
cmp r3 32
jne x8_miss_415
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_search
label x8_miss_415
jmp x8_route_351
label x8_route_351
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 12
cmp r6 r9
jgt x8_miss_425
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 64
jne x8_miss_425
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 98
je x8_case_426
cmp r3 66
jne x8_miss_425
label x8_case_426
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 111
je x8_case_427
cmp r3 79
jne x8_miss_425
label x8_case_427
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 111
je x8_case_428
cmp r3 79
jne x8_miss_425
label x8_case_428
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 107
je x8_case_429
cmp r3 75
jne x8_miss_425
label x8_case_429
mov r7 r8
add r7 r4
add r7 5
load8 r3 $r7
cmp r3 32
jne x8_miss_425
mov r7 r8
add r7 r4
add r7 6
load8 r3 $r7
cmp r3 115
je x8_case_430
cmp r3 83
jne x8_miss_425
label x8_case_430
mov r7 r8
add r7 r4
add r7 7
load8 r3 $r7
cmp r3 116
je x8_case_431
cmp r3 84
jne x8_miss_425
label x8_case_431
mov r7 r8
add r7 r4
add r7 8
load8 r3 $r7
cmp r3 97
je x8_case_432
cmp r3 65
jne x8_miss_425
label x8_case_432
mov r7 r8
add r7 r4
add r7 9
load8 r3 $r7
cmp r3 116
je x8_case_433
cmp r3 84
jne x8_miss_425
label x8_case_433
mov r7 r8
add r7 r4
add r7 10
load8 r3 $r7
cmp r3 117
je x8_case_434
cmp r3 85
jne x8_miss_425
label x8_case_434
mov r7 r8
add r7 r4
add r7 11
load8 r3 $r7
cmp r3 115
je x8_case_435
cmp r3 83
jne x8_miss_425
label x8_case_435
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_book_status
label x8_miss_425
jmp x8_route_424
label x8_route_424
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 16
cmp r6 r9
jgt x8_miss_437
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 64
jne x8_miss_437
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 108
je x8_case_438
cmp r3 76
jne x8_miss_437
label x8_case_438
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 97
je x8_case_439
cmp r3 65
jne x8_miss_437
label x8_case_439
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 110
je x8_case_440
cmp r3 78
jne x8_miss_437
label x8_case_440
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 103
je x8_case_441
cmp r3 71
jne x8_miss_437
label x8_case_441
mov r7 r8
add r7 r4
add r7 5
load8 r3 $r7
cmp r3 117
je x8_case_442
cmp r3 85
jne x8_miss_437
label x8_case_442
mov r7 r8
add r7 r4
add r7 6
load8 r3 $r7
cmp r3 97
je x8_case_443
cmp r3 65
jne x8_miss_437
label x8_case_443
mov r7 r8
add r7 r4
add r7 7
load8 r3 $r7
cmp r3 103
je x8_case_444
cmp r3 71
jne x8_miss_437
label x8_case_444
mov r7 r8
add r7 r4
add r7 8
load8 r3 $r7
cmp r3 101
je x8_case_445
cmp r3 69
jne x8_miss_437
label x8_case_445
mov r7 r8
add r7 r4
add r7 9
load8 r3 $r7
cmp r3 32
jne x8_miss_437
mov r7 r8
add r7 r4
add r7 10
load8 r3 $r7
cmp r3 115
je x8_case_446
cmp r3 83
jne x8_miss_437
label x8_case_446
mov r7 r8
add r7 r4
add r7 11
load8 r3 $r7
cmp r3 116
je x8_case_447
cmp r3 84
jne x8_miss_437
label x8_case_447
mov r7 r8
add r7 r4
add r7 12
load8 r3 $r7
cmp r3 97
je x8_case_448
cmp r3 65
jne x8_miss_437
label x8_case_448
mov r7 r8
add r7 r4
add r7 13
load8 r3 $r7
cmp r3 116
je x8_case_449
cmp r3 84
jne x8_miss_437
label x8_case_449
mov r7 r8
add r7 r4
add r7 14
load8 r3 $r7
cmp r3 117
je x8_case_450
cmp r3 85
jne x8_miss_437
label x8_case_450
mov r7 r8
add r7 r4
add r7 15
load8 r3 $r7
cmp r3 115
je x8_case_451
cmp r3 83
jne x8_miss_437
label x8_case_451
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_language_status
label x8_miss_437
jmp x8_route_436
label x8_route_436
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
cmp r9 512
jgt x8_resume
set r10 0
label x8_auto_query
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
cmp r10 r9
jge x8_resume
mov r14 r10
mod r14 256
store8 9120000000000100016 r14
mov r14 r10
div r14 256
mod r14 256
store8 9120000000000100017 r14
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 7
cmp r6 r9
jgt x8_miss_454
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 110
je x8_case_455
cmp r3 78
jne x8_miss_454
label x8_case_455
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 111
je x8_case_456
cmp r3 79
jne x8_miss_454
label x8_case_456
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 109
je x8_case_457
cmp r3 77
jne x8_miss_454
label x8_case_457
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 97
je x8_case_458
cmp r3 65
jne x8_miss_454
label x8_case_458
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 115
je x8_case_459
cmp r3 83
jne x8_miss_454
label x8_case_459
mov r7 r8
add r7 r4
add r7 5
load8 r3 $r7
cmp r3 105
je x8_case_460
cmp r3 73
jne x8_miss_454
label x8_case_460
mov r7 r8
add r7 r4
add r7 6
load8 r3 $r7
cmp r3 114
je x8_case_461
cmp r3 82
jne x8_miss_454
label x8_case_461
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_auto_hit_453
label x8_miss_454
jmp x8_auto_term_452
label x8_auto_hit_453
set r0 0
mov r14 r0
mod r14 256
store8 9120000000000100016 r14
mov r14 r0
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_search
label x8_auto_term_452
mov r14 r10
mod r14 256
store8 9120000000000100016 r14
mov r14 r10
div r14 256
mod r14 256
store8 9120000000000100017 r14
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 6
cmp r6 r9
jgt x8_miss_464
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 109
je x8_case_465
cmp r3 77
jne x8_miss_464
label x8_case_465
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 97
je x8_case_466
cmp r3 65
jne x8_miss_464
label x8_case_466
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 116
je x8_case_467
cmp r3 84
jne x8_miss_464
label x8_case_467
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 104
je x8_case_468
cmp r3 72
jne x8_miss_464
label x8_case_468
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 111
je x8_case_469
cmp r3 79
jne x8_miss_464
label x8_case_469
mov r7 r8
add r7 r4
add r7 5
load8 r3 $r7
cmp r3 110
je x8_case_470
cmp r3 78
jne x8_miss_464
label x8_case_470
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_auto_hit_463
label x8_miss_464
jmp x8_auto_term_462
label x8_auto_hit_463
set r0 0
mov r14 r0
mod r14 256
store8 9120000000000100016 r14
mov r14 r0
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_search
label x8_auto_term_462
mov r14 r10
mod r14 256
store8 9120000000000100016 r14
mov r14 r10
div r14 256
mod r14 256
store8 9120000000000100017 r14
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 5
cmp r6 r9
jgt x8_miss_473
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 97
je x8_case_474
cmp r3 65
jne x8_miss_473
label x8_case_474
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 114
je x8_case_475
cmp r3 82
jne x8_miss_473
label x8_case_475
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 107
je x8_case_476
cmp r3 75
jne x8_miss_473
label x8_case_476
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 97
je x8_case_477
cmp r3 65
jne x8_miss_473
label x8_case_477
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 100
je x8_case_478
cmp r3 68
jne x8_miss_473
label x8_case_478
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_auto_hit_472
label x8_miss_473
jmp x8_auto_term_471
label x8_auto_hit_472
set r0 0
mov r14 r0
mod r14 256
store8 9120000000000100016 r14
mov r14 r0
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_search
label x8_auto_term_471
mov r14 r10
mod r14 256
store8 9120000000000100016 r14
mov r14 r10
div r14 256
mod r14 256
store8 9120000000000100017 r14
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 7
cmp r6 r9
jgt x8_miss_481
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 100
je x8_case_482
cmp r3 68
jne x8_miss_481
label x8_case_482
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 97
je x8_case_483
cmp r3 65
jne x8_miss_481
label x8_case_483
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 98
je x8_case_484
cmp r3 66
jne x8_miss_481
label x8_case_484
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 97
je x8_case_485
cmp r3 65
jne x8_miss_481
label x8_case_485
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 115
je x8_case_486
cmp r3 83
jne x8_miss_481
label x8_case_486
mov r7 r8
add r7 r4
add r7 5
load8 r3 $r7
cmp r3 105
je x8_case_487
cmp r3 73
jne x8_miss_481
label x8_case_487
mov r7 r8
add r7 r4
add r7 6
load8 r3 $r7
cmp r3 114
je x8_case_488
cmp r3 82
jne x8_miss_481
label x8_case_488
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_auto_hit_480
label x8_miss_481
jmp x8_auto_term_479
label x8_auto_hit_480
set r0 0
mov r14 r0
mod r14 256
store8 9120000000000100016 r14
mov r14 r0
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_search
label x8_auto_term_479
mov r14 r10
mod r14 256
store8 9120000000000100016 r14
mov r14 r10
div r14 256
mod r14 256
store8 9120000000000100017 r14
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 7
cmp r6 r9
jgt x8_miss_491
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 107
je x8_case_492
cmp r3 75
jne x8_miss_491
label x8_case_492
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 97
je x8_case_493
cmp r3 65
jne x8_miss_491
label x8_case_493
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 108
je x8_case_494
cmp r3 76
jne x8_miss_491
label x8_case_494
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 97
je x8_case_495
cmp r3 65
jne x8_miss_491
label x8_case_495
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 98
je x8_case_496
cmp r3 66
jne x8_miss_491
label x8_case_496
mov r7 r8
add r7 r4
add r7 5
load8 r3 $r7
cmp r3 97
je x8_case_497
cmp r3 65
jne x8_miss_491
label x8_case_497
mov r7 r8
add r7 r4
add r7 6
load8 r3 $r7
cmp r3 98
je x8_case_498
cmp r3 66
jne x8_miss_491
label x8_case_498
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_auto_hit_490
label x8_miss_491
jmp x8_auto_term_489
label x8_auto_hit_490
set r0 0
mov r14 r0
mod r14 256
store8 9120000000000100016 r14
mov r14 r0
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_search
label x8_auto_term_489
mov r14 r10
mod r14 256
store8 9120000000000100016 r14
mov r14 r10
div r14 256
mod r14 256
store8 9120000000000100017 r14
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 6
cmp r6 r9
jgt x8_miss_501
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 115
je x8_case_502
cmp r3 83
jne x8_miss_501
label x8_case_502
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 104
je x8_case_503
cmp r3 72
jne x8_miss_501
label x8_case_503
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 97
je x8_case_504
cmp r3 65
jne x8_miss_501
label x8_case_504
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 114
je x8_case_505
cmp r3 82
jne x8_miss_501
label x8_case_505
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 114
je x8_case_506
cmp r3 82
jne x8_miss_501
label x8_case_506
mov r7 r8
add r7 r4
add r7 5
load8 r3 $r7
cmp r3 117
je x8_case_507
cmp r3 85
jne x8_miss_501
label x8_case_507
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_auto_hit_500
label x8_miss_501
jmp x8_auto_term_499
label x8_auto_hit_500
set r0 0
mov r14 r0
mod r14 256
store8 9120000000000100016 r14
mov r14 r0
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_search
label x8_auto_term_499
mov r14 r10
mod r14 256
store8 9120000000000100016 r14
mov r14 r10
div r14 256
mod r14 256
store8 9120000000000100017 r14
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 9
cmp r6 r9
jgt x8_miss_510
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 98
je x8_case_511
cmp r3 66
jne x8_miss_510
label x8_case_511
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 97
je x8_case_512
cmp r3 65
jne x8_miss_510
label x8_case_512
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 98
je x8_case_513
cmp r3 66
jne x8_miss_510
label x8_case_513
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 105
je x8_case_514
cmp r3 73
jne x8_miss_510
label x8_case_514
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 108
je x8_case_515
cmp r3 76
jne x8_miss_510
label x8_case_515
mov r7 r8
add r7 r4
add r7 5
load8 r3 $r7
cmp r3 111
je x8_case_516
cmp r3 79
jne x8_miss_510
label x8_case_516
mov r7 r8
add r7 r4
add r7 6
load8 r3 $r7
cmp r3 110
je x8_case_517
cmp r3 78
jne x8_miss_510
label x8_case_517
mov r7 r8
add r7 r4
add r7 7
load8 r3 $r7
cmp r3 105
je x8_case_518
cmp r3 73
jne x8_miss_510
label x8_case_518
mov r7 r8
add r7 r4
add r7 8
load8 r3 $r7
cmp r3 97
je x8_case_519
cmp r3 65
jne x8_miss_510
label x8_case_519
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_auto_hit_509
label x8_miss_510
jmp x8_auto_term_508
label x8_auto_hit_509
set r0 0
mov r14 r0
mod r14 256
store8 9120000000000100016 r14
mov r14 r0
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_search
label x8_auto_term_508
mov r14 r10
mod r14 256
store8 9120000000000100016 r14
mov r14 r10
div r14 256
mod r14 256
store8 9120000000000100017 r14
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 10
cmp r6 r9
jgt x8_miss_522
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 101
je x8_case_523
cmp r3 69
jne x8_miss_522
label x8_case_523
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 115
je x8_case_524
cmp r3 83
jne x8_miss_522
label x8_case_524
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 116
je x8_case_525
cmp r3 84
jne x8_miss_522
label x8_case_525
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 101
je x8_case_526
cmp r3 69
jne x8_miss_522
label x8_case_526
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 32
jne x8_miss_522
mov r7 r8
add r7 r4
add r7 5
load8 r3 $r7
cmp r3 108
je x8_case_527
cmp r3 76
jne x8_miss_522
label x8_case_527
mov r7 r8
add r7 r4
add r7 6
load8 r3 $r7
cmp r3 105
je x8_case_528
cmp r3 73
jne x8_miss_522
label x8_case_528
mov r7 r8
add r7 r4
add r7 7
load8 r3 $r7
cmp r3 98
je x8_case_529
cmp r3 66
jne x8_miss_522
label x8_case_529
mov r7 r8
add r7 r4
add r7 8
load8 r3 $r7
cmp r3 114
je x8_case_530
cmp r3 82
jne x8_miss_522
label x8_case_530
mov r7 r8
add r7 r4
add r7 9
load8 r3 $r7
cmp r3 111
je x8_case_531
cmp r3 79
jne x8_miss_522
label x8_case_531
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_auto_hit_521
label x8_miss_522
jmp x8_auto_term_520
label x8_auto_hit_521
set r0 0
mov r14 r0
mod r14 256
store8 9120000000000100016 r14
mov r14 r0
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_search
label x8_auto_term_520
mov r14 r10
mod r14 256
store8 9120000000000100016 r14
mov r14 r10
div r14 256
mod r14 256
store8 9120000000000100017 r14
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 14
cmp r6 r9
jgt x8_miss_534
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 100
je x8_case_535
cmp r3 68
jne x8_miss_534
label x8_case_535
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 105
je x8_case_536
cmp r3 73
jne x8_miss_534
label x8_case_536
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 114
je x8_case_537
cmp r3 82
jne x8_miss_534
label x8_case_537
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 105
je x8_case_538
cmp r3 73
jne x8_miss_534
label x8_case_538
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 97
je x8_case_539
cmp r3 65
jne x8_miss_534
label x8_case_539
mov r7 r8
add r7 r4
add r7 5
load8 r3 $r7
cmp r3 32
jne x8_miss_534
mov r7 r8
add r7 r4
add r7 6
load8 r3 $r7
cmp r3 101
je x8_case_540
cmp r3 69
jne x8_miss_534
label x8_case_540
mov r7 r8
add r7 r4
add r7 7
load8 r3 $r7
cmp r3 108
je x8_case_541
cmp r3 76
jne x8_miss_534
label x8_case_541
mov r7 r8
add r7 r4
add r7 8
load8 r3 $r7
cmp r3 32
jne x8_miss_534
mov r7 r8
add r7 r4
add r7 9
load8 r3 $r7
cmp r3 108
je x8_case_542
cmp r3 76
jne x8_miss_534
label x8_case_542
mov r7 r8
add r7 r4
add r7 10
load8 r3 $r7
cmp r3 105
je x8_case_543
cmp r3 73
jne x8_miss_534
label x8_case_543
mov r7 r8
add r7 r4
add r7 11
load8 r3 $r7
cmp r3 98
je x8_case_544
cmp r3 66
jne x8_miss_534
label x8_case_544
mov r7 r8
add r7 r4
add r7 12
load8 r3 $r7
cmp r3 114
je x8_case_545
cmp r3 82
jne x8_miss_534
label x8_case_545
mov r7 r8
add r7 r4
add r7 13
load8 r3 $r7
cmp r3 111
je x8_case_546
cmp r3 79
jne x8_miss_534
label x8_case_546
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_auto_hit_533
label x8_miss_534
jmp x8_auto_term_532
label x8_auto_hit_533
set r0 0
mov r14 r0
mod r14 256
store8 9120000000000100016 r14
mov r14 r0
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_search
label x8_auto_term_532
mov r14 r10
mod r14 256
store8 9120000000000100016 r14
mov r14 r10
div r14 256
mod r14 256
store8 9120000000000100017 r14
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 15
cmp r6 r9
jgt x8_miss_549
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 100
je x8_case_550
cmp r3 68
jne x8_miss_549
label x8_case_550
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 105
je x8_case_551
cmp r3 73
jne x8_miss_549
label x8_case_551
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 114
je x8_case_552
cmp r3 82
jne x8_miss_549
label x8_case_552
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 195
jne x8_miss_549
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 173
je x8_case_553
cmp r3 141
jne x8_miss_549
label x8_case_553
mov r7 r8
add r7 r4
add r7 5
load8 r3 $r7
cmp r3 97
je x8_case_554
cmp r3 65
jne x8_miss_549
label x8_case_554
mov r7 r8
add r7 r4
add r7 6
load8 r3 $r7
cmp r3 32
jne x8_miss_549
mov r7 r8
add r7 r4
add r7 7
load8 r3 $r7
cmp r3 101
je x8_case_555
cmp r3 69
jne x8_miss_549
label x8_case_555
mov r7 r8
add r7 r4
add r7 8
load8 r3 $r7
cmp r3 108
je x8_case_556
cmp r3 76
jne x8_miss_549
label x8_case_556
mov r7 r8
add r7 r4
add r7 9
load8 r3 $r7
cmp r3 32
jne x8_miss_549
mov r7 r8
add r7 r4
add r7 10
load8 r3 $r7
cmp r3 108
je x8_case_557
cmp r3 76
jne x8_miss_549
label x8_case_557
mov r7 r8
add r7 r4
add r7 11
load8 r3 $r7
cmp r3 105
je x8_case_558
cmp r3 73
jne x8_miss_549
label x8_case_558
mov r7 r8
add r7 r4
add r7 12
load8 r3 $r7
cmp r3 98
je x8_case_559
cmp r3 66
jne x8_miss_549
label x8_case_559
mov r7 r8
add r7 r4
add r7 13
load8 r3 $r7
cmp r3 114
je x8_case_560
cmp r3 82
jne x8_miss_549
label x8_case_560
mov r7 r8
add r7 r4
add r7 14
load8 r3 $r7
cmp r3 111
je x8_case_561
cmp r3 79
jne x8_miss_549
label x8_case_561
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_auto_hit_548
label x8_miss_549
jmp x8_auto_term_547
label x8_auto_hit_548
set r0 0
mov r14 r0
mod r14 256
store8 9120000000000100016 r14
mov r14 r0
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_search
label x8_auto_term_547
add r10 1
jmp x8_auto_query
label x8_code_normalize
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
mov r14 r4
mod r14 256
store8 9120000000000100360 r14
mov r14 r4
div r14 256
mod r14 256
store8 9120000000000100361 r14
set r0 37
mov r14 r0
mod r14 256
store8 9120000000000100202 r14
mov r14 r0
div r14 256
mod r14 256
store8 9120000000000100203 r14
store8 9120000000000112000 99
store8 9120000000000112001 114
store8 9120000000000112002 101
store8 9120000000000112003 97
store8 9120000000000112004 32
store8 9120000000000112005 121
store8 9120000000000112006 32
store8 9120000000000112007 101
store8 9120000000000112008 106
store8 9120000000000112009 101
store8 9120000000000112010 99
store8 9120000000000112011 117
store8 9120000000000112012 116
store8 9120000000000112013 97
store8 9120000000000112014 32
store8 9120000000000112015 117
store8 9120000000000112016 110
store8 9120000000000112017 32
store8 9120000000000112018 112
store8 9120000000000112019 114
store8 9120000000000112020 111
store8 9120000000000112021 103
store8 9120000000000112022 114
store8 9120000000000112023 97
store8 9120000000000112024 109
store8 9120000000000112025 97
store8 9120000000000112026 32
store8 9120000000000112027 101
store8 9120000000000112028 110
store8 9120000000000112029 32
store8 9120000000000112030 120
store8 9120000000000112031 105
store8 9120000000000112032 32
store8 9120000000000112033 113
store8 9120000000000112034 117
store8 9120000000000112035 101
store8 9120000000000112036 32
load8 r8 9120000000000100360
load8 r14 9120000000000100361
mul r14 256
add r8 r14
load8 r1 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r1 r14
sub r1 r8
add r8 9100000000000200256
load8 r12 9120000000000100100
cmp r12 16
jge x8_corrupt
mov r7 r12
mul r7 2
add r7 9120000000000103900
store8 $r7 1
add r7 1
store8 $r7 0
add r12 1
store8 9120000000000100100 r12
jmp x8_append
label x8_return_562
set r8 9120000000000112000
set r11 9100000000000200256
load8 r1 9120000000000100202
load8 r14 9120000000000100203
mul r14 256
add r1 r14
load8 r12 9120000000000100100
cmp r12 16
jge x8_corrupt
mov r7 r12
mul r7 2
add r7 9120000000000103900
store8 $r7 2
add r7 1
store8 $r7 0
add r12 1
store8 9120000000000100100 r12
jmp x8_copy_span
label x8_return_563
load8 r0 9120000000000100202
load8 r14 9120000000000100203
mul r14 256
add r0 r14
mov r14 r0
mod r14 256
store8 9100000000000200008 r14
mov r14 r0
div r14 256
mod r14 256
store8 9100000000000200009 r14
set r0 0
label x8_code_normalize_564
set r7 9120000000000100000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 49152
jlt x8_code_normalize_564
store8 9120000000000000002 0
store8 9100000000000200002 1
halt
label x8_to_en
store8 9120000000000100080 1
jmp x8_translate
label x8_to_es
store8 9120000000000100080 2
jmp x8_translate
label x8_grammar
store8 9120000000000100080 3
label x8_translate
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r0 r9
sub r0 r4
cmp r0 1
jlt x8_format
cmp r0 1024
jgt x8_text_limit
mov r14 r4
mod r14 256
store8 9120000000000100200 r14
mov r14 r4
div r14 256
mod r14 256
store8 9120000000000100201 r14
set r0 0
mov r14 r0
mod r14 256
store8 9120000000000100202 r14
mov r14 r0
div r14 256
mod r14 256
store8 9120000000000100203 r14
set r0 0
mov r14 r0
mod r14 256
store8 9120000000000100204 r14
mov r14 r0
div r14 256
mod r14 256
store8 9120000000000100205 r14
set r0 0
mov r14 r0
mod r14 256
store8 9120000000000100206 r14
mov r14 r0
div r14 256
mod r14 256
store8 9120000000000100207 r14
set r0 0
mov r14 r0
mod r14 256
store8 9120000000000100208 r14
mov r14 r0
div r14 256
mod r14 256
store8 9120000000000100209 r14
label x8_tr_next
load8 r4 9120000000000100200
load8 r14 9120000000000100201
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
cmp r4 r9
jge x8_tr_ready
set r7 9100000000000200256
add r7 r4
load8 r3 $r7
cmp r3 65
jlt x8_tr_symbol
cmp r3 90
jle x8_tr_word
cmp r3 97
jlt x8_tr_symbol
cmp r3 122
jle x8_tr_word
cmp r3 128
jge x8_tr_word
jmp x8_tr_symbol
label x8_tr_symbol
mov r8 r7
set r1 1
load8 r12 9120000000000100100
cmp r12 16
jge x8_corrupt
mov r7 r12
mul r7 2
add r7 9120000000000103900
store8 $r7 3
add r7 1
store8 $r7 0
add r12 1
store8 9120000000000100100 r12
jmp x8_append
label x8_return_565
load8 r4 9120000000000100200
load8 r14 9120000000000100201
mul r14 256
add r4 r14
add r4 1
mov r14 r4
mod r14 256
store8 9120000000000100200 r14
mov r14 r4
div r14 256
mod r14 256
store8 9120000000000100201 r14
jmp x8_tr_next
label x8_tr_word
set r0 0
mov r14 r0
mod r14 256
store8 9120000000000100210 r14
mov r14 r0
div r14 256
mod r14 256
store8 9120000000000100211 r14
set r0 0
mov r14 r0
mod r14 256
store8 9120000000000100212 r14
mov r14 r0
div r14 256
mod r14 256
store8 9120000000000100213 r14
set r0 0
mov r14 r0
mod r14 256
store8 9120000000000100214 r14
mov r14 r0
div r14 256
mod r14 256
store8 9120000000000100215 r14
set r10 0
label x8_tr_scan
load8 r0 9120000000000100208
load8 r14 9120000000000100209
mul r14 256
add r0 r14
add r0 1
cmp r0 10000
jgt x8_text_limit
mov r14 r0
mod r14 256
store8 9120000000000100208 r14
mov r14 r0
div r14 256
mod r14 256
store8 9120000000000100209 r14
load8 r11 601000002
load8 r14 601000003
mul r14 256
add r11 r14
cmp r10 r11
jge x8_tr_scanned
mov r13 r10
mul r13 256
add r13 601004096
mov r7 r13
add r7 0
load8 r0 $r7
load8 r1 9120000000000100080
cmp r1 3
je x8_tr_correction
cmp r0 1
jne x8_tr_record_next
cmp r1 2
je x8_tr_reverse
mov r7 r13
add r7 1
load8 r5 $r7
mov r7 r13
add r7 2
load8 r6 $r7
mov r8 r13
add r8 8
mov r11 r13
add r11 132
jmp x8_tr_candidate
label x8_tr_reverse
mov r7 r13
add r7 2
load8 r5 $r7
mov r7 r13
add r7 1
load8 r6 $r7
mov r8 r13
add r8 132
mov r11 r13
add r11 8
jmp x8_tr_candidate
label x8_tr_correction
cmp r0 3
jne x8_tr_record_next
mov r7 r13
add r7 1
load8 r5 $r7
mov r7 r13
add r7 2
load8 r6 $r7
mov r8 r13
add r8 8
mov r11 r13
add r11 132
label x8_tr_candidate
load8 r4 9120000000000100200
load8 r14 9120000000000100201
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r0 r4
add r0 r5
cmp r0 r9
jgt x8_tr_record_next
load8 r1 9120000000000100210
load8 r14 9120000000000100211
mul r14 256
add r1 r14
cmp r5 r1
jle x8_tr_record_next
set r2 0
label x8_tr_byte
cmp r2 r5
jge x8_tr_boundary
mov r7 r8
add r7 r2
load8 r1 $r7
mov r7 r4
add r7 r2
add r7 9100000000000200256
load8 r3 $r7
cmp r3 65
jlt x8_fold_566
cmp r3 90
jgt x8_fold_566
add r3 32
label x8_fold_566
cmp r1 65
jlt x8_fold_567
cmp r1 90
jgt x8_fold_567
add r1 32
label x8_fold_567
cmp r3 r1
jne x8_tr_record_next
add r2 1
jmp x8_tr_byte
label x8_tr_boundary
mov r0 r4
add r0 r5
cmp r0 r9
jge x8_tr_match
add r0 9100000000000200256
load8 r3 $r0
cmp r3 65
jlt x8_fold_568
cmp r3 90
jgt x8_fold_568
add r3 32
label x8_fold_568
cmp r3 97
jlt x8_tr_boundary_high
cmp r3 122
jle x8_tr_record_next
label x8_tr_boundary_high
cmp r3 128
jge x8_tr_record_next
label x8_tr_match
mov r14 r5
mod r14 256
store8 9120000000000100210 r14
mov r14 r5
div r14 256
mod r14 256
store8 9120000000000100211 r14
mov r14 r11
mod r14 256
store8 9120000000000100212 r14
mov r14 r11
div r14 256
mod r14 256
store8 9120000000000100213 r14
mov r14 r11
div r14 65536
mod r14 256
store8 9120000000000100214 r14
mov r14 r11
div r14 16777216
mod r14 256
store8 9120000000000100215 r14
mov r14 r11
div r14 4294967296
mod r14 256
store8 9120000000000100216 r14
mov r14 r11
div r14 1099511627776
mod r14 256
store8 9120000000000100217 r14
mov r14 r11
div r14 281474976710656
mod r14 256
store8 9120000000000100218 r14
mov r14 r11
div r14 72057594037927936
mod r14 256
store8 9120000000000100219 r14
mov r14 r6
mod r14 256
store8 9120000000000100220 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100221 r14
label x8_tr_record_next
add r10 1
jmp x8_tr_scan
label x8_tr_scanned
load8 r5 9120000000000100210
load8 r14 9120000000000100211
mul r14 256
add r5 r14
cmp r5 0
je x8_tr_unknown
load8 r8 9120000000000100212
load8 r14 9120000000000100213
mul r14 256
add r8 r14
load8 r14 9120000000000100214
mul r14 65536
add r8 r14
load8 r14 9120000000000100215
mul r14 16777216
add r8 r14
load8 r14 9120000000000100216
mul r14 4294967296
add r8 r14
load8 r14 9120000000000100217
mul r14 1099511627776
add r8 r14
load8 r14 9120000000000100218
mul r14 281474976710656
add r8 r14
load8 r14 9120000000000100219
mul r14 72057594037927936
add r8 r14
load8 r1 9120000000000100220
load8 r14 9120000000000100221
mul r14 256
add r1 r14
load8 r12 9120000000000100100
cmp r12 16
jge x8_corrupt
mov r7 r12
mul r7 2
add r7 9120000000000103900
store8 $r7 4
add r7 1
store8 $r7 0
add r12 1
store8 9120000000000100100 r12
jmp x8_append
label x8_return_569
load8 r4 9120000000000100200
load8 r14 9120000000000100201
mul r14 256
add r4 r14
load8 r5 9120000000000100210
load8 r14 9120000000000100211
mul r14 256
add r5 r14
add r4 r5
mov r14 r4
mod r14 256
store8 9120000000000100200 r14
mov r14 r4
div r14 256
mod r14 256
store8 9120000000000100201 r14
jmp x8_tr_next
label x8_tr_unknown
load8 r4 9120000000000100200
load8 r14 9120000000000100201
mul r14 256
add r4 r14
mov r14 r4
mod r14 256
store8 9120000000000100222 r14
mov r14 r4
div r14 256
mod r14 256
store8 9120000000000100223 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
label x8_tr_unknown_byte
cmp r4 r9
jge x8_tr_unknown_end
set r7 9100000000000200256
add r7 r4
load8 r3 $r7
cmp r3 65
jlt x8_fold_570
cmp r3 90
jgt x8_fold_570
add r3 32
label x8_fold_570
cmp r3 128
jge x8_tr_unknown_add
cmp r3 97
jlt x8_tr_unknown_end
cmp r3 122
jgt x8_tr_unknown_end
label x8_tr_unknown_add
add r4 1
jmp x8_tr_unknown_byte
label x8_tr_unknown_end
mov r14 r4
mod r14 256
store8 9120000000000100200 r14
mov r14 r4
div r14 256
mod r14 256
store8 9120000000000100201 r14
load8 r8 9120000000000100222
load8 r14 9120000000000100223
mul r14 256
add r8 r14
mov r1 r4
sub r1 r8
add r8 9100000000000200256
load8 r12 9120000000000100100
cmp r12 16
jge x8_corrupt
mov r7 r12
mul r7 2
add r7 9120000000000103900
store8 $r7 5
add r7 1
store8 $r7 0
add r12 1
store8 9120000000000100100 r12
jmp x8_append
label x8_return_571
load8 r0 9120000000000100080
cmp r0 3
je x8_tr_next
load8 r0 9120000000000100204
load8 r14 9120000000000100205
mul r14 256
add r0 r14
add r0 1
mov r14 r0
mod r14 256
store8 9120000000000100204 r14
mov r14 r0
div r14 256
mod r14 256
store8 9120000000000100205 r14
jmp x8_tr_next
label x8_tr_ready
load8 r0 9120000000000100080
cmp r0 3
je x8_grammar_ready
load8 r0 9120000000000100204
load8 r14 9120000000000100205
mul r14 256
add r0 r14
cmp r0 0
je x8_tr_complete
set r14 84
print r14
set r14 114
print r14
set r14 97
print r14
set r14 100
print r14
set r14 117
print r14
set r14 99
print r14
set r14 99
print r14
set r14 105
print r14
set r14 195
print r14
set r14 179
print r14
set r14 110
print r14
set r14 32
print r14
set r14 112
print r14
set r14 97
print r14
set r14 114
print r14
set r14 99
print r14
set r14 105
print r14
set r14 97
print r14
set r14 108
print r14
set r14 59
print r14
set r14 32
print r14
set r14 99
print r14
set r14 111
print r14
set r14 110
print r14
set r14 115
print r14
set r14 101
print r14
set r14 114
print r14
set r14 118
print r14
set r14 195
print r14
set r14 169
print r14
set r14 32
print r14
set r14 112
print r14
set r14 97
print r14
set r14 108
print r14
set r14 97
print r14
set r14 98
print r14
set r14 114
print r14
set r14 97
print r14
set r14 115
print r14
set r14 32
print r14
set r14 115
print r14
set r14 105
print r14
set r14 110
print r14
set r14 32
print r14
set r14 101
print r14
set r14 113
print r14
set r14 117
print r14
set r14 105
print r14
set r14 118
print r14
set r14 97
print r14
set r14 108
print r14
set r14 101
print r14
set r14 110
print r14
set r14 99
print r14
set r14 105
print r14
set r14 97
print r14
set r14 32
print r14
set r14 101
print r14
set r14 110
print r14
set r14 115
print r14
set r14 101
print r14
set r14 195
print r14
set r14 177
print r14
set r14 97
print r14
set r14 100
print r14
set r14 97
print r14
set r14 58
print r14
set r14 32
print r14
jmp x8_output
label x8_tr_complete
set r14 84
print r14
set r14 114
print r14
set r14 97
print r14
set r14 100
print r14
set r14 117
print r14
set r14 99
print r14
set r14 99
print r14
set r14 105
print r14
set r14 195
print r14
set r14 179
print r14
set r14 110
print r14
set r14 58
print r14
set r14 32
print r14
jmp x8_output
label x8_grammar_ready
set r14 67
print r14
set r14 111
print r14
set r14 114
print r14
set r14 114
print r14
set r14 101
print r14
set r14 99
print r14
set r14 99
print r14
set r14 105
print r14
set r14 195
print r14
set r14 179
print r14
set r14 110
print r14
set r14 32
print r14
set r14 112
print r14
set r14 111
print r14
set r14 114
print r14
set r14 32
print r14
set r14 114
print r14
set r14 101
print r14
set r14 103
print r14
set r14 108
print r14
set r14 97
print r14
set r14 115
print r14
set r14 32
print r14
set r14 101
print r14
set r14 110
print r14
set r14 115
print r14
set r14 101
print r14
set r14 195
print r14
set r14 177
print r14
set r14 97
print r14
set r14 100
print r14
set r14 97
print r14
set r14 115
print r14
set r14 58
print r14
set r14 32
print r14
jmp x8_output
label x8_teach_pair
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
mov r14 r4
mod r14 256
store8 9120000000000100230 r14
mov r14 r4
div r14 256
mod r14 256
store8 9120000000000100231 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
label x8_pair_divider
cmp r4 r9
jge x8_format
set r7 9100000000000200256
add r7 r4
load8 r3 $r7
cmp r3 124
je x8_pair_divided
add r4 1
jmp x8_pair_divider
label x8_pair_divided
mov r5 r4
sub r5 1
load8 r0 9120000000000100230
load8 r14 9120000000000100231
mul r14 256
add r0 r14
sub r5 r0
cmp r5 1
jlt x8_format
cmp r5 120
jgt x8_format
sub r7 1
load8 r3 $r7
cmp r3 32
jne x8_format
add r7 2
load8 r3 $r7
cmp r3 32
jne x8_format
add r4 2
mov r6 r9
sub r6 r4
cmp r6 1
jlt x8_format
cmp r6 120
jgt x8_format
mov r14 r4
mod r14 256
store8 9120000000000100232 r14
mov r14 r4
div r14 256
mod r14 256
store8 9120000000000100233 r14
mov r14 r5
mod r14 256
store8 9120000000000100234 r14
mov r14 r5
div r14 256
mod r14 256
store8 9120000000000100235 r14
mov r14 r6
mod r14 256
store8 9120000000000100236 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100237 r14
set r10 0
label x8_pair_find
load8 r11 601000002
load8 r14 601000003
mul r14 256
add r11 r14
cmp r10 r11
jge x8_pair_insert
mov r13 r10
mul r13 256
add r13 601004096
mov r7 r13
add r7 0
load8 r0 $r7
cmp r0 1
jne x8_pair_next
mov r7 r13
add r7 1
load8 r0 $r7
load8 r5 9120000000000100234
load8 r14 9120000000000100235
mul r14 256
add r5 r14
cmp r0 r5
jne x8_pair_next
set r2 0
load8 r4 9120000000000100230
load8 r14 9120000000000100231
mul r14 256
add r4 r14
label x8_pair_compare
cmp r2 r5
jge x8_pair_existing
mov r7 r13
add r7 8
add r7 r2
load8 r1 $r7
mov r7 r4
add r7 r2
add r7 9100000000000200256
load8 r3 $r7
cmp r1 65
jlt x8_fold_572
cmp r1 90
jgt x8_fold_572
add r1 32
label x8_fold_572
cmp r3 65
jlt x8_fold_573
cmp r3 90
jgt x8_fold_573
add r3 32
label x8_fold_573
cmp r1 r3
jne x8_pair_next
add r2 1
jmp x8_pair_compare
label x8_pair_next
add r10 1
jmp x8_pair_find
label x8_pair_existing
mov r7 r13
add r7 2
load8 r0 $r7
load8 r6 9120000000000100236
load8 r14 9120000000000100237
mul r14 256
add r6 r14
cmp r0 r6
jne x8_pair_conflict
set r2 0
load8 r4 9120000000000100232
load8 r14 9120000000000100233
mul r14 256
add r4 r14
label x8_pair_same
cmp r2 r6
jge x8_pair_idempotent
mov r7 r13
add r7 132
add r7 r2
load8 r1 $r7
mov r7 r4
add r7 r2
add r7 9100000000000200256
load8 r3 $r7
cmp r1 r3
jne x8_pair_conflict
add r2 1
jmp x8_pair_same
label x8_pair_insert
cmp r11 2048
jge x8_pair_full
mov r13 r11
mul r13 256
add r13 601004096
store8 $r13 1
load8 r5 9120000000000100234
load8 r14 9120000000000100235
mul r14 256
add r5 r14
mov r7 r13
add r7 1
mov r14 r5
mod r14 256
store8 $r7 r14
load8 r6 9120000000000100236
load8 r14 9120000000000100237
mul r14 256
add r6 r14
mov r7 r13
add r7 2
mov r14 r6
mod r14 256
store8 $r7 r14
load8 r8 9120000000000100230
load8 r14 9120000000000100231
mul r14 256
add r8 r14
add r8 9100000000000200256
load8 r1 9120000000000100234
load8 r14 9120000000000100235
mul r14 256
add r1 r14
mov r11 r13
add r11 8
load8 r12 9120000000000100100
cmp r12 16
jge x8_corrupt
mov r7 r12
mul r7 2
add r7 9120000000000103900
store8 $r7 6
add r7 1
store8 $r7 0
add r12 1
store8 9120000000000100100 r12
jmp x8_copy_span
label x8_return_574
load8 r8 9120000000000100232
load8 r14 9120000000000100233
mul r14 256
add r8 r14
add r8 9100000000000200256
load8 r1 9120000000000100236
load8 r14 9120000000000100237
mul r14 256
add r1 r14
mov r11 r13
add r11 132
load8 r12 9120000000000100100
cmp r12 16
jge x8_corrupt
mov r7 r12
mul r7 2
add r7 9120000000000103900
store8 $r7 7
add r7 1
store8 $r7 0
add r12 1
store8 9120000000000100100 r12
jmp x8_copy_span
label x8_return_575
load8 r0 601000002
load8 r14 601000003
mul r14 256
add r0 r14
add r0 1
mov r14 r0
mod r14 256
store8 601000002 r14
mov r14 r0
div r14 256
mod r14 256
store8 601000003 r14
label x8_pair_idempotent
set r14 69
print r14
set r14 113
print r14
set r14 117
print r14
set r14 105
print r14
set r14 118
print r14
set r14 97
print r14
set r14 108
print r14
set r14 101
print r14
set r14 110
print r14
set r14 99
print r14
set r14 105
print r14
set r14 97
print r14
set r14 32
print r14
set r14 105
print r14
set r14 110
print r14
set r14 99
print r14
set r14 111
print r14
set r14 114
print r14
set r14 112
print r14
set r14 111
print r14
set r14 114
print r14
set r14 97
print r14
set r14 100
print r14
set r14 97
print r14
set r14 46
print r14
jmp x8_done
label x8_pair_conflict
set r14 78
print r14
set r14 111
print r14
set r14 32
print r14
set r14 99
print r14
set r14 97
print r14
set r14 109
print r14
set r14 98
print r14
set r14 105
print r14
set r14 195
print r14
set r14 169
print r14
set r14 32
print r14
set r14 108
print r14
set r14 97
print r14
set r14 32
print r14
set r14 101
print r14
set r14 113
print r14
set r14 117
print r14
set r14 105
print r14
set r14 118
print r14
set r14 97
print r14
set r14 108
print r14
set r14 101
print r14
set r14 110
print r14
set r14 99
print r14
set r14 105
print r14
set r14 97
print r14
set r14 58
print r14
set r14 32
print r14
set r14 121
print r14
set r14 97
print r14
set r14 32
print r14
set r14 101
print r14
set r14 120
print r14
set r14 105
print r14
set r14 115
print r14
set r14 116
print r14
set r14 101
print r14
set r14 32
print r14
set r14 111
print r14
set r14 116
print r14
set r14 114
print r14
set r14 97
print r14
set r14 32
print r14
set r14 116
print r14
set r14 114
print r14
set r14 97
print r14
set r14 100
print r14
set r14 117
print r14
set r14 99
print r14
set r14 99
print r14
set r14 105
print r14
set r14 195
print r14
set r14 179
print r14
set r14 110
print r14
set r14 32
print r14
set r14 112
print r14
set r14 97
print r14
set r14 114
print r14
set r14 97
print r14
set r14 32
print r14
set r14 101
print r14
set r14 115
print r14
set r14 97
print r14
set r14 32
print r14
set r14 102
print r14
set r14 114
print r14
set r14 97
print r14
set r14 115
print r14
set r14 101
print r14
set r14 46
print r14
jmp x8_done
label x8_pair_full
set r14 78
print r14
set r14 111
print r14
set r14 32
print r14
set r14 99
print r14
set r14 97
print r14
set r14 109
print r14
set r14 98
print r14
set r14 105
print r14
set r14 195
print r14
set r14 169
print r14
set r14 32
print r14
set r14 101
print r14
set r14 108
print r14
set r14 32
print r14
set r14 100
print r14
set r14 105
print r14
set r14 99
print r14
set r14 99
print r14
set r14 105
print r14
set r14 111
print r14
set r14 110
print r14
set r14 97
print r14
set r14 114
print r14
set r14 105
print r14
set r14 111
print r14
set r14 58
print r14
set r14 32
print r14
set r14 99
print r14
set r14 97
print r14
set r14 112
print r14
set r14 97
print r14
set r14 99
print r14
set r14 105
print r14
set r14 100
print r14
set r14 97
print r14
set r14 100
print r14
set r14 32
print r14
set r14 97
print r14
set r14 103
print r14
set r14 111
print r14
set r14 116
print r14
set r14 97
print r14
set r14 100
print r14
set r14 97
print r14
set r14 46
print r14
jmp x8_done
label x8_summary_count
load8 r12 9120000000000100100
cmp r12 16
jge x8_corrupt
mov r7 r12
mul r7 2
add r7 9120000000000103900
store8 $r7 8
add r7 1
store8 $r7 0
add r12 1
store8 9120000000000100100 r12
jmp x8_number
label x8_return_576
cmp r0 1
jlt x8_format
cmp r0 8
jgt x8_format
mov r14 r0
mod r14 256
store8 9120000000000100250 r14
mov r14 r0
div r14 256
mod r14 256
store8 9120000000000100251 r14
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 10
cmp r6 r9
jgt x8_miss_578
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 32
jne x8_miss_578
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 102
je x8_case_579
cmp r3 70
jne x8_miss_578
label x8_case_579
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 114
je x8_case_580
cmp r3 82
jne x8_miss_578
label x8_case_580
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 97
je x8_case_581
cmp r3 65
jne x8_miss_578
label x8_case_581
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 115
je x8_case_582
cmp r3 83
jne x8_miss_578
label x8_case_582
mov r7 r8
add r7 r4
add r7 5
load8 r3 $r7
cmp r3 101
je x8_case_583
cmp r3 69
jne x8_miss_578
label x8_case_583
mov r7 r8
add r7 r4
add r7 6
load8 r3 $r7
cmp r3 115
je x8_case_584
cmp r3 83
jne x8_miss_578
label x8_case_584
mov r7 r8
add r7 r4
add r7 7
load8 r3 $r7
cmp r3 58
jne x8_miss_578
mov r7 r8
add r7 r4
add r7 8
load8 r3 $r7
cmp r3 13
jne x8_miss_578
mov r7 r8
add r7 r4
add r7 9
load8 r3 $r7
cmp r3 10
jne x8_miss_578
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_consume_577
label x8_miss_578
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 9
cmp r6 r9
jgt x8_miss_585
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 32
jne x8_miss_585
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 102
je x8_case_586
cmp r3 70
jne x8_miss_585
label x8_case_586
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 114
je x8_case_587
cmp r3 82
jne x8_miss_585
label x8_case_587
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 97
je x8_case_588
cmp r3 65
jne x8_miss_585
label x8_case_588
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 115
je x8_case_589
cmp r3 83
jne x8_miss_585
label x8_case_589
mov r7 r8
add r7 r4
add r7 5
load8 r3 $r7
cmp r3 101
je x8_case_590
cmp r3 69
jne x8_miss_585
label x8_case_590
mov r7 r8
add r7 r4
add r7 6
load8 r3 $r7
cmp r3 115
je x8_case_591
cmp r3 83
jne x8_miss_585
label x8_case_591
mov r7 r8
add r7 r4
add r7 7
load8 r3 $r7
cmp r3 58
jne x8_miss_585
mov r7 r8
add r7 r4
add r7 8
load8 r3 $r7
cmp r3 10
jne x8_miss_585
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_consume_577
label x8_miss_585
jmp x8_format
label x8_consume_577
jmp x8_summary_begin
label x8_summary
set r0 3
mov r14 r0
mod r14 256
store8 9120000000000100250 r14
mov r14 r0
div r14 256
mod r14 256
store8 9120000000000100251 r14
label x8_summary_begin
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r14 r4
mod r14 256
store8 9120000000000100252 r14
mov r14 r4
div r14 256
mod r14 256
store8 9120000000000100253 r14
cmp r4 r9
jge x8_format
set r5 0
label x8_summary_scan
cmp r4 r9
jge x8_summary_end
set r7 9100000000000200256
add r7 r4
load8 r3 $r7
add r4 1
cmp r3 33
je x8_summary_boundary
cmp r3 63
je x8_summary_boundary
cmp r3 46
jne x8_summary_scan
cmp r4 2
jlt x8_summary_boundary
cmp r4 r9
jge x8_summary_boundary
sub r7 1
load8 r2 $r7
add r7 2
load8 r3 $r7
cmp r2 48
jlt x8_summary_boundary
cmp r2 57
jgt x8_summary_boundary
cmp r3 48
jlt x8_summary_boundary
cmp r3 57
jle x8_summary_scan
label x8_summary_boundary
cmp r4 r9
jge x8_summary_sentence
set r7 9100000000000200256
add r7 r4
load8 r3 $r7
cmp r3 32
jgt x8_summary_scan
label x8_summary_sentence
add r5 1
load8 r0 9120000000000100250
load8 r14 9120000000000100251
mul r14 256
add r0 r14
cmp r5 r0
jlt x8_summary_scan
label x8_summary_end
mov r14 r4
mod r14 256
store8 9120000000000100254 r14
mov r14 r4
div r14 256
mod r14 256
store8 9120000000000100255 r14
set r14 82
print r14
set r14 101
print r14
set r14 115
print r14
set r14 117
print r14
set r14 109
print r14
set r14 101
print r14
set r14 110
print r14
set r14 32
print r14
set r14 101
print r14
set r14 120
print r14
set r14 116
print r14
set r14 114
print r14
set r14 97
print r14
set r14 99
print r14
set r14 116
print r14
set r14 105
print r14
set r14 118
print r14
set r14 111
print r14
set r14 58
print r14
set r14 32
print r14
load8 r8 9120000000000100252
load8 r14 9120000000000100253
mul r14 256
add r8 r14
load8 r1 9120000000000100254
load8 r14 9120000000000100255
mul r14 256
add r1 r14
sub r1 r8
add r8 9100000000000200256
set r0 0
label x8_emit_592
cmp r0 r1
jge x8_emitted_593
mov r7 r8
add r7 r0
load8 r14 $r7
print r14
add r0 1
jmp x8_emit_592
label x8_emitted_593
jmp x8_done
label x8_compare
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 3
cmp r6 r9
jgt x8_miss_595
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 65
jne x8_miss_595
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 58
jne x8_miss_595
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 32
jne x8_miss_595
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_consume_594
label x8_miss_595
jmp x8_format
label x8_consume_594
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
mov r14 r4
mod r14 256
store8 9120000000000100260 r14
mov r14 r4
div r14 256
mod r14 256
store8 9120000000000100261 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
label x8_compare_divider
mov r0 r4
add r0 4
cmp r0 r9
jgt x8_format
set r7 9100000000000200256
add r7 r4
load8 r3 $r7
cmp r3 10
jne x8_compare_divider_next
add r7 1
load8 r3 $r7
cmp r3 66
jne x8_compare_divider_next
add r7 1
load8 r3 $r7
cmp r3 58
jne x8_compare_divider_next
add r7 1
load8 r3 $r7
cmp r3 32
je x8_compare_split
label x8_compare_divider_next
add r4 1
jmp x8_compare_divider
label x8_compare_split
mov r14 r4
mod r14 256
store8 9120000000000100262 r14
mov r14 r4
div r14 256
mod r14 256
store8 9120000000000100263 r14
add r4 4
mov r14 r4
mod r14 256
store8 9120000000000100264 r14
mov r14 r4
div r14 256
mod r14 256
store8 9120000000000100265 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r14 r9
mod r14 256
store8 9120000000000100266 r14
mov r14 r9
div r14 256
mod r14 256
store8 9120000000000100267 r14
load8 r0 9120000000000100262
load8 r14 9120000000000100263
mul r14 256
add r0 r14
load8 r1 9120000000000100260
load8 r14 9120000000000100261
mul r14 256
add r1 r14
sub r0 r1
cmp r0 1
jlt x8_format
cmp r0 1024
jgt x8_text_limit
mov r0 r9
sub r0 r4
cmp r0 1
jlt x8_format
cmp r0 1024
jgt x8_text_limit
set r0 0
mov r14 r0
mod r14 256
store8 9120000000000100276 r14
mov r14 r0
div r14 256
mod r14 256
store8 9120000000000100277 r14
set r14 67
print r14
set r14 111
print r14
set r14 109
print r14
set r14 112
print r14
set r14 97
print r14
set r14 114
print r14
set r14 97
print r14
set r14 99
print r14
set r14 105
print r14
set r14 195
print r14
set r14 179
print r14
set r14 110
print r14
set r14 32
print r14
set r14 108
print r14
set r14 195
print r14
set r14 169
print r14
set r14 120
print r14
set r14 105
print r14
set r14 99
print r14
set r14 97
print r14
set r14 32
print r14
set r14 100
print r14
set r14 101
print r14
set r14 32
print r14
set r14 108
print r14
set r14 111
print r14
set r14 115
print r14
set r14 32
print r14
set r14 116
print r14
set r14 101
print r14
set r14 120
print r14
set r14 116
print r14
set r14 111
print r14
set r14 115
print r14
set r14 32
print r14
set r14 112
print r14
set r14 114
print r14
set r14 111
print r14
set r14 112
print r14
set r14 111
print r14
set r14 114
print r14
set r14 99
print r14
set r14 105
print r14
set r14 111
print r14
set r14 110
print r14
set r14 97
print r14
set r14 100
print r14
set r14 111
print r14
set r14 115
print r14
set r14 46
print r14
set r14 10
print r14
set r14 91
print r14
set r14 65
print r14
set r14 93
print r14
set r14 32
print r14
load8 r8 9120000000000100260
load8 r14 9120000000000100261
mul r14 256
add r8 r14
load8 r1 9120000000000100262
load8 r14 9120000000000100263
mul r14 256
add r1 r14
sub r1 r8
add r8 9100000000000200256
set r0 0
label x8_emit_596
cmp r0 r1
jge x8_emitted_597
mov r7 r8
add r7 r0
load8 r14 $r7
print r14
add r0 1
jmp x8_emit_596
label x8_emitted_597
set r14 10
print r14
set r14 91
print r14
set r14 66
print r14
set r14 93
print r14
set r14 32
print r14
load8 r8 9120000000000100264
load8 r14 9120000000000100265
mul r14 256
add r8 r14
load8 r1 9120000000000100266
load8 r14 9120000000000100267
mul r14 256
add r1 r14
sub r1 r8
add r8 9100000000000200256
set r0 0
label x8_emit_598
cmp r0 r1
jge x8_emitted_599
mov r7 r8
add r7 r0
load8 r14 $r7
print r14
add r0 1
jmp x8_emit_598
label x8_emitted_599
set r14 10
print r14
set r14 80
print r14
set r14 97
print r14
set r14 108
print r14
set r14 97
print r14
set r14 98
print r14
set r14 114
print r14
set r14 97
print r14
set r14 115
print r14
set r14 32
print r14
set r14 99
print r14
set r14 111
print r14
set r14 109
print r14
set r14 112
print r14
set r14 97
print r14
set r14 114
print r14
set r14 116
print r14
set r14 105
print r14
set r14 100
print r14
set r14 97
print r14
set r14 115
print r14
set r14 58
print r14
set r14 32
print r14
set r0 0
mov r14 r0
mod r14 256
store8 9120000000000100268 r14
mov r14 r0
div r14 256
mod r14 256
store8 9120000000000100269 r14
load8 r4 9120000000000100260
load8 r14 9120000000000100261
mul r14 256
add r4 r14
mov r14 r4
mod r14 256
store8 9120000000000100270 r14
mov r14 r4
div r14 256
mod r14 256
store8 9120000000000100271 r14
label x8_compare_token
load8 r4 9120000000000100270
load8 r14 9120000000000100271
mul r14 256
add r4 r14
load8 r9 9120000000000100262
load8 r14 9120000000000100263
mul r14 256
add r9 r14
cmp r4 r9
jge x8_compare_end
set r7 9100000000000200256
add r7 r4
load8 r3 $r7
cmp r3 65
jlt x8_fold_600
cmp r3 90
jgt x8_fold_600
add r3 32
label x8_fold_600
cmp r3 128
jge x8_cmp_word_start
cmp r3 95
je x8_cmp_word_start
cmp r3 48
jlt x8_compare_skip
cmp r3 57
jle x8_cmp_word_start
cmp r3 97
jlt x8_compare_skip
cmp r3 122
jgt x8_compare_skip
label x8_cmp_word_start
mov r14 r4
mod r14 256
store8 9120000000000100272 r14
mov r14 r4
div r14 256
mod r14 256
store8 9120000000000100273 r14
label x8_compare_token_end
add r4 1
cmp r4 r9
jge x8_compare_token_ready
set r7 9100000000000200256
add r7 r4
load8 r3 $r7
cmp r3 65
jlt x8_fold_601
cmp r3 90
jgt x8_fold_601
add r3 32
label x8_fold_601
cmp r3 128
jge x8_compare_token_end
cmp r3 95
je x8_compare_token_end
cmp r3 48
jlt x8_compare_token_ready
cmp r3 57
jle x8_compare_token_end
cmp r3 97
jlt x8_compare_token_ready
cmp r3 122
jle x8_compare_token_end
label x8_compare_token_ready
mov r14 r4
mod r14 256
store8 9120000000000100270 r14
mov r14 r4
div r14 256
mod r14 256
store8 9120000000000100271 r14
load8 r5 9120000000000100272
load8 r14 9120000000000100273
mul r14 256
add r5 r14
sub r4 r5
cmp r4 4
jlt x8_compare_token
mov r14 r4
mod r14 256
store8 9120000000000100274 r14
mov r14 r4
div r14 256
mod r14 256
store8 9120000000000100275 r14
load8 r6 9120000000000100264
load8 r14 9120000000000100265
mul r14 256
add r6 r14
label x8_compare_find
load8 r9 9120000000000100266
load8 r14 9120000000000100267
mul r14 256
add r9 r14
load8 r5 9120000000000100274
load8 r14 9120000000000100275
mul r14 256
add r5 r14
mov r0 r6
add r0 r5
cmp r0 r9
jgt x8_compare_token
set r2 0
label x8_compare_find_byte
load8 r0 9120000000000100276
load8 r14 9120000000000100277
mul r14 256
add r0 r14
add r0 1
cmp r0 12000
jgt x8_compare_limit
mov r14 r0
mod r14 256
store8 9120000000000100276 r14
mov r14 r0
div r14 256
mod r14 256
store8 9120000000000100277 r14
cmp r2 r5
jge x8_compare_found
mov r7 r6
add r7 r2
add r7 9100000000000200256
load8 r3 $r7
cmp r3 65
jlt x8_fold_602
cmp r3 90
jgt x8_fold_602
add r3 32
label x8_fold_602
load8 r4 9120000000000100272
load8 r14 9120000000000100273
mul r14 256
add r4 r14
mov r7 r4
add r7 r2
add r7 9100000000000200256
load8 r1 $r7
cmp r1 65
jlt x8_fold_603
cmp r1 90
jgt x8_fold_603
add r1 32
label x8_fold_603
cmp r1 r3
jne x8_compare_find_next
add r2 1
jmp x8_compare_find_byte
label x8_compare_find_next
add r6 1
jmp x8_compare_find
label x8_compare_found
load8 r0 9120000000000100264
load8 r14 9120000000000100265
mul r14 256
add r0 r14
cmp r6 r0
je x8_cmp_start_ok
mov r7 r6
sub r7 1
add r7 9100000000000200256
load8 r3 $r7
cmp r3 65
jlt x8_fold_604
cmp r3 90
jgt x8_fold_604
add r3 32
label x8_fold_604
cmp r3 128
jge x8_compare_find_next
cmp r3 95
je x8_compare_find_next
cmp r3 48
jlt x8_cmp_start_ok
cmp r3 57
jle x8_compare_find_next
cmp r3 97
jlt x8_cmp_start_ok
cmp r3 122
jle x8_compare_find_next
label x8_cmp_start_ok
load8 r5 9120000000000100274
load8 r14 9120000000000100275
mul r14 256
add r5 r14
load8 r9 9120000000000100266
load8 r14 9120000000000100267
mul r14 256
add r9 r14
mov r7 r6
add r7 r5
cmp r7 r9
jge x8_cmp_end_ok
add r7 9100000000000200256
load8 r3 $r7
cmp r3 65
jlt x8_fold_605
cmp r3 90
jgt x8_fold_605
add r3 32
label x8_fold_605
cmp r3 128
jge x8_compare_find_next
cmp r3 95
je x8_compare_find_next
cmp r3 48
jlt x8_cmp_end_ok
cmp r3 57
jle x8_compare_find_next
cmp r3 97
jlt x8_cmp_end_ok
cmp r3 122
jle x8_compare_find_next
label x8_cmp_end_ok
load8 r0 9120000000000100268
load8 r14 9120000000000100269
mul r14 256
add r0 r14
cmp r0 0
je x8_compare_first
set r14 44
print r14
set r14 32
print r14
label x8_compare_first
load8 r8 9120000000000100272
load8 r14 9120000000000100273
mul r14 256
add r8 r14
load8 r1 9120000000000100274
load8 r14 9120000000000100275
mul r14 256
add r1 r14
add r8 9100000000000200256
set r0 0
label x8_emit_606
cmp r0 r1
jge x8_emitted_607
mov r7 r8
add r7 r0
load8 r14 $r7
print r14
add r0 1
jmp x8_emit_606
label x8_emitted_607
load8 r0 9120000000000100268
load8 r14 9120000000000100269
mul r14 256
add r0 r14
add r0 1
mov r14 r0
mod r14 256
store8 9120000000000100268 r14
mov r14 r0
div r14 256
mod r14 256
store8 9120000000000100269 r14
cmp r0 12
jge x8_compare_end
jmp x8_compare_token
label x8_compare_skip
add r4 1
mov r14 r4
mod r14 256
store8 9120000000000100270 r14
mov r14 r4
div r14 256
mod r14 256
store8 9120000000000100271 r14
jmp x8_compare_token
label x8_compare_end
load8 r0 9120000000000100268
load8 r14 9120000000000100269
mul r14 256
add r0 r14
cmp r0 0
jne x8_compare_note
set r14 110
print r14
set r14 105
print r14
set r14 110
print r14
set r14 103
print r14
set r14 117
print r14
set r14 110
print r14
set r14 97
print r14
set r14 32
print r14
set r14 99
print r14
set r14 111
print r14
set r14 105
print r14
set r14 110
print r14
set r14 99
print r14
set r14 105
print r14
set r14 100
print r14
set r14 101
print r14
set r14 110
print r14
set r14 99
print r14
set r14 105
print r14
set r14 97
print r14
label x8_compare_note
set r14 46
print r14
set r14 10
print r14
set r14 76
print r14
set r14 97
print r14
set r14 115
print r14
set r14 32
print r14
set r14 99
print r14
set r14 111
print r14
set r14 105
print r14
set r14 110
print r14
set r14 99
print r14
set r14 105
print r14
set r14 100
print r14
set r14 101
print r14
set r14 110
print r14
set r14 99
print r14
set r14 105
print r14
set r14 97
print r14
set r14 115
print r14
set r14 32
print r14
set r14 100
print r14
set r14 101
print r14
set r14 32
print r14
set r14 112
print r14
set r14 97
print r14
set r14 108
print r14
set r14 97
print r14
set r14 98
print r14
set r14 114
print r14
set r14 97
print r14
set r14 115
print r14
set r14 32
print r14
set r14 110
print r14
set r14 111
print r14
set r14 32
print r14
set r14 100
print r14
set r14 101
print r14
set r14 109
print r14
set r14 117
print r14
set r14 101
print r14
set r14 115
print r14
set r14 116
print r14
set r14 114
print r14
set r14 97
print r14
set r14 110
print r14
set r14 32
print r14
set r14 101
print r14
set r14 113
print r14
set r14 117
print r14
set r14 105
print r14
set r14 118
print r14
set r14 97
print r14
set r14 108
print r14
set r14 101
print r14
set r14 110
print r14
set r14 99
print r14
set r14 105
print r14
set r14 97
print r14
set r14 32
print r14
set r14 100
print r14
set r14 101
print r14
set r14 32
print r14
set r14 115
print r14
set r14 105
print r14
set r14 103
print r14
set r14 110
print r14
set r14 105
print r14
set r14 102
print r14
set r14 105
print r14
set r14 99
print r14
set r14 97
print r14
set r14 100
print r14
set r14 111
print r14
set r14 46
print r14
jmp x8_done
label x8_mail
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 14
cmp r6 r9
jgt x8_miss_609
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 100
je x8_case_610
cmp r3 68
jne x8_miss_609
label x8_case_610
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 101
je x8_case_611
cmp r3 69
jne x8_miss_609
label x8_case_611
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 115
je x8_case_612
cmp r3 83
jne x8_miss_609
label x8_case_612
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 116
je x8_case_613
cmp r3 84
jne x8_miss_609
label x8_case_613
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 105
je x8_case_614
cmp r3 73
jne x8_miss_609
label x8_case_614
mov r7 r8
add r7 r4
add r7 5
load8 r3 $r7
cmp r3 110
je x8_case_615
cmp r3 78
jne x8_miss_609
label x8_case_615
mov r7 r8
add r7 r4
add r7 6
load8 r3 $r7
cmp r3 97
je x8_case_616
cmp r3 65
jne x8_miss_609
label x8_case_616
mov r7 r8
add r7 r4
add r7 7
load8 r3 $r7
cmp r3 116
je x8_case_617
cmp r3 84
jne x8_miss_609
label x8_case_617
mov r7 r8
add r7 r4
add r7 8
load8 r3 $r7
cmp r3 97
je x8_case_618
cmp r3 65
jne x8_miss_609
label x8_case_618
mov r7 r8
add r7 r4
add r7 9
load8 r3 $r7
cmp r3 114
je x8_case_619
cmp r3 82
jne x8_miss_609
label x8_case_619
mov r7 r8
add r7 r4
add r7 10
load8 r3 $r7
cmp r3 105
je x8_case_620
cmp r3 73
jne x8_miss_609
label x8_case_620
mov r7 r8
add r7 r4
add r7 11
load8 r3 $r7
cmp r3 111
je x8_case_621
cmp r3 79
jne x8_miss_609
label x8_case_621
mov r7 r8
add r7 r4
add r7 12
load8 r3 $r7
cmp r3 58
jne x8_miss_609
mov r7 r8
add r7 r4
add r7 13
load8 r3 $r7
cmp r3 32
jne x8_miss_609
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_consume_608
label x8_miss_609
jmp x8_format
label x8_consume_608
load8 r12 9120000000000100100
cmp r12 16
jge x8_corrupt
mov r7 r12
mul r7 2
add r7 9120000000000103900
store8 $r7 9
add r7 1
store8 $r7 0
add r12 1
store8 9120000000000100100 r12
jmp x8_line
label x8_return_622
mov r14 r8
mod r14 256
store8 9120000000000100280 r14
mov r14 r8
div r14 256
mod r14 256
store8 9120000000000100281 r14
mov r14 r1
mod r14 256
store8 9120000000000100282 r14
mov r14 r1
div r14 256
mod r14 256
store8 9120000000000100283 r14
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 8
cmp r6 r9
jgt x8_miss_624
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 97
je x8_case_625
cmp r3 65
jne x8_miss_624
label x8_case_625
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 115
je x8_case_626
cmp r3 83
jne x8_miss_624
label x8_case_626
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 117
je x8_case_627
cmp r3 85
jne x8_miss_624
label x8_case_627
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 110
je x8_case_628
cmp r3 78
jne x8_miss_624
label x8_case_628
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 116
je x8_case_629
cmp r3 84
jne x8_miss_624
label x8_case_629
mov r7 r8
add r7 r4
add r7 5
load8 r3 $r7
cmp r3 111
je x8_case_630
cmp r3 79
jne x8_miss_624
label x8_case_630
mov r7 r8
add r7 r4
add r7 6
load8 r3 $r7
cmp r3 58
jne x8_miss_624
mov r7 r8
add r7 r4
add r7 7
load8 r3 $r7
cmp r3 32
jne x8_miss_624
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_consume_623
label x8_miss_624
jmp x8_format
label x8_consume_623
load8 r12 9120000000000100100
cmp r12 16
jge x8_corrupt
mov r7 r12
mul r7 2
add r7 9120000000000103900
store8 $r7 10
add r7 1
store8 $r7 0
add r12 1
store8 9120000000000100100 r12
jmp x8_line
label x8_return_631
mov r14 r8
mod r14 256
store8 9120000000000100284 r14
mov r14 r8
div r14 256
mod r14 256
store8 9120000000000100285 r14
mov r14 r1
mod r14 256
store8 9120000000000100286 r14
mov r14 r1
div r14 256
mod r14 256
store8 9120000000000100287 r14
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 11
cmp r6 r9
jgt x8_miss_633
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 99
je x8_case_634
cmp r3 67
jne x8_miss_633
label x8_case_634
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 111
je x8_case_635
cmp r3 79
jne x8_miss_633
label x8_case_635
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 110
je x8_case_636
cmp r3 78
jne x8_miss_633
label x8_case_636
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 116
je x8_case_637
cmp r3 84
jne x8_miss_633
label x8_case_637
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 101
je x8_case_638
cmp r3 69
jne x8_miss_633
label x8_case_638
mov r7 r8
add r7 r4
add r7 5
load8 r3 $r7
cmp r3 110
je x8_case_639
cmp r3 78
jne x8_miss_633
label x8_case_639
mov r7 r8
add r7 r4
add r7 6
load8 r3 $r7
cmp r3 105
je x8_case_640
cmp r3 73
jne x8_miss_633
label x8_case_640
mov r7 r8
add r7 r4
add r7 7
load8 r3 $r7
cmp r3 100
je x8_case_641
cmp r3 68
jne x8_miss_633
label x8_case_641
mov r7 r8
add r7 r4
add r7 8
load8 r3 $r7
cmp r3 111
je x8_case_642
cmp r3 79
jne x8_miss_633
label x8_case_642
mov r7 r8
add r7 r4
add r7 9
load8 r3 $r7
cmp r3 58
jne x8_miss_633
mov r7 r8
add r7 r4
add r7 10
load8 r3 $r7
cmp r3 32
jne x8_miss_633
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_consume_632
label x8_miss_633
jmp x8_format
label x8_consume_632
load8 r12 9120000000000100100
cmp r12 16
jge x8_corrupt
mov r7 r12
mul r7 2
add r7 9120000000000103900
store8 $r7 11
add r7 1
store8 $r7 0
add r12 1
store8 9120000000000100100 r12
jmp x8_line
label x8_return_643
mov r14 r8
mod r14 256
store8 9120000000000100288 r14
mov r14 r8
div r14 256
mod r14 256
store8 9120000000000100289 r14
mov r14 r1
mod r14 256
store8 9120000000000100290 r14
mov r14 r1
div r14 256
mod r14 256
store8 9120000000000100291 r14
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r6 r4
add r6 7
cmp r6 r9
jgt x8_miss_645
set r8 9100000000000200256
mov r7 r8
add r7 r4
add r7 0
load8 r3 $r7
cmp r3 102
je x8_case_646
cmp r3 70
jne x8_miss_645
label x8_case_646
mov r7 r8
add r7 r4
add r7 1
load8 r3 $r7
cmp r3 105
je x8_case_647
cmp r3 73
jne x8_miss_645
label x8_case_647
mov r7 r8
add r7 r4
add r7 2
load8 r3 $r7
cmp r3 114
je x8_case_648
cmp r3 82
jne x8_miss_645
label x8_case_648
mov r7 r8
add r7 r4
add r7 3
load8 r3 $r7
cmp r3 109
je x8_case_649
cmp r3 77
jne x8_miss_645
label x8_case_649
mov r7 r8
add r7 r4
add r7 4
load8 r3 $r7
cmp r3 97
je x8_case_650
cmp r3 65
jne x8_miss_645
label x8_case_650
mov r7 r8
add r7 r4
add r7 5
load8 r3 $r7
cmp r3 58
jne x8_miss_645
mov r7 r8
add r7 r4
add r7 6
load8 r3 $r7
cmp r3 32
jne x8_miss_645
mov r14 r6
mod r14 256
store8 9120000000000100016 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_consume_644
label x8_miss_645
jmp x8_format
label x8_consume_644
load8 r8 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r8 r14
load8 r1 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r1 r14
sub r1 r8
cmp r1 1
jlt x8_format
mov r14 r8
mod r14 256
store8 9120000000000100292 r14
mov r14 r8
div r14 256
mod r14 256
store8 9120000000000100293 r14
mov r14 r1
mod r14 256
store8 9120000000000100294 r14
mov r14 r1
div r14 256
mod r14 256
store8 9120000000000100295 r14
set r14 65
print r14
set r14 115
print r14
set r14 117
print r14
set r14 110
print r14
set r14 116
print r14
set r14 111
print r14
set r14 58
print r14
set r14 32
print r14
load8 r8 9120000000000100284
load8 r14 9120000000000100285
mul r14 256
add r8 r14
load8 r1 9120000000000100286
load8 r14 9120000000000100287
mul r14 256
add r1 r14
add r8 9100000000000200256
set r0 0
label x8_emit_651
cmp r0 r1
jge x8_emitted_652
mov r7 r8
add r7 r0
load8 r14 $r7
print r14
add r0 1
jmp x8_emit_651
label x8_emitted_652
set r14 10
print r14
set r14 10
print r14
set r14 72
print r14
set r14 111
print r14
set r14 108
print r14
set r14 97
print r14
set r14 44
print r14
set r14 32
print r14
load8 r8 9120000000000100280
load8 r14 9120000000000100281
mul r14 256
add r8 r14
load8 r1 9120000000000100282
load8 r14 9120000000000100283
mul r14 256
add r1 r14
add r8 9100000000000200256
set r0 0
label x8_emit_653
cmp r0 r1
jge x8_emitted_654
mov r7 r8
add r7 r0
load8 r14 $r7
print r14
add r0 1
jmp x8_emit_653
label x8_emitted_654
set r14 58
print r14
set r14 10
print r14
set r14 10
print r14
load8 r8 9120000000000100288
load8 r14 9120000000000100289
mul r14 256
add r8 r14
load8 r1 9120000000000100290
load8 r14 9120000000000100291
mul r14 256
add r1 r14
add r8 9100000000000200256
set r0 0
label x8_emit_655
cmp r0 r1
jge x8_emitted_656
mov r7 r8
add r7 r0
load8 r14 $r7
print r14
add r0 1
jmp x8_emit_655
label x8_emitted_656
set r14 10
print r14
set r14 10
print r14
set r14 83
print r14
set r14 97
print r14
set r14 108
print r14
set r14 117
print r14
set r14 100
print r14
set r14 111
print r14
set r14 115
print r14
set r14 44
print r14
set r14 10
print r14
load8 r8 9120000000000100292
load8 r14 9120000000000100293
mul r14 256
add r8 r14
load8 r1 9120000000000100294
load8 r14 9120000000000100295
mul r14 256
add r1 r14
add r8 9100000000000200256
set r0 0
label x8_emit_657
cmp r0 r1
jge x8_emitted_658
mov r7 r8
add r7 r0
load8 r14 $r7
print r14
add r0 1
jmp x8_emit_657
label x8_emitted_658
jmp x8_done
label x8_line
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r8 r4
label x8_line_scan
cmp r4 r9
jge x8_format
set r7 9100000000000200256
add r7 r4
load8 r3 $r7
cmp r3 10
je x8_line_end
cmp r3 13
je x8_line_cr
add r4 1
jmp x8_line_scan
label x8_line_cr
add r7 1
load8 r3 $r7
cmp r3 10
jne x8_format
mov r1 r4
sub r1 r8
add r4 2
jmp x8_line_done
label x8_line_end
mov r1 r4
sub r1 r8
add r4 1
label x8_line_done
cmp r1 1
jlt x8_format
cmp r1 4096
jgt x8_text_limit
mov r14 r4
mod r14 256
store8 9120000000000100016 r14
mov r14 r4
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_return
label x8_page
load8 r12 9120000000000100100
cmp r12 16
jge x8_corrupt
mov r7 r12
mul r7 2
add r7 9120000000000103900
store8 $r7 12
add r7 1
store8 $r7 0
add r12 1
store8 9120000000000100100 r12
jmp x8_number
label x8_return_659
load8 r12 9120000000000100100
cmp r12 16
jge x8_corrupt
mov r7 r12
mul r7 2
add r7 9120000000000103900
store8 $r7 13
add r7 1
store8 $r7 0
add r12 1
store8 9120000000000100100 r12
jmp x8_end
label x8_return_660
cmp r0 1
jlt x8_page_missing
cmp r0 122
jgt x8_page_missing
mov r14 r0
mod r14 256
store8 9120000000000100300 r14
mov r14 r0
div r14 256
mod r14 256
store8 9120000000000100301 r14
set r14 66
print r14
set r14 97
print r14
set r14 98
print r14
set r14 105
print r14
set r14 108
print r14
set r14 111
print r14
set r14 110
print r14
set r14 105
print r14
set r14 97
print r14
set r14 44
print r14
set r14 32
print r14
set r14 112
print r14
set r14 195
print r14
set r14 161
print r14
set r14 103
print r14
set r14 105
print r14
set r14 110
print r14
set r14 97
print r14
set r14 32
print r14
load8 r0 9120000000000100300
load8 r14 9120000000000100301
mul r14 256
add r0 r14
load8 r12 9120000000000100100
cmp r12 16
jge x8_corrupt
mov r7 r12
mul r7 2
add r7 9120000000000103900
store8 $r7 14
add r7 1
store8 $r7 0
add r12 1
store8 9120000000000100100 r12
jmp x8_uint
label x8_return_661
set r14 58
print r14
set r14 10
print r14
load8 r12 9120000000000100100
cmp r12 16
jge x8_corrupt
mov r7 r12
mul r7 2
add r7 9120000000000103900
store8 $r7 15
add r7 1
store8 $r7 0
add r12 1
store8 9120000000000100100 r12
jmp x8_read_page
label x8_return_662
set r0 0
label x8_emit_663
cmp r0 r1
jge x8_emitted_664
mov r7 r8
add r7 r0
load8 r14 $r7
print r14
add r0 1
jmp x8_emit_663
label x8_emitted_664
jmp x8_done
label x8_page_missing
set r14 69
print r14
set r14 108
print r14
set r14 32
print r14
set r14 100
print r14
set r14 111
print r14
set r14 99
print r14
set r14 117
print r14
set r14 109
print r14
set r14 101
print r14
set r14 110
print r14
set r14 116
print r14
set r14 111
print r14
set r14 32
print r14
set r14 99
print r14
set r14 111
print r14
set r14 110
print r14
set r14 116
print r14
set r14 105
print r14
set r14 101
print r14
set r14 110
print r14
set r14 101
print r14
set r14 32
print r14
set r14 112
print r14
set r14 195
print r14
set r14 161
print r14
set r14 103
print r14
set r14 105
print r14
set r14 110
print r14
set r14 97
print r14
set r14 115
print r14
set r14 32
print r14
set r14 49
print r14
set r14 32
print r14
set r14 97
print r14
set r14 32
print r14
set r14 49
print r14
set r14 50
print r14
set r14 50
print r14
set r14 46
print r14
jmp x8_done
label x8_book_status
load8 r12 9120000000000100100
cmp r12 16
jge x8_corrupt
mov r7 r12
mul r7 2
add r7 9120000000000103900
store8 $r7 16
add r7 1
store8 $r7 0
add r12 1
store8 9120000000000100100 r12
jmp x8_end
label x8_return_665
set r14 66
print r14
set r14 97
print r14
set r14 98
print r14
set r14 105
print r14
set r14 108
print r14
set r14 111
print r14
set r14 110
print r14
set r14 105
print r14
set r14 97
print r14
set r14 58
print r14
set r14 32
print r14
set r14 49
print r14
set r14 50
print r14
set r14 50
print r14
set r14 32
print r14
set r14 112
print r14
set r14 195
print r14
set r14 161
print r14
set r14 103
print r14
set r14 105
print r14
set r14 110
print r14
set r14 97
print r14
set r14 115
print r14
set r14 32
print r14
set r14 111
print r14
set r14 114
print r14
set r14 105
print r14
set r14 103
print r14
set r14 105
print r14
set r14 110
print r14
set r14 97
print r14
set r14 108
print r14
set r14 101
print r14
set r14 115
print r14
set r14 59
print r14
set r14 32
print r14
set r14 99
print r14
set r14 117
print r14
set r14 114
print r14
set r14 114
print r14
set r14 195
print r14
set r14 173
print r14
set r14 99
print r14
set r14 117
print r14
set r14 108
print r14
set r14 111
print r14
set r14 32
print r14
set r14 114
print r14
set r14 101
print r14
set r14 99
print r14
set r14 111
print r14
set r14 110
print r14
set r14 99
print r14
set r14 105
print r14
set r14 108
print r14
set r14 105
print r14
set r14 97
print r14
set r14 100
print r14
set r14 111
print r14
set r14 32
print r14
set r14 121
print r14
set r14 32
print r14
set r14 102
print r14
set r14 117
print r14
set r14 101
print r14
set r14 110
print r14
set r14 116
print r14
set r14 101
print r14
set r14 115
print r14
set r14 32
print r14
set r14 99
print r14
set r14 111
print r14
set r14 110
print r14
set r14 115
print r14
set r14 101
print r14
set r14 114
print r14
set r14 118
print r14
set r14 97
print r14
set r14 100
print r14
set r14 97
print r14
set r14 115
print r14
set r14 46
print r14
jmp x8_done
label x8_language_status
load8 r12 9120000000000100100
cmp r12 16
jge x8_corrupt
mov r7 r12
mul r7 2
add r7 9120000000000103900
store8 $r7 17
add r7 1
store8 $r7 0
add r12 1
store8 9120000000000100100 r12
jmp x8_end
label x8_return_666
set r14 69
print r14
set r14 113
print r14
set r14 117
print r14
set r14 105
print r14
set r14 118
print r14
set r14 97
print r14
set r14 108
print r14
set r14 101
print r14
set r14 110
print r14
set r14 99
print r14
set r14 105
print r14
set r14 97
print r14
set r14 115
print r14
set r14 32
print r14
set r14 121
print r14
set r14 32
print r14
set r14 114
print r14
set r14 101
print r14
set r14 103
print r14
set r14 108
print r14
set r14 97
print r14
set r14 115
print r14
set r14 32
print r14
set r14 101
print r14
set r14 110
print r14
set r14 115
print r14
set r14 101
print r14
set r14 195
print r14
set r14 177
print r14
set r14 97
print r14
set r14 100
print r14
set r14 97
print r14
set r14 115
print r14
set r14 58
print r14
set r14 32
print r14
load8 r0 601000002
load8 r14 601000003
mul r14 256
add r0 r14
load8 r12 9120000000000100100
cmp r12 16
jge x8_corrupt
mov r7 r12
mul r7 2
add r7 9120000000000103900
store8 $r7 18
add r7 1
store8 $r7 0
add r12 1
store8 9120000000000100100 r12
jmp x8_uint
label x8_return_667
set r14 46
print r14
set r14 32
print r14
set r14 84
print r14
set r14 114
print r14
set r14 97
print r14
set r14 100
print r14
set r14 117
print r14
set r14 99
print r14
set r14 99
print r14
set r14 105
print r14
set r14 195
print r14
set r14 179
print r14
set r14 110
print r14
set r14 32
print r14
set r14 112
print r14
set r14 111
print r14
set r14 114
print r14
set r14 32
print r14
set r14 102
print r14
set r14 114
print r14
set r14 97
print r14
set r14 115
print r14
set r14 101
print r14
set r14 115
print r14
set r14 59
print r14
set r14 32
print r14
set r14 99
print r14
set r14 111
print r14
set r14 98
print r14
set r14 101
print r14
set r14 114
print r14
set r14 116
print r14
set r14 117
print r14
set r14 114
print r14
set r14 97
print r14
set r14 32
print r14
set r14 112
print r14
set r14 97
print r14
set r14 114
print r14
set r14 99
print r14
set r14 105
print r14
set r14 97
print r14
set r14 108
print r14
set r14 32
print r14
set r14 105
print r14
set r14 110
print r14
set r14 100
print r14
set r14 105
print r14
set r14 99
print r14
set r14 97
print r14
set r14 100
print r14
set r14 97
print r14
set r14 46
print r14
jmp x8_done
label x8_search
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
mov r0 r9
sub r0 r4
cmp r0 1
jlt x8_format
cmp r0 512
jgt x8_text_limit
mov r14 r4
mod r14 256
store8 9120000000000100320 r14
mov r14 r4
div r14 256
mod r14 256
store8 9120000000000100321 r14
set r0 0
label x8_scores_668
set r7 9120000000000101000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 640
jlt x8_scores_668
set r0 0
mov r14 r0
mod r14 256
store8 9120000000000100322 r14
mov r14 r0
div r14 256
mod r14 256
store8 9120000000000100323 r14
label x8_search_word
load8 r4 9120000000000100320
load8 r14 9120000000000100321
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
cmp r4 r9
jge x8_rank
set r5 0
set r6 0
label x8_search_char
cmp r4 r9
jge x8_search_word_end
set r7 9100000000000200256
add r7 r4
load8 r3 $r7
add r4 1
cmp r3 65
jlt x8_fold_669
cmp r3 90
jgt x8_fold_669
add r3 32
label x8_fold_669
cmp r3 195
je x8_search_accent
cmp r3 97
jlt x8_search_word_end
cmp r3 122
jle x8_search_store
cmp r3 48
jlt x8_search_word_end
cmp r3 57
jgt x8_search_word_end
jmp x8_search_store
label x8_search_accent
cmp r4 r9
jge x8_search_word_end
add r7 1
load8 r3 $r7
add r4 1
cmp r3 129
je x8_accent_670_hit
cmp r3 161
je x8_accent_670_hit
jmp x8_accent_670
label x8_accent_670_hit
set r3 97
jmp x8_search_store
label x8_accent_670
cmp r3 137
je x8_accent_671_hit
cmp r3 169
je x8_accent_671_hit
jmp x8_accent_671
label x8_accent_671_hit
set r3 101
jmp x8_search_store
label x8_accent_671
cmp r3 141
je x8_accent_672_hit
cmp r3 173
je x8_accent_672_hit
jmp x8_accent_672
label x8_accent_672_hit
set r3 105
jmp x8_search_store
label x8_accent_672
cmp r3 147
je x8_accent_673_hit
cmp r3 179
je x8_accent_673_hit
jmp x8_accent_673
label x8_accent_673_hit
set r3 111
jmp x8_search_store
label x8_accent_673
cmp r3 154
je x8_accent_674_hit
cmp r3 186
je x8_accent_674_hit
cmp r3 156
je x8_accent_674_hit
cmp r3 188
je x8_accent_674_hit
jmp x8_accent_674
label x8_accent_674_hit
set r3 117
jmp x8_search_store
label x8_accent_674
cmp r3 145
je x8_accent_675_hit
cmp r3 177
je x8_accent_675_hit
jmp x8_accent_675
label x8_accent_675_hit
set r3 110
jmp x8_search_store
label x8_accent_675
jmp x8_search_word_end
label x8_search_store
cmp r5 32
jge x8_search_char
set r7 9120000000000100600
add r7 r5
store8 $r7 r3
mul r6 33
add r6 r3
mod r6 4093
add r5 1
jmp x8_search_char
label x8_search_word_end
mov r14 r4
mod r14 256
store8 9120000000000100320 r14
mov r14 r4
div r14 256
mod r14 256
store8 9120000000000100321 r14
cmp r5 2
jlt x8_search_word
mov r14 r5
mod r14 256
store8 9120000000000100324 r14
mov r14 r5
div r14 256
mod r14 256
store8 9120000000000100325 r14
mul r6 2
add r6 602000256
load8 r10 $r6
add r6 1
load8 r3 $r6
mul r3 256
add r10 r3
label x8_index_chain
cmp r10 0
je x8_search_word
mov r13 r10
sub r13 1
mul r13 112
add r13 602065536
mov r7 r13
add r7 0
load8 r0 $r7
load8 r5 9120000000000100324
load8 r14 9120000000000100325
mul r14 256
add r5 r14
cmp r0 r5
jne x8_index_next
set r2 0
label x8_index_word_compare
cmp r2 r5
jge x8_index_score
mov r7 r13
add r7 8
add r7 r2
load8 r1 $r7
set r7 9120000000000100600
add r7 r2
load8 r3 $r7
cmp r1 r3
jne x8_index_next
add r2 1
jmp x8_index_word_compare
label x8_index_score
mov r7 r13
add r7 1
load8 r11 $r7
set r2 0
label x8_index_score_id
cmp r2 r11
jge x8_index_next
mov r7 r2
mul r7 2
add r7 r13
add r7 40
load8 r0 $r7
add r7 1
load8 r3 $r7
mul r3 256
add r0 r3
cmp r0 634
jge x8_corrupt
add r0 9120000000000101000
load8 r3 $r0
cmp r3 250
jge x8_index_score_next
add r3 1
store8 $r0 r3
label x8_index_score_next
add r2 1
jmp x8_index_score_id
label x8_index_next
mov r7 r13
add r7 2
load8 r10 $r7
add r7 1
load8 r14 $r7
mul r14 256
add r10 r14
jmp x8_index_chain
label x8_rank
set r0 0
mov r14 r0
mod r14 256
store8 9120000000000100330 r14
mov r14 r0
div r14 256
mod r14 256
store8 9120000000000100331 r14
set r0 0
mov r14 r0
mod r14 256
store8 9120000000000100350 r14
mov r14 r0
div r14 256
mod r14 256
store8 9120000000000100351 r14
label x8_rank_again
load8 r0 9120000000000100350
load8 r14 9120000000000100351
mul r14 256
add r0 r14
add r0 1
cmp r0 8
jgt x8_rank_end
mov r14 r0
mod r14 256
store8 9120000000000100350 r14
mov r14 r0
div r14 256
mod r14 256
store8 9120000000000100351 r14
set r10 0
set r5 0
set r6 65535
label x8_rank_scan
set r7 9120000000000101000
add r7 r10
load8 r3 $r7
cmp r3 r5
jle x8_rank_next
mov r5 r3
mov r6 r10
label x8_rank_next
add r10 1
cmp r10 512
jlt x8_rank_scan
cmp r5 0
je x8_rank_end
mov r14 r6
mod r14 256
store8 9120000000000100332 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100333 r14
set r7 9120000000000101000
add r7 r6
store8 $r7 0
mov r13 r6
mul r13 640
add r13 9110000000000004096
mov r7 r13
add r7 0
load8 r0 $r7
cmp r0 1
jne x8_rank_again
load8 r6 9120000000000100332
load8 r14 9120000000000100333
mul r14 256
add r6 r14
mul r6 66
add r6 602010000
load8 r5 $r6
add r6 1
mov r14 r6
mod r14 256
store8 9120000000000100340 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100341 r14
mov r14 r6
div r14 65536
mod r14 256
store8 9120000000000100342 r14
mov r14 r6
div r14 16777216
mod r14 256
store8 9120000000000100343 r14
mov r14 r6
div r14 4294967296
mod r14 256
store8 9120000000000100344 r14
mov r14 r6
div r14 1099511627776
mod r14 256
store8 9120000000000100345 r14
mov r14 r6
div r14 281474976710656
mod r14 256
store8 9120000000000100346 r14
mov r14 r6
div r14 72057594037927936
mod r14 256
store8 9120000000000100347 r14
mov r14 r5
mod r14 256
store8 9120000000000100348 r14
mov r14 r5
div r14 256
mod r14 256
store8 9120000000000100349 r14
set r10 0
label x8_rank_find_current
cmp r10 4096
jge x8_rank_again
mov r13 r10
mul r13 640
add r13 9110000000000004096
mov r7 r13
add r7 0
load8 r0 $r7
cmp r0 1
jne x8_rank_current_next
mov r7 r13
add r7 1
load8 r0 $r7
load8 r5 9120000000000100348
load8 r14 9120000000000100349
mul r14 256
add r5 r14
cmp r0 r5
jne x8_rank_current_next
set r2 0
label x8_rank_key_byte
cmp r2 r5
jge x8_rank_current_found
mov r7 r13
add r7 16
add r7 r2
load8 r1 $r7
load8 r6 9120000000000100340
load8 r14 9120000000000100341
mul r14 256
add r6 r14
load8 r14 9120000000000100342
mul r14 65536
add r6 r14
load8 r14 9120000000000100343
mul r14 16777216
add r6 r14
load8 r14 9120000000000100344
mul r14 4294967296
add r6 r14
load8 r14 9120000000000100345
mul r14 1099511627776
add r6 r14
load8 r14 9120000000000100346
mul r14 281474976710656
add r6 r14
load8 r14 9120000000000100347
mul r14 72057594037927936
add r6 r14
mov r7 r6
add r7 r2
load8 r3 $r7
cmp r1 r3
jne x8_rank_current_next
add r2 1
jmp x8_rank_key_byte
label x8_rank_current_next
add r10 1
jmp x8_rank_find_current
label x8_rank_current_found
mov r14 r13
mod r14 256
store8 9120000000000100336 r14
mov r14 r13
div r14 256
mod r14 256
store8 9120000000000100337 r14
mov r14 r13
div r14 65536
mod r14 256
store8 9120000000000100338 r14
mov r14 r13
div r14 16777216
mod r14 256
store8 9120000000000100339 r14
mov r14 r13
div r14 4294967296
mod r14 256
store8 9120000000000100340 r14
mov r14 r13
div r14 1099511627776
mod r14 256
store8 9120000000000100341 r14
mov r14 r13
div r14 281474976710656
mod r14 256
store8 9120000000000100342 r14
mov r14 r13
div r14 72057594037927936
mod r14 256
store8 9120000000000100343 r14
load8 r0 9120000000000100330
load8 r14 9120000000000100331
mul r14 256
add r0 r14
cmp r0 0
jne x8_rank_emit
set r14 69
print r14
set r14 118
print r14
set r14 105
print r14
set r14 100
print r14
set r14 101
print r14
set r14 110
print r14
set r14 99
print r14
set r14 105
print r14
set r14 97
print r14
set r14 32
print r14
set r14 100
print r14
set r14 101
print r14
set r14 108
print r14
set r14 32
print r14
set r14 99
print r14
set r14 117
print r14
set r14 114
print r14
set r14 114
print r14
set r14 195
print r14
set r14 173
print r14
set r14 99
print r14
set r14 117
print r14
set r14 108
print r14
set r14 111
print r14
set r14 32
print r14
set r14 40
print r14
set r14 99
print r14
set r14 111
print r14
set r14 105
print r14
set r14 110
print r14
set r14 99
print r14
set r14 105
print r14
set r14 100
print r14
set r14 101
print r14
set r14 110
print r14
set r14 99
print r14
set r14 105
print r14
set r14 97
print r14
set r14 115
print r14
set r14 32
print r14
set r14 100
print r14
set r14 101
print r14
set r14 32
print r14
set r14 116
print r14
set r14 195
print r14
set r14 169
print r14
set r14 114
print r14
set r14 109
print r14
set r14 105
print r14
set r14 110
print r14
set r14 111
print r14
set r14 115
print r14
set r14 41
print r14
set r14 58
print r14
set r14 10
print r14
label x8_rank_emit
load8 r13 9120000000000100336
load8 r14 9120000000000100337
mul r14 256
add r13 r14
load8 r14 9120000000000100338
mul r14 65536
add r13 r14
load8 r14 9120000000000100339
mul r14 16777216
add r13 r14
load8 r14 9120000000000100340
mul r14 4294967296
add r13 r14
load8 r14 9120000000000100341
mul r14 1099511627776
add r13 r14
load8 r14 9120000000000100342
mul r14 281474976710656
add r13 r14
load8 r14 9120000000000100343
mul r14 72057594037927936
add r13 r14
mov r7 r13
add r7 1
load8 r1 $r7
mov r8 r13
add r8 16
set r0 0
label x8_emit_676
cmp r0 r1
jge x8_emitted_677
mov r7 r8
add r7 r0
load8 r14 $r7
print r14
add r0 1
jmp x8_emit_676
label x8_emitted_677
set r14 58
print r14
set r14 32
print r14
load8 r13 9120000000000100336
load8 r14 9120000000000100337
mul r14 256
add r13 r14
load8 r14 9120000000000100338
mul r14 65536
add r13 r14
load8 r14 9120000000000100339
mul r14 16777216
add r13 r14
load8 r14 9120000000000100340
mul r14 4294967296
add r13 r14
load8 r14 9120000000000100341
mul r14 1099511627776
add r13 r14
load8 r14 9120000000000100342
mul r14 281474976710656
add r13 r14
load8 r14 9120000000000100343
mul r14 72057594037927936
add r13 r14
mov r7 r13
add r7 2
load8 r1 $r7
mov r8 r13
add r8 80
set r0 0
label x8_emit_678
cmp r0 r1
jge x8_emitted_679
mov r7 r8
add r7 r0
load8 r14 $r7
print r14
add r0 1
jmp x8_emit_678
label x8_emitted_679
set r14 46
print r14
set r14 32
print r14
set r14 82
print r14
set r14 101
print r14
set r14 113
print r14
set r14 117
print r14
set r14 105
print r14
set r14 101
print r14
set r14 114
print r14
set r14 101
print r14
set r14 32
print r14
load8 r13 9120000000000100336
load8 r14 9120000000000100337
mul r14 256
add r13 r14
load8 r14 9120000000000100338
mul r14 65536
add r13 r14
load8 r14 9120000000000100339
mul r14 16777216
add r13 r14
load8 r14 9120000000000100340
mul r14 4294967296
add r13 r14
load8 r14 9120000000000100341
mul r14 1099511627776
add r13 r14
load8 r14 9120000000000100342
mul r14 281474976710656
add r13 r14
load8 r14 9120000000000100343
mul r14 72057594037927936
add r13 r14
mov r7 r13
add r7 3
load8 r1 $r7
mov r8 r13
add r8 304
set r0 0
label x8_emit_680
cmp r0 r1
jge x8_emitted_681
mov r7 r8
add r7 r0
load8 r14 $r7
print r14
add r0 1
jmp x8_emit_680
label x8_emitted_681
set r14 32
print r14
set r14 91
print r14
load8 r13 9120000000000100336
load8 r14 9120000000000100337
mul r14 256
add r13 r14
load8 r14 9120000000000100338
mul r14 65536
add r13 r14
load8 r14 9120000000000100339
mul r14 16777216
add r13 r14
load8 r14 9120000000000100340
mul r14 4294967296
add r13 r14
load8 r14 9120000000000100341
mul r14 1099511627776
add r13 r14
load8 r14 9120000000000100342
mul r14 281474976710656
add r13 r14
load8 r14 9120000000000100343
mul r14 72057594037927936
add r13 r14
mov r7 r13
add r7 4
load8 r1 $r7
mov r8 r13
add r8 528
set r0 0
label x8_emit_682
cmp r0 r1
jge x8_emitted_683
mov r7 r8
add r7 r0
load8 r14 $r7
print r14
add r0 1
jmp x8_emit_682
label x8_emitted_683
set r14 44
print r14
set r14 32
print r14
set r14 112
print r14
set r14 195
print r14
set r14 161
print r14
set r14 103
print r14
set r14 105
print r14
set r14 110
print r14
set r14 97
print r14
set r14 115
print r14
set r14 32
print r14
load8 r13 9120000000000100336
load8 r14 9120000000000100337
mul r14 256
add r13 r14
load8 r14 9120000000000100338
mul r14 65536
add r13 r14
load8 r14 9120000000000100339
mul r14 16777216
add r13 r14
load8 r14 9120000000000100340
mul r14 4294967296
add r13 r14
load8 r14 9120000000000100341
mul r14 1099511627776
add r13 r14
load8 r14 9120000000000100342
mul r14 281474976710656
add r13 r14
load8 r14 9120000000000100343
mul r14 72057594037927936
add r13 r14
mov r7 r13
add r7 5
load8 r1 $r7
mov r8 r13
add r8 560
set r0 0
label x8_emit_684
cmp r0 r1
jge x8_emitted_685
mov r7 r8
add r7 r0
load8 r14 $r7
print r14
add r0 1
jmp x8_emit_684
label x8_emitted_685
set r14 93
print r14
set r14 46
print r14
set r14 10
print r14
load8 r0 9120000000000100330
load8 r14 9120000000000100331
mul r14 256
add r0 r14
add r0 1
mov r14 r0
mod r14 256
store8 9120000000000100330 r14
mov r14 r0
div r14 256
mod r14 256
store8 9120000000000100331 r14
cmp r0 3
jlt x8_rank_again
jmp x8_done
label x8_rank_end
load8 r0 9120000000000100330
load8 r14 9120000000000100331
mul r14 256
add r0 r14
cmp r0 0
jne x8_done
set r10 512
set r5 0
set r6 0
label x8_page_rank
set r7 9120000000000101000
add r7 r10
load8 r3 $r7
cmp r3 r5
jle x8_page_rank_next
mov r5 r3
mov r6 r10
label x8_page_rank_next
add r10 1
cmp r10 634
jlt x8_page_rank
cmp r5 0
je x8_search_empty
sub r6 511
mov r14 r6
mod r14 256
store8 9120000000000100300 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100301 r14
set r14 67
print r14
set r14 111
print r14
set r14 105
print r14
set r14 110
print r14
set r14 99
print r14
set r14 105
print r14
set r14 100
print r14
set r14 101
print r14
set r14 110
print r14
set r14 99
print r14
set r14 105
print r14
set r14 97
print r14
set r14 32
print r14
set r14 108
print r14
set r14 195
print r14
set r14 169
print r14
set r14 120
print r14
set r14 105
print r14
set r14 99
print r14
set r14 97
print r14
set r14 32
print r14
set r14 101
print r14
set r14 110
print r14
set r14 32
print r14
set r14 101
print r14
set r14 108
print r14
set r14 32
print r14
set r14 116
print r14
set r14 101
print r14
set r14 120
print r14
set r14 116
print r14
set r14 111
print r14
set r14 32
print r14
set r14 111
print r14
set r14 114
print r14
set r14 105
print r14
set r14 103
print r14
set r14 105
print r14
set r14 110
print r14
set r14 97
print r14
set r14 108
print r14
set r14 44
print r14
set r14 32
print r14
set r14 112
print r14
set r14 195
print r14
set r14 161
print r14
set r14 103
print r14
set r14 105
print r14
set r14 110
print r14
set r14 97
print r14
set r14 32
print r14
load8 r0 9120000000000100300
load8 r14 9120000000000100301
mul r14 256
add r0 r14
load8 r12 9120000000000100100
cmp r12 16
jge x8_corrupt
mov r7 r12
mul r7 2
add r7 9120000000000103900
store8 $r7 19
add r7 1
store8 $r7 0
add r12 1
store8 9120000000000100100 r12
jmp x8_uint
label x8_return_686
set r14 58
print r14
set r14 10
print r14
load8 r12 9120000000000100100
cmp r12 16
jge x8_corrupt
mov r7 r12
mul r7 2
add r7 9120000000000103900
store8 $r7 20
add r7 1
store8 $r7 0
add r12 1
store8 9120000000000100100 r12
jmp x8_read_page
label x8_return_687
set r0 0
label x8_emit_688
cmp r0 r1
jge x8_emitted_689
mov r7 r8
add r7 r0
load8 r14 $r7
print r14
add r0 1
jmp x8_emit_688
label x8_emitted_689
jmp x8_done
label x8_search_empty
set r14 78
print r14
set r14 111
print r14
set r14 32
print r14
set r14 101
print r14
set r14 110
print r14
set r14 99
print r14
set r14 111
print r14
set r14 110
print r14
set r14 116
print r14
set r14 114
print r14
set r14 195
print r14
set r14 169
print r14
set r14 32
print r14
set r14 101
print r14
set r14 118
print r14
set r14 105
print r14
set r14 100
print r14
set r14 101
print r14
set r14 110
print r14
set r14 99
print r14
set r14 105
print r14
set r14 97
print r14
set r14 32
print r14
set r14 118
print r14
set r14 105
print r14
set r14 103
print r14
set r14 101
print r14
set r14 110
print r14
set r14 116
print r14
set r14 101
print r14
set r14 32
print r14
set r14 112
print r14
set r14 97
print r14
set r14 114
print r14
set r14 97
print r14
set r14 32
print r14
set r14 101
print r14
set r14 115
print r14
set r14 97
print r14
set r14 32
print r14
set r14 99
print r14
set r14 111
print r14
set r14 110
print r14
set r14 115
print r14
set r14 117
print r14
set r14 108
print r14
set r14 116
print r14
set r14 97
print r14
set r14 46
print r14
set r14 32
print r14
set r14 80
print r14
set r14 114
print r14
set r14 117
print r14
set r14 101
print r14
set r14 98
print r14
set r14 97
print r14
set r14 32
print r14
set r14 117
print r14
set r14 110
print r14
set r14 32
print r14
set r14 99
print r14
set r14 111
print r14
set r14 110
print r14
set r14 99
print r14
set r14 101
print r14
set r14 112
print r14
set r14 116
print r14
set r14 111
print r14
set r14 32
print r14
set r14 111
print r14
set r14 32
print r14
set r14 108
print r14
set r14 101
print r14
set r14 101
print r14
set r14 32
print r14
set r14 117
print r14
set r14 110
print r14
set r14 97
print r14
set r14 32
print r14
set r14 112
print r14
set r14 195
print r14
set r14 161
print r14
set r14 103
print r14
set r14 105
print r14
set r14 110
print r14
set r14 97
print r14
set r14 32
print r14
set r14 99
print r14
set r14 111
print r14
set r14 110
print r14
set r14 99
print r14
set r14 114
print r14
set r14 101
print r14
set r14 116
print r14
set r14 97
print r14
set r14 46
print r14
jmp x8_done
label x8_append
load8 r2 9120000000000100202
load8 r14 9120000000000100203
mul r14 256
add r2 r14
mov r6 r2
add r6 r1
cmp r6 32768
jgt x8_text_limit
set r0 0
label x8_append_loop
cmp r0 r1
jge x8_append_done
mov r7 r8
add r7 r0
load8 r3 $r7
set r7 9120000000000112000
add r7 r2
add r7 r0
store8 $r7 r3
add r0 1
jmp x8_append_loop
label x8_append_done
mov r14 r6
mod r14 256
store8 9120000000000100202 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100203 r14
jmp x8_return
label x8_copy_span
set r0 0
label x8_copy_span_loop
cmp r0 r1
jge x8_copy_span_done
mov r7 r8
add r7 r0
load8 r3 $r7
mov r7 r11
add r7 r0
store8 $r7 r3
add r0 1
jmp x8_copy_span_loop
label x8_copy_span_done
jmp x8_return
label x8_output
set r8 9120000000000112000
load8 r1 9120000000000100202
load8 r14 9120000000000100203
mul r14 256
add r1 r14
set r0 0
label x8_emit_690
cmp r0 r1
jge x8_emitted_691
mov r7 r8
add r7 r0
load8 r14 $r7
print r14
add r0 1
jmp x8_emit_690
label x8_emitted_691
jmp x8_done
label x8_read_page
load8 r13 9120000000000100300
load8 r14 9120000000000100301
mul r14 256
add r13 r14
cmp r13 1
jlt x8_corrupt
cmp r13 122
jgt x8_corrupt
sub r13 1
mul r13 8
add r13 600004096
mov r7 r13
add r7 0
load8 r8 $r7
add r7 1
load8 r14 $r7
mul r14 256
add r8 r14
add r7 1
load8 r14 $r7
mul r14 65536
add r8 r14
add r7 1
load8 r14 $r7
mul r14 16777216
add r8 r14
mov r7 r13
add r7 4
load8 r10 $r7
add r7 1
load8 r14 $r7
mul r14 256
add r10 r14
mov r7 r13
add r7 6
load8 r9 $r7
add r7 1
load8 r14 $r7
mul r14 256
add r9 r14
load8 r0 600000008
load8 r14 600000009
mul r14 256
add r0 r14
load8 r14 600000010
mul r14 65536
add r0 r14
load8 r14 600000011
mul r14 16777216
add r0 r14
mov r1 r8
add r1 r9
cmp r1 r0
jgt x8_corrupt
cmp r10 16384
jgt x8_corrupt
add r8 600008192
set r4 0
load8 r2 600000014
load8 r14 600000015
mul r14 256
add r2 r14
cmp r2 3500
jgt x8_corrupt
set r6 0
label x8_lz_dictionary
cmp r6 r2
jge x8_lz_dictionary_ready
set r7 600000128
add r7 r6
load8 r3 $r7
set r7 9120000000000112000
add r7 r6
store8 $r7 r3
add r6 1
jmp x8_lz_dictionary
label x8_lz_dictionary_ready
add r10 r2
label x8_lz_token
cmp r4 r9
jge x8_lz_done
mov r7 r8
add r7 r4
load8 r3 $r7
add r4 1
cmp r3 128
jge x8_lz_match
mov r11 r3
add r11 1
mov r0 r4
add r0 r11
cmp r0 r9
jgt x8_corrupt
mov r0 r6
add r0 r11
cmp r0 r10
jgt x8_corrupt
label x8_lz_literal
cmp r11 0
je x8_lz_token
mov r7 r8
add r7 r4
load8 r3 $r7
set r7 9120000000000112000
add r7 r6
store8 $r7 r3
add r4 1
add r6 1
sub r11 1
jmp x8_lz_literal
label x8_lz_match
mov r11 r3
sub r11 124
mov r0 r4
add r0 2
cmp r0 r9
jgt x8_corrupt
mov r7 r8
add r7 r4
load8 r5 $r7
add r7 1
load8 r3 $r7
mul r3 256
add r5 r3
add r4 2
cmp r5 1
jlt x8_corrupt
cmp r5 r6
jgt x8_corrupt
mov r0 r6
add r0 r11
cmp r0 r10
jgt x8_corrupt
label x8_lz_copy
cmp r11 0
je x8_lz_token
set r7 9120000000000112000
add r7 r6
sub r7 r5
load8 r3 $r7
add r7 r5
store8 $r7 r3
add r6 1
sub r11 1
jmp x8_lz_copy
label x8_lz_done
cmp r6 r10
jne x8_corrupt
mov r14 r6
mod r14 256
store8 9120000000000100202 r14
mov r14 r6
div r14 256
mod r14 256
store8 9120000000000100203 r14
set r8 9120000000000112000
add r8 r2
mov r1 r6
sub r1 r2
jmp x8_return
label x8_number
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
set r0 0
set r5 0
label x8_number_byte
cmp r4 r9
jge x8_number_end
set r7 9100000000000200256
add r7 r4
load8 r3 $r7
cmp r3 48
jlt x8_number_end
cmp r3 57
jgt x8_number_end
sub r3 48
mul r0 10
add r0 r3
cmp r0 1000000
jgt x8_format
add r5 1
add r4 1
jmp x8_number_byte
label x8_number_end
cmp r5 0
je x8_format
mov r14 r4
mod r14 256
store8 9120000000000100016 r14
mov r14 r4
div r14 256
mod r14 256
store8 9120000000000100017 r14
jmp x8_return
label x8_end
load8 r4 9120000000000100016
load8 r14 9120000000000100017
mul r14 256
add r4 r14
load8 r9 9120000000000100018
load8 r14 9120000000000100019
mul r14 256
add r9 r14
label x8_end_byte
cmp r4 r9
jge x8_end_ok
set r7 9100000000000200256
add r7 r4
load8 r3 $r7
cmp r3 32
jne x8_format
add r4 1
jmp x8_end_byte
label x8_end_ok
jmp x8_return
label x8_uint
set r5 1000000000
set r6 0
label x8_uint_digit
mov r1 r0
div r1 r5
cmp r1 0
jne x8_uint_print
cmp r6 1
je x8_uint_print
cmp r5 1
jne x8_uint_next
label x8_uint_print
mov r14 r1
add r14 48
print r14
set r6 1
label x8_uint_next
mod r0 r5
div r5 10
cmp r5 0
jgt x8_uint_digit
jmp x8_return
label x8_no_consent
load8 r0 9100000000000200003
cmp r0 1
jne x8_consent_ready
store8 9100000000000100200 1
label x8_consent_ready
set r14 78
print r14
set r14 111
print r14
set r14 32
print r14
set r14 103
print r14
set r14 117
print r14
set r14 97
print r14
set r14 114
print r14
set r14 100
print r14
set r14 195
print r14
set r14 169
print r14
set r14 32
print r14
set r14 101
print r14
set r14 115
print r14
set r14 97
print r14
set r14 32
print r14
set r14 97
print r14
set r14 102
print r14
set r14 105
print r14
set r14 114
print r14
set r14 109
print r14
set r14 97
print r14
set r14 99
print r14
set r14 105
print r14
set r14 195
print r14
set r14 179
print r14
set r14 110
print r14
set r14 46
print r14
set r14 32
print r14
set r14 80
print r14
set r14 97
print r14
set r14 114
print r14
set r14 97
print r14
set r14 32
print r14
set r14 99
print r14
set r14 111
print r14
set r14 110
print r14
set r14 115
print r14
set r14 101
print r14
set r14 114
print r14
set r14 118
print r14
set r14 97
print r14
set r14 114
print r14
set r14 108
print r14
set r14 97
print r14
set r14 44
print r14
set r14 32
print r14
set r14 101
print r14
set r14 115
print r14
set r14 99
print r14
set r14 114
print r14
set r14 105
print r14
set r14 98
print r14
set r14 101
print r14
set r14 32
print r14
set r14 194
print r14
set r14 171
print r14
set r14 114
print r14
set r14 101
print r14
set r14 99
print r14
set r14 117
print r14
set r14 101
print r14
set r14 114
print r14
set r14 100
print r14
set r14 97
print r14
set r14 32
print r14
set r14 113
print r14
set r14 117
print r14
set r14 101
print r14
set r14 32
print r14
set r14 226
print r14
set r14 128
print r14
set r14 166
print r14
set r14 194
print r14
set r14 187
print r14
set r14 32
print r14
set r14 111
print r14
set r14 32
print r14
set r14 117
print r14
set r14 115
print r14
set r14 97
print r14
set r14 32
print r14
set r14 117
print r14
set r14 110
print r14
set r14 97
print r14
set r14 32
print r14
set r14 101
print r14
set r14 110
print r14
set r14 115
print r14
set r14 101
print r14
set r14 195
print r14
set r14 177
print r14
set r14 97
print r14
set r14 110
print r14
set r14 122
print r14
set r14 97
print r14
set r14 32
print r14
set r14 101
print r14
set r14 120
print r14
set r14 112
print r14
set r14 108
print r14
set r14 195
print r14
set r14 173
print r14
set r14 99
print r14
set r14 105
print r14
set r14 116
print r14
set r14 97
print r14
set r14 46
print r14
jmp x8_done
label x8_compare_limit
set r14 10
print r14
set r14 67
print r14
set r14 111
print r14
set r14 109
print r14
set r14 112
print r14
set r14 97
print r14
set r14 114
print r14
set r14 97
print r14
set r14 99
print r14
set r14 105
print r14
set r14 195
print r14
set r14 179
print r14
set r14 110
print r14
set r14 32
print r14
set r14 105
print r14
set r14 110
print r14
set r14 99
print r14
set r14 111
print r14
set r14 109
print r14
set r14 112
print r14
set r14 108
print r14
set r14 101
print r14
set r14 116
print r14
set r14 97
print r14
set r14 58
print r14
set r14 32
print r14
set r14 115
print r14
set r14 101
print r14
set r14 32
print r14
set r14 97
print r14
set r14 108
print r14
set r14 99
print r14
set r14 97
print r14
set r14 110
print r14
set r14 122
print r14
set r14 195
print r14
set r14 179
print r14
set r14 32
print r14
set r14 101
print r14
set r14 108
print r14
set r14 32
print r14
set r14 112
print r14
set r14 114
print r14
set r14 101
print r14
set r14 115
print r14
set r14 117
print r14
set r14 112
print r14
set r14 117
print r14
set r14 101
print r14
set r14 115
print r14
set r14 116
print r14
set r14 111
print r14
set r14 32
print r14
set r14 100
print r14
set r14 101
print r14
set r14 32
print r14
set r14 99
print r14
set r14 111
print r14
set r14 105
print r14
set r14 110
print r14
set r14 99
print r14
set r14 105
print r14
set r14 100
print r14
set r14 101
print r14
set r14 110
print r14
set r14 99
print r14
set r14 105
print r14
set r14 97
print r14
set r14 115
print r14
set r14 46
print r14
jmp x8_done
label x8_text_limit
set r14 76
print r14
set r14 97
print r14
set r14 32
print r14
set r14 111
print r14
set r14 112
print r14
set r14 101
print r14
set r14 114
print r14
set r14 97
print r14
set r14 99
print r14
set r14 105
print r14
set r14 195
print r14
set r14 179
print r14
set r14 110
print r14
set r14 32
print r14
set r14 115
print r14
set r14 117
print r14
set r14 112
print r14
set r14 101
print r14
set r14 114
print r14
set r14 97
print r14
set r14 32
print r14
set r14 115
print r14
set r14 117
print r14
set r14 32
print r14
set r14 108
print r14
set r14 195
print r14
set r14 173
print r14
set r14 109
print r14
set r14 105
print r14
set r14 116
print r14
set r14 101
print r14
set r14 32
print r14
set r14 100
print r14
set r14 101
print r14
set r14 32
print r14
set r14 116
print r14
set r14 101
print r14
set r14 120
print r14
set r14 116
print r14
set r14 111
print r14
set r14 32
print r14
set r14 100
print r14
set r14 101
print r14
set r14 99
print r14
set r14 108
print r14
set r14 97
print r14
set r14 114
print r14
set r14 97
print r14
set r14 100
print r14
set r14 111
print r14
set r14 59
print r14
set r14 32
print r14
set r14 110
print r14
set r14 111
print r14
set r14 32
print r14
set r14 99
print r14
set r14 97
print r14
set r14 109
print r14
set r14 98
print r14
set r14 105
print r14
set r14 195
print r14
set r14 169
print r14
set r14 32
print r14
set r14 101
print r14
set r14 108
print r14
set r14 32
print r14
set r14 99
print r14
set r14 111
print r14
set r14 110
print r14
set r14 116
print r14
set r14 101
print r14
set r14 110
print r14
set r14 105
print r14
set r14 100
print r14
set r14 111
print r14
set r14 32
print r14
set r14 103
print r14
set r14 117
print r14
set r14 97
print r14
set r14 114
print r14
set r14 100
print r14
set r14 97
print r14
set r14 100
print r14
set r14 111
print r14
set r14 46
print r14
jmp x8_done
label x8_format
set r14 78
print r14
set r14 101
print r14
set r14 99
print r14
set r14 101
print r14
set r14 115
print r14
set r14 105
print r14
set r14 116
print r14
set r14 111
print r14
set r14 32
print r14
set r14 101
print r14
set r14 108
print r14
set r14 32
print r14
set r14 102
print r14
set r14 111
print r14
set r14 114
print r14
set r14 109
print r14
set r14 97
print r14
set r14 116
print r14
set r14 111
print r14
set r14 32
print r14
set r14 99
print r14
set r14 111
print r14
set r14 109
print r14
set r14 112
print r14
set r14 108
print r14
set r14 101
print r14
set r14 116
print r14
set r14 111
print r14
set r14 32
print r14
set r14 100
print r14
set r14 101
print r14
set r14 32
print r14
set r14 101
print r14
set r14 115
print r14
set r14 97
print r14
set r14 32
print r14
set r14 111
print r14
set r14 112
print r14
set r14 101
print r14
set r14 114
print r14
set r14 97
print r14
set r14 99
print r14
set r14 105
print r14
set r14 195
print r14
set r14 179
print r14
set r14 110
print r14
set r14 59
print r14
set r14 32
print r14
set r14 110
print r14
set r14 111
print r14
set r14 32
print r14
set r14 99
print r14
set r14 97
print r14
set r14 109
print r14
set r14 98
print r14
set r14 105
print r14
set r14 195
print r14
set r14 169
print r14
set r14 32
print r14
set r14 101
print r14
set r14 108
print r14
set r14 32
print r14
set r14 99
print r14
set r14 111
print r14
set r14 110
print r14
set r14 116
print r14
set r14 101
print r14
set r14 110
print r14
set r14 105
print r14
set r14 100
print r14
set r14 111
print r14
set r14 32
print r14
set r14 103
print r14
set r14 117
print r14
set r14 97
print r14
set r14 114
print r14
set r14 100
print r14
set r14 97
print r14
set r14 100
print r14
set r14 111
print r14
set r14 46
print r14
jmp x8_done
label x8_done
load8 r5 9120000000000100202
load8 r14 9120000000000100203
mul r14 256
add r5 r14
set r0 0
label x8_erase_output
cmp r0 r5
jge x8_erase_scratch
set r7 9120000000000112000
add r7 r0
store8 $r7 0
add r0 1
jmp x8_erase_output
label x8_erase_scratch
set r0 0
label x8_erase_692
set r7 9120000000000100000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 8192
jlt x8_erase_692
jmp x6_done
label x8_resume
set r0 0
label x8_resume_693
set r7 9120000000000100000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x8_resume_693
jmp x7_routes
label x8_corrupt
set r0 0
mod r0 0
label x8_return
load8 r12 9120000000000100100
cmp r12 1
jlt x8_corrupt
sub r12 1
store8 9120000000000100100 r12
mov r7 r12
mul r7 2
add r7 9120000000000103900
load8 r12 $r7
add r7 1
load8 r14 $r7
mul r14 256
add r12 r14
cmp r12 1
je x8_return_562
cmp r12 2
je x8_return_563
cmp r12 3
je x8_return_565
cmp r12 4
je x8_return_569
cmp r12 5
je x8_return_571
cmp r12 6
je x8_return_574
cmp r12 7
je x8_return_575
cmp r12 8
je x8_return_576
cmp r12 9
je x8_return_622
cmp r12 10
je x8_return_631
cmp r12 11
je x8_return_643
cmp r12 12
je x8_return_659
cmp r12 13
je x8_return_660
cmp r12 14
je x8_return_661
cmp r12 15
je x8_return_662
cmp r12 16
je x8_return_665
cmp r12 17
je x8_return_666
cmp r12 18
je x8_return_667
cmp r12 19
je x8_return_686
cmp r12 20
je x8_return_687
jmp x8_corrupt

label x7_routes
store8 9120000000000000002 0
store8 9100000000000200002 1
halt
label x6_parent
jmp x8_corrupt
label x6_format
jmp x8_format
label x6_text_v2
load8 r0 9100000000000200000
cmp r0 86
jne x6_error_version
load8 r0 9100000000000200001
cmp r0 2
jne x6_error_version
load8 r0 9100000000000200004
cmp r0 1
je x6_text_language
cmp r0 2
jne x6_error_language
label x6_text_language
load8 r9 9100000000000200008
load8 r14 9100000000000200009
mul r14 256
add r9 r14
cmp r9 1
jlt x6_error_empty
cmp r9 16384
jgt x6_error_size
set r4 0
label x6_utf8
cmp r4 r9
jge x6_text_valid
set r7 9100000000000200256
add r7 r4
load8 r3 $r7
add r4 1
cmp r3 128
jge x6_utf8_lead
cmp r3 127
je x6_error_control
cmp r3 32
jge x6_utf8
cmp r3 9
je x6_utf8
cmp r3 10
je x6_utf8
cmp r3 13
je x6_utf8
jmp x6_error_control
label x6_utf8_lead
cmp r3 194
jlt x6_error_utf8
cmp r3 223
jle x6_utf8_two
cmp r3 239
jle x6_utf8_three
cmp r3 244
jle x6_utf8_four
jmp x6_error_utf8
label x6_utf8_two
set r5 1
set r6 128
set r10 191
jmp x6_utf8_next
label x6_utf8_three
set r5 2
set r6 128
set r10 191
cmp r3 224
jne x6_utf8_not_e0
set r6 160
label x6_utf8_not_e0
cmp r3 237
jne x6_utf8_next
set r10 159
jmp x6_utf8_next
label x6_utf8_four
set r5 3
set r6 128
set r10 191
cmp r3 240
jne x6_utf8_not_f0
set r6 144
label x6_utf8_not_f0
cmp r3 244
jne x6_utf8_next
set r10 143
label x6_utf8_next
cmp r4 r9
jge x6_error_utf8
set r7 9100000000000200256
add r7 r4
load8 r3 $r7
cmp r3 r6
jlt x6_error_utf8
cmp r3 r10
jgt x6_error_utf8
add r4 1
sub r5 1
cmp r5 0
je x6_utf8
set r6 128
set r10 191
jmp x6_utf8_next
label x6_text_valid
store8 9100000000000200002 0
store8 9100000000000200003 1
store8 9100000000000200010 0
store8 9100000000000100200 1
mov r14 r9
mod r14 256
store8 9100000000000100018 r14
mov r14 r9
div r14 256
mod r14 256
store8 9100000000000100019 r14
set r0 0
mov r14 r0
mod r14 256
store8 9100000000000100016 r14
mov r14 r0
div r14 256
mod r14 256
store8 9100000000000100017 r14
store8 9100000000000100100 0
jmp x6_routes
label x6_error_version
store8 9100000000000200002 0
store8 9100000000000200003 3
store8 9100000000000200010 5
halt
label x6_error_language
store8 9100000000000200002 0
store8 9100000000000200003 3
store8 9100000000000200010 6
halt
label x6_error_empty
store8 9100000000000200002 0
store8 9100000000000200003 3
store8 9100000000000200010 1
halt
label x6_error_size
store8 9100000000000200002 0
store8 9100000000000200003 3
store8 9100000000000200010 2
halt
label x6_error_utf8
store8 9100000000000200002 0
store8 9100000000000200003 3
store8 9100000000000200010 3
halt
label x6_error_control
store8 9100000000000200002 0
store8 9100000000000200003 3
store8 9100000000000200010 4
halt
label x6_error_unsupported
store8 9100000000000200002 0
store8 9100000000000200003 3
store8 9100000000000200010 7
halt
label x6_echo
load8 r8 9100000000000100016
load8 r14 9100000000000100017
mul r14 256
add r8 r14
load8 r1 9100000000000100018
load8 r14 9100000000000100019
mul r14 256
add r1 r14
sub r1 r8
cmp r1 1
jlt x6_format
add r8 9100000000000200256
set r0 0
label x6_emit_0
cmp r0 r1
jge x6_emitted_1
mov r7 r8
add r7 r0
load8 r14 $r7
print r14
add r0 1
jmp x6_emit_0
label x6_emitted_1
jmp x6_done
label x6_to_parent
load8 r9 9100000000000100018
load8 r14 9100000000000100019
mul r14 256
add r9 r14
cmp r9 255
jgt x6_error_unsupported
set r0 0
label x6_parent_bytes
cmp r0 r9
jge x6_parent_ready
set r7 9100000000000200256
add r7 r0
load8 r3 $r7
cmp r3 9
je x6_error_unsupported
cmp r3 10
je x6_error_unsupported
cmp r3 13
je x6_error_unsupported
set r7 7400000000000000128
add r7 r0
store8 $r7 r3
add r0 1
jmp x6_parent_bytes
label x6_parent_ready
store8 7400000000000000017 r9
store8 7400000000000000016 1
load8 r0 9100000000000200004
store8 7400000000000000003 r0
set r0 0
label x6_parent_scratch_2
set r7 9100000000000100000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 4096
jlt x6_parent_scratch_2
jmp x6_parent
label x6_done
load8 r6 9100000000000100200
set r0 0
label x6_done_scratch_1026
set r7 9100000000000100000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 4096
jlt x6_done_scratch_1026
set r0 0
label x6_done_work_1027
set r7 9100000000000120000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 8192
jlt x6_done_work_1027
set r0 0
label x6_done_input_1028
set r7 9100000000000200256
add r7 r0
store8 $r7 0
add r0 1
cmp r0 16384
jlt x6_done_input_1028
set r0 0
label x6_done_legacy_input_1029
set r7 7400000000000000128
add r7 r0
store8 $r7 0
add r0 1
cmp r0 256
jlt x6_done_legacy_input_1029
store8 7400000000000000016 0
store8 7400000000000000017 0
store8 9050000000000000008 0
store8 9050000000000000009 0
store8 9050000000000000010 0
store8 9050000000000000011 0
store8 8400000000000000012 0
store8 8400000000000000013 0
store8 9000000000000000032 0
store8 9100000000000200002 0
store8 9100000000000200003 0
store8 9100000000000200004 0
store8 9100000000000200008 0
store8 9100000000000200009 0
store8 9100000000000200010 0
cmp r6 1
jne x6_halt
store8 9100000000000200003 2
label x6_halt
halt

