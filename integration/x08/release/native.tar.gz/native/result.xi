#!reverse-pc-machine-v1
load8 r0 9090000000000000000
cmp r0 85
jne failure
load8 r0 9090000000000000001
cmp r0 1
jne failure
load8 r0 9090000000000000002
cmp r0 4
jne failure
load8 r0 9090000000000000007
cmp r0 1
jne failure
set r14 80
print r14
set r14 114
print r14
set r14 111
print r14
set r14 103
print r14
set r14 114
print r14
set r14 97
print r14
set r14 109
print r14
set r14 97
print r14
set r14 32
print r14
set r14 88
print r14
set r14 73
print r14
set r14 32
print r14
set r14 101
print r14
set r14 106
print r14
set r14 101
print r14
set r14 99
print r14
set r14 117
print r14
set r14 116
print r14
set r14 97
print r14
set r14 100
print r14
set r14 111
print r14
set r14 32
print r14
set r14 121
print r14
set r14 32
print r14
set r14 118
print r14
set r14 101
print r14
set r14 114
print r14
set r14 105
print r14
set r14 102
print r14
set r14 105
print r14
set r14 99
print r14
set r14 97
print r14
set r14 100
print r14
set r14 111
print r14
set r14 32
print r14
set r14 112
print r14
set r14 111
print r14
set r14 114
print r14
set r14 32
print r14
set r14 119
print r14
set r14 52
print r14
set r14 85
print r14
set r14 46
print r14
set r14 32
print r14
set r14 82
print r14
set r14 101
print r14
set r14 115
print r14
set r14 117
print r14
set r14 108
print r14
set r14 116
print r14
set r14 97
print r14
set r14 100
print r14
set r14 111
print r14
set r14 58
print r14
set r14 32
print r14
store8 9090000000000100000 0
label item
load8 r4 9090000000000100000
load8 r9 9090000000000000020
cmp r4 r9
jge done
cmp r4 0
je value
set r14 44
print r14
set r14 32
print r14
label value
mov r13 r4
mul r13 9
add r13 9090000000000000512
mov r7 r13
add r7 1
load8 r2 $r7
add r7 1
load8 r14 $r7
mul r14 256
add r2 r14
add r7 1
load8 r14 $r7
mul r14 65536
add r2 r14
add r7 1
load8 r14 $r7
mul r14 16777216
add r2 r14
add r7 1
load8 r14 $r7
mul r14 4294967296
add r2 r14
add r7 1
load8 r14 $r7
mul r14 1099511627776
add r2 r14
mov r7 r13
add r7 0
load8 r0 $r7
cmp r0 0
je positive
set r14 45
print r14
label positive
set r3 1000000000000
set r4 0
label digits
mov r14 r2
div r14 r3
cmp r14 0
jne digit
cmp r4 0
jne digit
cmp r3 1
jne skip
label digit
add r14 48
print r14
set r4 1
label skip
mod r2 r3
div r3 10
cmp r3 0
jgt digits
load8 r0 9090000000000100000
add r0 1
store8 9090000000000100000 r0
jmp item
label done
set r14 46
print r14
set r0 0
label x5_clean_0
set r7 9090000000000100000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 8192
jlt x5_clean_0
halt
label failure
set r14 76
print r14
set r14 97
print r14
set r14 32
print r14
set r14 116
print r14
set r14 97
print r14
set r14 114
print r14
set r14 101
print r14
set r14 97
print r14
set r14 32
print r14
set r14 88
print r14
set r14 73
print r14
set r14 32
print r14
set r14 110
print r14
set r14 111
print r14
set r14 32
print r14
set r14 113
print r14
set r14 117
print r14
set r14 101
print r14
set r14 100
print r14
set r14 195
print r14
set r14 179
print r14
set r14 32
print r14
set r14 101
print r14
set r14 106
print r14
set r14 101
print r14
set r14 99
print r14
set r14 117
print r14
set r14 116
print r14
set r14 97
print r14
set r14 100
print r14
set r14 97
print r14
set r14 32
print r14
set r14 121
print r14
set r14 32
print r14
set r14 118
print r14
set r14 101
print r14
set r14 114
print r14
set r14 105
print r14
set r14 102
print r14
set r14 105
print r14
set r14 99
print r14
set r14 97
print r14
set r14 100
print r14
set r14 97
print r14
set r14 46
print r14
set r14 32
print r14
set r14 82
print r14
set r14 101
print r14
set r14 118
print r14
set r14 105
print r14
set r14 115
print r14
set r14 97
print r14
set r14 32
print r14
set r14 101
print r14
set r14 108
print r14
set r14 32
print r14
set r14 100
print r14
set r14 105
print r14
set r14 97
print r14
set r14 103
print r14
set r14 110
print r14
set r14 195
print r14
set r14 179
print r14
set r14 115
print r14
set r14 116
print r14
set r14 105
print r14
set r14 99
print r14
set r14 111
print r14
set r14 32
print r14
set r14 100
print r14
set r14 101
print r14
set r14 108
print r14
set r14 32
print r14
set r14 97
print r14
set r14 110
print r14
set r14 102
print r14
set r14 105
print r14
set r14 116
print r14
set r14 114
print r14
set r14 105
print r14
set r14 195
print r14
set r14 179
print r14
set r14 110
print r14
set r14 46
print r14
halt
