#!reverse-pc-machine-v1
load8 r0 9090000000000000000
cmp r0 85
jne refused
load8 r0 9090000000000000001
cmp r0 1
jne refused
load8 r0 9090000000000000002
cmp r0 3
jne refused
load8 r0 9090000000000000010
load8 r1 9090000000000000256
cmp r0 r1
jne rejected
load8 r0 9090000000000000014
load8 r1 9090000000000000260
cmp r0 r1
jne rejected
load8 r0 9090000000000000011
load8 r1 9090000000000000257
cmp r0 r1
jne rejected
load8 r0 9090000000000000015
load8 r1 9090000000000000261
cmp r0 r1
jne rejected
load8 r0 9090000000000000012
load8 r1 9090000000000000258
cmp r0 r1
jne rejected
load8 r0 9090000000000000016
load8 r1 9090000000000000262
cmp r0 r1
jne rejected
load8 r0 9090000000000000013
load8 r1 9090000000000000259
cmp r0 r1
jne rejected
load8 r0 9090000000000000017
load8 r1 9090000000000000263
cmp r0 r1
jne rejected
load8 r0 9090000000000000032
load8 r1 9090000000000000264
cmp r0 r1
jne rejected
load8 r0 9090000000000000033
load8 r1 9090000000000000265
cmp r0 r1
jne rejected
load8 r0 9090000000000000034
load8 r1 9090000000000000266
cmp r0 r1
jne rejected
load8 r0 9090000000000000035
load8 r1 9090000000000000267
cmp r0 r1
jne rejected
load8 r0 9090000000000000036
load8 r1 9090000000000000268
cmp r0 r1
jne rejected
load8 r0 9090000000000000037
load8 r1 9090000000000000269
cmp r0 r1
jne rejected
load8 r0 9090000000000000038
load8 r1 9090000000000000270
cmp r0 r1
jne rejected
load8 r0 9090000000000000039
load8 r1 9090000000000000271
cmp r0 r1
jne rejected
load8 r0 9090000000000000040
load8 r1 9090000000000000272
cmp r0 r1
jne rejected
load8 r0 9090000000000000041
load8 r1 9090000000000000273
cmp r0 r1
jne rejected
load8 r0 9090000000000000042
load8 r1 9090000000000000274
cmp r0 r1
jne rejected
load8 r0 9090000000000000043
load8 r1 9090000000000000275
cmp r0 r1
jne rejected
load8 r0 9090000000000000044
load8 r1 9090000000000000276
cmp r0 r1
jne rejected
load8 r0 9090000000000000045
load8 r1 9090000000000000277
cmp r0 r1
jne rejected
load8 r0 9090000000000000046
load8 r1 9090000000000000278
cmp r0 r1
jne rejected
load8 r0 9090000000000000047
load8 r1 9090000000000000279
cmp r0 r1
jne rejected
load8 r0 9090000000000000048
load8 r1 9090000000000000280
cmp r0 r1
jne rejected
load8 r0 9090000000000000049
load8 r1 9090000000000000281
cmp r0 r1
jne rejected
load8 r0 9090000000000000050
load8 r1 9090000000000000282
cmp r0 r1
jne rejected
load8 r0 9090000000000000051
load8 r1 9090000000000000283
cmp r0 r1
jne rejected
load8 r0 9090000000000000052
load8 r1 9090000000000000284
cmp r0 r1
jne rejected
load8 r0 9090000000000000053
load8 r1 9090000000000000285
cmp r0 r1
jne rejected
load8 r0 9090000000000000054
load8 r1 9090000000000000286
cmp r0 r1
jne rejected
load8 r0 9090000000000000055
load8 r1 9090000000000000287
cmp r0 r1
jne rejected
load8 r0 9090000000000000056
load8 r1 9090000000000000288
cmp r0 r1
jne rejected
load8 r0 9090000000000000057
load8 r1 9090000000000000289
cmp r0 r1
jne rejected
load8 r0 9090000000000000058
load8 r1 9090000000000000290
cmp r0 r1
jne rejected
load8 r0 9090000000000000059
load8 r1 9090000000000000291
cmp r0 r1
jne rejected
load8 r0 9090000000000000060
load8 r1 9090000000000000292
cmp r0 r1
jne rejected
load8 r0 9090000000000000061
load8 r1 9090000000000000293
cmp r0 r1
jne rejected
load8 r0 9090000000000000062
load8 r1 9090000000000000294
cmp r0 r1
jne rejected
load8 r0 9090000000000000063
load8 r1 9090000000000000295
cmp r0 r1
jne rejected
load8 r0 9090000000000000296
cmp r0 1
jne rejected
load8 r0 9090000000000000297
cmp r0 1
jlt rejected
cmp r0 16
jgt rejected
store8 9090000000000000020 r0
load8 r1 9090000000000000003
cmp r1 5
je sort_check
cmp r0 1
jne rejected
cmp r1 1
je binary
cmp r1 2
je range
cmp r1 3
je factorial
cmp r1 4
je gcd
cmp r1 6
je guard
jmp rejected
label binary
set r13 9090000000000000064
mov r7 r13
add r7 1
load8 r0 $r7
add r7 1
load8 r14 $r7
mul r14 256
add r0 r14
add r7 1
load8 r14 $r7
mul r14 65536
add r0 r14
add r7 1
load8 r14 $r7
mul r14 16777216
add r0 r14
mov r7 r13
add r7 0
load8 r14 $r7
cmp r14 0
je x5_sg_0
mul r0 -1
label x5_sg_0
set r13 9090000000000000069
mov r7 r13
add r7 1
load8 r1 $r7
add r7 1
load8 r14 $r7
mul r14 256
add r1 r14
add r7 1
load8 r14 $r7
mul r14 65536
add r1 r14
add r7 1
load8 r14 $r7
mul r14 16777216
add r1 r14
mov r7 r13
add r7 0
load8 r14 $r7
cmp r14 0
je x5_sg_1
mul r1 -1
label x5_sg_1
load8 r2 9090000000000000004
cmp r2 1
je binary_add
cmp r2 2
je binary_sub
cmp r2 3
je binary_mul
cmp r1 0
je rejected
cmp r2 4
je binary_div
cmp r2 5
jne rejected
mod r0 r1
jmp binary_done
label binary_add
add r0 r1
jmp binary_done
label binary_sub
sub r0 r1
jmp binary_done
label binary_mul
mul r0 r1
jmp binary_done
label binary_div
div r0 r1
jmp binary_done
label binary_done
set r4 0
mov r13 r4
mul r13 9
add r13 9090000000000000512
mov r7 r13
add r7 7
load8 r14 $r7
cmp r14 0
jne rejected
mov r7 r13
add r7 8
load8 r14 $r7
cmp r14 0
jne rejected
mov r7 r13
add r7 1
load8 r1 $r7
add r7 1
load8 r14 $r7
mul r14 256
add r1 r14
add r7 1
load8 r14 $r7
mul r14 65536
add r1 r14
add r7 1
load8 r14 $r7
mul r14 16777216
add r1 r14
add r7 1
load8 r14 $r7
mul r14 4294967296
add r1 r14
add r7 1
load8 r14 $r7
mul r14 1099511627776
add r1 r14
cmp r1 1000000000000
jgt rejected
mov r7 r13
add r7 0
load8 r14 $r7
cmp r14 1
jgt rejected
cmp r14 0
je x5_obs_positive_2
mul r1 -1
label x5_obs_positive_2
cmp r0 r1
jne rejected
jmp approved
label range
set r13 9090000000000000064
mov r7 r13
add r7 1
load8 r0 $r7
add r7 1
load8 r14 $r7
mul r14 256
add r0 r14
add r7 1
load8 r14 $r7
mul r14 65536
add r0 r14
add r7 1
load8 r14 $r7
mul r14 16777216
add r0 r14
mov r7 r13
add r7 0
load8 r14 $r7
cmp r14 0
je x5_sg_3
mul r0 -1
label x5_sg_3
set r13 9090000000000000069
mov r7 r13
add r7 1
load8 r1 $r7
add r7 1
load8 r14 $r7
mul r14 256
add r1 r14
add r7 1
load8 r14 $r7
mul r14 65536
add r1 r14
add r7 1
load8 r14 $r7
mul r14 16777216
add r1 r14
mov r7 r13
add r7 0
load8 r14 $r7
cmp r14 0
je x5_sg_4
mul r1 -1
label x5_sg_4
mov r2 r1
sub r2 r0
add r2 1
add r0 r1
mul r0 r2
div r0 2
set r4 0
mov r13 r4
mul r13 9
add r13 9090000000000000512
mov r7 r13
add r7 7
load8 r14 $r7
cmp r14 0
jne rejected
mov r7 r13
add r7 8
load8 r14 $r7
cmp r14 0
jne rejected
mov r7 r13
add r7 1
load8 r1 $r7
add r7 1
load8 r14 $r7
mul r14 256
add r1 r14
add r7 1
load8 r14 $r7
mul r14 65536
add r1 r14
add r7 1
load8 r14 $r7
mul r14 16777216
add r1 r14
add r7 1
load8 r14 $r7
mul r14 4294967296
add r1 r14
add r7 1
load8 r14 $r7
mul r14 1099511627776
add r1 r14
cmp r1 1000000000000
jgt rejected
mov r7 r13
add r7 0
load8 r14 $r7
cmp r14 1
jgt rejected
cmp r14 0
je x5_obs_positive_5
mul r1 -1
label x5_obs_positive_5
cmp r0 r1
jne rejected
jmp approved
label factorial
set r13 9090000000000000064
mov r7 r13
add r7 1
load8 r5 $r7
add r7 1
load8 r14 $r7
mul r14 256
add r5 r14
add r7 1
load8 r14 $r7
mul r14 65536
add r5 r14
add r7 1
load8 r14 $r7
mul r14 16777216
add r5 r14
mov r7 r13
add r7 0
load8 r14 $r7
cmp r14 0
je x5_sg_6
mul r5 -1
label x5_sg_6
set r0 1
set r1 2
label factorial_reference
cmp r1 r5
jgt factorial_done
mul r0 r1
add r1 1
jmp factorial_reference
label factorial_done
set r4 0
mov r13 r4
mul r13 9
add r13 9090000000000000512
mov r7 r13
add r7 7
load8 r14 $r7
cmp r14 0
jne rejected
mov r7 r13
add r7 8
load8 r14 $r7
cmp r14 0
jne rejected
mov r7 r13
add r7 1
load8 r1 $r7
add r7 1
load8 r14 $r7
mul r14 256
add r1 r14
add r7 1
load8 r14 $r7
mul r14 65536
add r1 r14
add r7 1
load8 r14 $r7
mul r14 16777216
add r1 r14
add r7 1
load8 r14 $r7
mul r14 4294967296
add r1 r14
add r7 1
load8 r14 $r7
mul r14 1099511627776
add r1 r14
cmp r1 1000000000000
jgt rejected
mov r7 r13
add r7 0
load8 r14 $r7
cmp r14 1
jgt rejected
cmp r14 0
je x5_obs_positive_7
mul r1 -1
label x5_obs_positive_7
cmp r0 r1
jne rejected
jmp approved
label gcd
set r13 9090000000000000064
mov r7 r13
add r7 1
load8 r0 $r7
add r7 1
load8 r14 $r7
mul r14 256
add r0 r14
add r7 1
load8 r14 $r7
mul r14 65536
add r0 r14
add r7 1
load8 r14 $r7
mul r14 16777216
add r0 r14
mov r7 r13
add r7 0
load8 r14 $r7
cmp r14 0
je x5_sg_8
mul r0 -1
label x5_sg_8
set r13 9090000000000000069
mov r7 r13
add r7 1
load8 r1 $r7
add r7 1
load8 r14 $r7
mul r14 256
add r1 r14
add r7 1
load8 r14 $r7
mul r14 65536
add r1 r14
add r7 1
load8 r14 $r7
mul r14 16777216
add r1 r14
mov r7 r13
add r7 0
load8 r14 $r7
cmp r14 0
je x5_sg_9
mul r1 -1
label x5_sg_9
cmp r0 0
jge gcd_a_abs
mul r0 -1
label gcd_a_abs
cmp r1 0
jge gcd_abs_done
mul r1 -1
label gcd_abs_done
cmp r0 0
je gcd_return_b
cmp r1 0
je gcd_reference_done
set r2 1
label gcd_common_twos
mov r3 r0
mod r3 2
cmp r3 0
jne gcd_a_twos
mov r3 r1
mod r3 2
cmp r3 0
jne gcd_a_twos
div r0 2
div r1 2
mul r2 2
jmp gcd_common_twos
label gcd_a_twos
mov r3 r0
mod r3 2
cmp r3 0
jne gcd_b_twos
div r0 2
jmp gcd_a_twos
label gcd_b_twos
mov r3 r1
mod r3 2
cmp r3 0
jne gcd_subtract
div r1 2
jmp gcd_b_twos
label gcd_subtract
cmp r0 r1
jle gcd_ordered
mov r3 r0
mov r0 r1
mov r1 r3
label gcd_ordered
sub r1 r0
cmp r1 0
jne gcd_b_twos
mul r0 r2
jmp gcd_reference_done
label gcd_return_b
mov r0 r1
label gcd_reference_done
set r4 0
mov r13 r4
mul r13 9
add r13 9090000000000000512
mov r7 r13
add r7 7
load8 r14 $r7
cmp r14 0
jne rejected
mov r7 r13
add r7 8
load8 r14 $r7
cmp r14 0
jne rejected
mov r7 r13
add r7 1
load8 r1 $r7
add r7 1
load8 r14 $r7
mul r14 256
add r1 r14
add r7 1
load8 r14 $r7
mul r14 65536
add r1 r14
add r7 1
load8 r14 $r7
mul r14 16777216
add r1 r14
add r7 1
load8 r14 $r7
mul r14 4294967296
add r1 r14
add r7 1
load8 r14 $r7
mul r14 1099511627776
add r1 r14
cmp r1 1000000000000
jgt rejected
mov r7 r13
add r7 0
load8 r14 $r7
cmp r14 1
jgt rejected
cmp r14 0
je x5_obs_positive_10
mul r1 -1
label x5_obs_positive_10
cmp r0 r1
jne rejected
jmp approved
label guard
set r0 1
set r4 0
mov r13 r4
mul r13 9
add r13 9090000000000000512
mov r7 r13
add r7 7
load8 r14 $r7
cmp r14 0
jne rejected
mov r7 r13
add r7 8
load8 r14 $r7
cmp r14 0
jne rejected
mov r7 r13
add r7 1
load8 r1 $r7
add r7 1
load8 r14 $r7
mul r14 256
add r1 r14
add r7 1
load8 r14 $r7
mul r14 65536
add r1 r14
add r7 1
load8 r14 $r7
mul r14 16777216
add r1 r14
add r7 1
load8 r14 $r7
mul r14 4294967296
add r1 r14
add r7 1
load8 r14 $r7
mul r14 1099511627776
add r1 r14
cmp r1 1000000000000
jgt rejected
mov r7 r13
add r7 0
load8 r14 $r7
cmp r14 1
jgt rejected
cmp r14 0
je x5_obs_positive_11
mul r1 -1
label x5_obs_positive_11
cmp r0 r1
jne rejected
jmp approved
label sort_check
load8 r0 9090000000000000005
load8 r1 9090000000000000297
cmp r0 r1
jne rejected
set r4 0
label sort_order
load8 r9 9090000000000000005
cmp r4 r9
jge sort_multiset
mov r13 r4
mul r13 9
add r13 9090000000000000512
mov r7 r13
add r7 7
load8 r14 $r7
cmp r14 0
jne rejected
mov r7 r13
add r7 8
load8 r14 $r7
cmp r14 0
jne rejected
mov r7 r13
add r7 1
load8 r0 $r7
add r7 1
load8 r14 $r7
mul r14 256
add r0 r14
add r7 1
load8 r14 $r7
mul r14 65536
add r0 r14
add r7 1
load8 r14 $r7
mul r14 16777216
add r0 r14
add r7 1
load8 r14 $r7
mul r14 4294967296
add r0 r14
add r7 1
load8 r14 $r7
mul r14 1099511627776
add r0 r14
cmp r0 1000000000000
jgt rejected
mov r7 r13
add r7 0
load8 r14 $r7
cmp r14 1
jgt rejected
cmp r14 0
je x5_obs_positive_12
mul r0 -1
label x5_obs_positive_12
cmp r0 -32768
jlt rejected
cmp r0 32767
jgt rejected
cmp r4 0
je sort_order_next
mov r5 r4
sub r5 1
mov r13 r5
mul r13 9
add r13 9090000000000000512
mov r7 r13
add r7 7
load8 r14 $r7
cmp r14 0
jne rejected
mov r7 r13
add r7 8
load8 r14 $r7
cmp r14 0
jne rejected
mov r7 r13
add r7 1
load8 r1 $r7
add r7 1
load8 r14 $r7
mul r14 256
add r1 r14
add r7 1
load8 r14 $r7
mul r14 65536
add r1 r14
add r7 1
load8 r14 $r7
mul r14 16777216
add r1 r14
add r7 1
load8 r14 $r7
mul r14 4294967296
add r1 r14
add r7 1
load8 r14 $r7
mul r14 1099511627776
add r1 r14
cmp r1 1000000000000
jgt rejected
mov r7 r13
add r7 0
load8 r14 $r7
cmp r14 1
jgt rejected
cmp r14 0
je x5_obs_positive_13
mul r1 -1
label x5_obs_positive_13
cmp r1 r0
jgt rejected
label sort_order_next
add r4 1
jmp sort_order
label sort_multiset
set r4 0
label sort_input_value
load8 r9 9090000000000000005
cmp r4 r9
jge approved
mov r13 r4
mul r13 5
add r13 9090000000000000064
mov r7 r13
add r7 1
load8 r5 $r7
add r7 1
load8 r14 $r7
mul r14 256
add r5 r14
add r7 1
load8 r14 $r7
mul r14 65536
add r5 r14
add r7 1
load8 r14 $r7
mul r14 16777216
add r5 r14
mov r7 r13
add r7 0
load8 r14 $r7
cmp r14 0
je x5_sg_14
mul r5 -1
label x5_sg_14
set r6 0
set r10 0
set r11 0
label sort_frequency
load8 r9 9090000000000000005
cmp r6 r9
jge sort_frequency_done
mov r13 r6
mul r13 5
add r13 9090000000000000064
mov r7 r13
add r7 1
load8 r0 $r7
add r7 1
load8 r14 $r7
mul r14 256
add r0 r14
add r7 1
load8 r14 $r7
mul r14 65536
add r0 r14
add r7 1
load8 r14 $r7
mul r14 16777216
add r0 r14
mov r7 r13
add r7 0
load8 r14 $r7
cmp r14 0
je x5_sg_15
mul r0 -1
label x5_sg_15
cmp r0 r5
jne sort_frequency_output
add r10 1
label sort_frequency_output
mov r13 r6
mul r13 9
add r13 9090000000000000512
mov r7 r13
add r7 7
load8 r14 $r7
cmp r14 0
jne rejected
mov r7 r13
add r7 8
load8 r14 $r7
cmp r14 0
jne rejected
mov r7 r13
add r7 1
load8 r0 $r7
add r7 1
load8 r14 $r7
mul r14 256
add r0 r14
add r7 1
load8 r14 $r7
mul r14 65536
add r0 r14
add r7 1
load8 r14 $r7
mul r14 16777216
add r0 r14
add r7 1
load8 r14 $r7
mul r14 4294967296
add r0 r14
add r7 1
load8 r14 $r7
mul r14 1099511627776
add r0 r14
cmp r0 1000000000000
jgt rejected
mov r7 r13
add r7 0
load8 r14 $r7
cmp r14 1
jgt rejected
cmp r14 0
je x5_obs_positive_16
mul r0 -1
label x5_obs_positive_16
cmp r0 r5
jne sort_frequency_next
add r11 1
label sort_frequency_next
add r6 1
jmp sort_frequency
label sort_frequency_done
cmp r10 r11
jne rejected
add r4 1
jmp sort_input_value
label approved
store8 9090000000000000002 4
store8 9090000000000000007 1
set r0 0
label x5_review_clean_17
set r7 9090000000000100000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 8192
jlt x5_review_clean_17
set r0 0
print r0
halt
label rejected
store8 9090000000000000002 5
store8 9090000000000000007 2
set r0 0
label x5_reject_clean_18
set r7 9090000000000100000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 8192
jlt x5_reject_clean_18
set r0 1
print r0
halt
label refused
set r0 1
print r0
halt
