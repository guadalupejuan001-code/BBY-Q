#!reverse-pc-machine-v1
load8 r0 9110000000000000001
cmp r0 1
je apply
cmp r0 2
jne refuse
halt
label apply
store8 9110000000000000001 2
halt
label refuse
set r0 0
mod r0 0
