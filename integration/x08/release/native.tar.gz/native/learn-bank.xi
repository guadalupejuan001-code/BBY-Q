#!reverse-pc-machine-v1
load8 r0 9110000000000000000
cmp r0 87
jne x7_bank_unowned
load8 r0 9110000000000000001
cmp r0 2
jne x7_bank_unowned
load8 r0 9110000000000000002
load8 r14 9110000000000000003
mul r14 256
add r0 r14
cmp r0 4096
jgt x7_bank_unowned
load8 r0 9110000000000000008
load8 r14 9110000000000000009
mul r14 256
add r0 r14
load8 r14 9110000000000000010
mul r14 65536
add r0 r14
load8 r14 9110000000000000011
mul r14 16777216
add r0 r14
cmp r0 4294967295
jge x7_bank_revision
load8 r0 9110000000004000000
cmp r0 1
jlt x7_bank_invalid
cmp r0 7
jgt x7_bank_invalid
cmp r0 4
jge x7_bank_rule
load8 r0 9110000000004000257
cmp r0 1
jlt x7_bank_invalid
cmp r0 64
jgt x7_bank_invalid
load8 r0 9110000000004000000
cmp r0 3
je x7_bank_fields_ready
load8 r0 9110000000004000258
cmp r0 1
jlt x7_bank_invalid
cmp r0 224
jgt x7_bank_invalid
load8 r0 9110000000004000259
cmp r0 1
jlt x7_bank_invalid
cmp r0 224
jgt x7_bank_invalid
load8 r0 9110000000004000260
cmp r0 1
jlt x7_bank_invalid
cmp r0 32
jgt x7_bank_invalid
load8 r0 9110000000004000261
cmp r0 1
jlt x7_bank_invalid
cmp r0 32
jgt x7_bank_invalid
load8 r0 9110000000004000262
cmp r0 5
jgt x7_bank_invalid
label x7_bank_fields_ready
set r10 0
label x7_bank_field
cmp r10 0
je x7_bank_key_field
cmp r10 1
je x7_bank_definition_field
cmp r10 2
je x7_bank_requirement_field
cmp r10 3
je x7_bank_source_field
set r8 9110000000004000816
load8 r9 9110000000004000261
jmp x7_bank_utf8_begin
label x7_bank_key_field
set r8 9110000000004000272
load8 r9 9110000000004000257
jmp x7_bank_utf8_begin
label x7_bank_definition_field
set r8 9110000000004000336
load8 r9 9110000000004000258
jmp x7_bank_utf8_begin
label x7_bank_requirement_field
set r8 9110000000004000560
load8 r9 9110000000004000259
jmp x7_bank_utf8_begin
label x7_bank_source_field
set r8 9110000000004000784
load8 r9 9110000000004000260
jmp x7_bank_utf8_begin
label x7_bank_utf8_begin
set r4 0
label x7_bank_utf8
cmp r4 r9
jge x7_bank_utf8_done
mov r7 r8
add r7 r4
load8 r3 $r7
add r4 1
cmp r3 128
jge x7_bank_lead
cmp r3 32
jlt x7_bank_invalid
cmp r3 127
je x7_bank_invalid
jmp x7_bank_utf8
label x7_bank_lead
cmp r3 194
jlt x7_bank_invalid
cmp r3 223
jle x7_bank_two
cmp r3 239
jle x7_bank_three
cmp r3 244
jle x7_bank_four
jmp x7_bank_invalid
label x7_bank_two
set r5 1
set r6 128
set r11 191
jmp x7_bank_cont
label x7_bank_three
set r5 2
set r6 128
set r11 191
cmp r3 224
jne x7_bank_not_e0
set r6 160
label x7_bank_not_e0
cmp r3 237
jne x7_bank_cont
set r11 159
jmp x7_bank_cont
label x7_bank_four
set r5 3
set r6 128
set r11 191
cmp r3 240
jne x7_bank_not_f0
set r6 144
label x7_bank_not_f0
cmp r3 244
jne x7_bank_cont
set r11 143
label x7_bank_cont
cmp r4 r9
jge x7_bank_invalid
mov r7 r8
add r7 r4
load8 r3 $r7
cmp r3 r6
jlt x7_bank_invalid
cmp r3 r11
jgt x7_bank_invalid
add r4 1
sub r5 1
cmp r5 0
je x7_bank_utf8
set r6 128
set r11 191
jmp x7_bank_cont
label x7_bank_utf8_done
load8 r0 9110000000004000000
cmp r0 3
je x7_bank_normalize
add r10 1
cmp r10 5
jlt x7_bank_field
label x7_bank_normalize
load8 r9 9110000000004000257
set r4 0
label x7_bank_lower
cmp r4 r9
jge x7_bank_find_begin
set r7 9110000000004000272
add r7 r4
load8 r3 $r7
cmp r3 65
jlt x7_bank_lower_next
cmp r3 90
jgt x7_bank_lower_next
add r3 32
store8 $r7 r3
label x7_bank_lower_next
add r4 1
jmp x7_bank_lower
label x7_bank_find_begin
set r0 65535
mov r14 r0
mod r14 256
store8 9110000000004000042 r14
mov r14 r0
div r14 256
mod r14 256
store8 9110000000004000043 r14
set r10 0
label x7_bank_find
mov r13 r10
mul r13 640
add r13 9110000000000004096
mov r7 r13
add r7 0
load8 r0 $r7
cmp r0 0
je x7_bank_empty_slot
cmp r0 1
jne x7_bank_invalid
mov r7 r13
add r7 1
load8 r0 $r7
load8 r9 9110000000004000257
cmp r0 r9
jne x7_bank_next
set r4 0
label x7_bank_key_compare
cmp r4 r9
jge x7_bank_found
mov r7 r13
add r7 16
add r7 r4
load8 r2 $r7
set r7 9110000000004000272
add r7 r4
load8 r3 $r7
cmp r2 r3
jne x7_bank_next
add r4 1
jmp x7_bank_key_compare
label x7_bank_empty_slot
load8 r0 9110000000004000042
load8 r14 9110000000004000043
mul r14 256
add r0 r14
cmp r0 65535
jne x7_bank_next
mov r14 r10
mod r14 256
store8 9110000000004000042 r14
mov r14 r10
div r14 256
mod r14 256
store8 9110000000004000043 r14
label x7_bank_next
add r10 1
cmp r10 4096
jlt x7_bank_find
load8 r0 9110000000004000000
cmp r0 3
je x7_bank_ok
cmp r0 2
je x7_bank_missing
load8 r10 9110000000004000042
load8 r14 9110000000004000043
mul r14 256
add r10 r14
cmp r10 65535
je x7_bank_full
mov r13 r10
mul r13 640
add r13 9110000000000004096
load8 r0 9110000000000000002
load8 r14 9110000000000000003
mul r14 256
add r0 r14
cmp r0 4096
jge x7_bank_full
add r0 1
mov r14 r0
mod r14 256
store8 9110000000000000002 r14
mov r14 r0
div r14 256
mod r14 256
store8 9110000000000000003 r14
jmp x7_bank_write
label x7_bank_found
load8 r0 9110000000004000000
cmp r0 3
je x7_bank_delete
cmp r0 2
jne x7_bank_compare_fields
mov r7 r13
add r7 8
load8 r1 $r7
add r7 1
load8 r14 $r7
mul r14 256
add r1 r14
add r7 1
load8 r14 $r7
mul r14 65536
add r1 r14
add r7 1
load8 r14 $r7
mul r14 16777216
add r1 r14
load8 r2 9110000000004000032
load8 r14 9110000000004000033
mul r14 256
add r2 r14
load8 r14 9110000000004000034
mul r14 65536
add r2 r14
load8 r14 9110000000004000035
mul r14 16777216
add r2 r14
cmp r1 r2
jne x7_bank_revision
label x7_bank_compare_fields
set r4 1
label x7_bank_compare_byte
cmp r4 8
je x7_bank_compare_payload
cmp r4 592
jge x7_bank_ok
mov r7 r13
add r7 r4
load8 r2 $r7
set r7 9110000000004000256
add r7 r4
load8 r3 $r7
cmp r2 r3
jne x7_bank_different
add r4 1
jmp x7_bank_compare_byte
label x7_bank_compare_payload
set r4 16
jmp x7_bank_compare_byte
label x7_bank_different
load8 r0 9110000000004000000
cmp r0 2
jne x7_bank_conflict
label x7_bank_write
load8 r6 9110000000000000008
load8 r14 9110000000000000009
mul r14 256
add r6 r14
load8 r14 9110000000000000010
mul r14 65536
add r6 r14
load8 r14 9110000000000000011
mul r14 16777216
add r6 r14
cmp r6 4294967295
jge x7_bank_revision
add r6 1
mov r14 r6
mod r14 256
store8 9110000000000000008 r14
mov r14 r6
div r14 256
mod r14 256
store8 9110000000000000009 r14
mov r14 r6
div r14 65536
mod r14 256
store8 9110000000000000010 r14
mov r14 r6
div r14 16777216
mod r14 256
store8 9110000000000000011 r14
set r4 0
label x7_bank_write_byte
set r7 9110000000004000256
add r7 r4
load8 r3 $r7
mov r7 r13
add r7 r4
store8 $r7 r3
add r4 1
cmp r4 640
jlt x7_bank_write_byte
store8 $r13 1
mov r7 r13
add r7 8
mov r14 r6
mod r14 256
store8 $r7 r14
mov r7 r13
add r7 9
mov r14 r6
div r14 256
mod r14 256
store8 $r7 r14
mov r7 r13
add r7 10
mov r14 r6
div r14 65536
mod r14 256
store8 $r7 r14
mov r7 r13
add r7 11
mov r14 r6
div r14 16777216
mod r14 256
store8 $r7 r14
jmp x7_bank_ok
label x7_bank_delete
load8 r6 9110000000000000008
load8 r14 9110000000000000009
mul r14 256
add r6 r14
load8 r14 9110000000000000010
mul r14 65536
add r6 r14
load8 r14 9110000000000000011
mul r14 16777216
add r6 r14
cmp r6 4294967295
jge x7_bank_revision
add r6 1
mov r14 r6
mod r14 256
store8 9110000000000000008 r14
mov r14 r6
div r14 256
mod r14 256
store8 9110000000000000009 r14
mov r14 r6
div r14 65536
mod r14 256
store8 9110000000000000010 r14
mov r14 r6
div r14 16777216
mod r14 256
store8 9110000000000000011 r14
set r4 0
label x7_bank_delete_byte
mov r7 r13
add r7 r4
store8 $r7 0
add r4 1
cmp r4 640
jlt x7_bank_delete_byte
load8 r0 9110000000000000002
load8 r14 9110000000000000003
mul r14 256
add r0 r14
sub r0 1
mov r14 r0
mod r14 256
store8 9110000000000000002 r14
mov r14 r0
div r14 256
mod r14 256
store8 9110000000000000003 r14
jmp x7_bank_ok
label x7_bank_rule
load8 r10 9110000000004000000
cmp r10 4
je x7_bank_percent
cmp r10 6
je x7_bank_percent
set r13 9110000000000000640
set r11 3
jmp x7_bank_rule_validate
label x7_bank_percent
set r13 9110000000000000512
set r11 1
label x7_bank_rule_validate
set r4 0
set r5 0
label x7_bank_rule_rate
set r7 9110000000004000256
add r7 r4
load8 r3 $r7
cmp r3 100
jgt x7_bank_invalid
add r5 r3
add r4 1
cmp r4 r11
jlt x7_bank_rule_rate
cmp r11 1
je x7_bank_rule_existing
cmp r5 100
jne x7_bank_invalid
label x7_bank_rule_existing
mov r7 r13
add r7 0
load8 r0 $r7
cmp r0 0
je x7_bank_rule_store
cmp r0 1
jne x7_bank_invalid
cmp r10 6
jge x7_bank_rule_revision
set r4 0
label x7_bank_rule_same
mov r7 r13
add r7 1
add r7 r4
load8 r2 $r7
set r7 9110000000004000256
add r7 r4
load8 r3 $r7
cmp r2 r3
jne x7_bank_conflict
add r4 1
cmp r4 r11
jlt x7_bank_rule_same
jmp x7_bank_ok
label x7_bank_rule_revision
mov r7 r13
add r7 4
load8 r1 $r7
add r7 1
load8 r14 $r7
mul r14 256
add r1 r14
add r7 1
load8 r14 $r7
mul r14 65536
add r1 r14
add r7 1
load8 r14 $r7
mul r14 16777216
add r1 r14
load8 r2 9110000000004000032
load8 r14 9110000000004000033
mul r14 256
add r2 r14
load8 r14 9110000000004000034
mul r14 65536
add r2 r14
load8 r14 9110000000004000035
mul r14 16777216
add r2 r14
cmp r1 r2
jne x7_bank_revision
label x7_bank_rule_store
load8 r6 9110000000000000008
load8 r14 9110000000000000009
mul r14 256
add r6 r14
load8 r14 9110000000000000010
mul r14 65536
add r6 r14
load8 r14 9110000000000000011
mul r14 16777216
add r6 r14
cmp r6 4294967295
jge x7_bank_revision
add r6 1
mov r14 r6
mod r14 256
store8 9110000000000000008 r14
mov r14 r6
div r14 256
mod r14 256
store8 9110000000000000009 r14
mov r14 r6
div r14 65536
mod r14 256
store8 9110000000000000010 r14
mov r14 r6
div r14 16777216
mod r14 256
store8 9110000000000000011 r14
store8 $r13 1
set r4 0
label x7_bank_rule_copy
set r7 9110000000004000256
add r7 r4
load8 r3 $r7
mov r7 r13
add r7 1
add r7 r4
store8 $r7 r3
add r4 1
cmp r4 r11
jlt x7_bank_rule_copy
mov r7 r13
add r7 4
mov r14 r6
mod r14 256
store8 $r7 r14
mov r7 r13
add r7 5
mov r14 r6
div r14 256
mod r14 256
store8 $r7 r14
mov r7 r13
add r7 6
mov r14 r6
div r14 65536
mod r14 256
store8 $r7 r14
mov r7 r13
add r7 7
mov r14 r6
div r14 16777216
mod r14 256
store8 $r7 r14
jmp x7_bank_ok
label x7_bank_ok
set r0 0
jmp x7_bank_finish
label x7_bank_invalid
set r0 1
jmp x7_bank_finish
label x7_bank_conflict
set r0 2
jmp x7_bank_finish
label x7_bank_missing
set r0 3
jmp x7_bank_finish
label x7_bank_full
set r0 4
jmp x7_bank_finish
label x7_bank_revision
set r0 5
jmp x7_bank_finish
label x7_bank_finish
store8 9110000000004000001 r0
print r0
set r4 0
label x7_bank_erase
set r7 9110000000004000000
add r7 r4
store8 $r7 0
add r4 1
cmp r4 8192
jlt x7_bank_erase
halt
label x7_bank_unowned
set r0 1
print r0
halt
