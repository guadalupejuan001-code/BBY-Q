#!reverse-pc-machine-v1
load8 r0 9100000000000200000
cmp r0 86
jne x6finish_refuse
load8 r0 9100000000000200001
cmp r0 2
jne x6finish_refuse
set r0 0
label x6finish_payload
set r7 9100000000000200000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 16640
jlt x6finish_payload
store8 9100000000000200000 86
store8 9100000000000200001 2
set r0 0
label x6finish_scratch
set r7 9100000000000100000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 4096
jlt x6finish_scratch
set r0 0
label x6finish_work
set r7 9100000000000120000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 8192
jlt x6finish_work
store8 9120000000000000002 0
halt
label x6finish_refuse
set r0 0
mod r0 0
