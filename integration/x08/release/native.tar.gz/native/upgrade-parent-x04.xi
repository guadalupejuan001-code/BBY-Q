#!reverse-pc-machine-v1
load8 r0 9080000000000000000
cmp r0 0
je x4up_empty
cmp r0 84
jne x4up_refuse
load8 r0 9080000000000000001
cmp r0 1
jne x4up_refuse
load8 r0 9080000000000000002
cmp r0 24
jgt x4up_refuse
load8 r0 9080000000000000003
cmp r0 64
jgt x4up_refuse
jmp x4up_scratch
label x4up_empty
set r0 0
label x4up_scan
set r7 9080000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x4up_refuse
add r0 1
cmp r0 2048
jlt x4up_scan
label x4up_scratch
set r0 0
label x4up_scratch_scan
set r7 9080000000000100000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x4up_refuse
add r0 1
cmp r0 12288
jlt x4up_scratch_scan
jmp x4up_parent
label x4up_refuse
set r0 0
mod r0 0

label x4up_parent
load8 r0 9070000000000000000
cmp r0 83
jne x4up_refuse
load8 r0 9070000000000000001
cmp r0 1
jne x4up_refuse
load8 r0 9070000000000000000
cmp r0 0
je x3up_empty
cmp r0 83
jne x3up_refuse
load8 r0 9070000000000000001
cmp r0 1
jne x3up_refuse
load8 r0 9070000000000000002
cmp r0 128
jgt x3up_refuse
load8 r0 9070000000000000012
cmp r0 16
jgt x3up_refuse
jmp x3up_scratch
label x3up_empty
set r0 0
label x3up_scan
set r7 9070000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x3up_refuse
add r0 1
cmp r0 32768
jlt x3up_scan
label x3up_scratch
set r0 0
label x3up_scratch_scan
set r7 9070000000000100000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x3up_refuse
add r0 1
cmp r0 1024
jlt x3up_scratch_scan
jmp x3up_prior_guard
label x3up_refuse
set r0 0
mod r0 0

label x3up_prior_guard
load8 r0 9060000000000000000
cmp r0 0
je x2up_unowned
cmp r0 82
jne x2up_refuse
load8 r0 9060000000000000001
cmp r0 1
jne x2up_refuse
load8 r0 9060000000000000002
cmp r0 32
jgt x2up_refuse
load8 r0 9060000000000000003
cmp r0 128
jgt x2up_refuse
jmp x2up_scratch
label x2up_unowned
set r0 0
label x2up_bank_scan
set r7 9060000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x2up_refuse
add r0 1
cmp r0 24576
jlt x2up_bank_scan
label x2up_scratch
set r0 0
label x2up_scratch_scan
set r7 9060000000000100000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x2up_refuse
add r0 1
cmp r0 2048
jlt x2up_scratch_scan
jmp x2up_prior_guard
label x2up_refuse
set r0 0
mod r0 0

label x2up_prior_guard
# Read-only namespace ownership guard. Run BEFORE transporting any lesson.
load8 r0 9050000000000000000
cmp r0 0
je xg_empty
cmp r0 88
jne xg_invalid
load8 r0 9050000000000000001
cmp r0 1
jne xg_invalid
load8 r0 9050000000000000002
cmp r0 128
jgt xg_invalid
jmp x4up_finish
label xg_empty
set r0 0
label xg_each
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne xg_invalid
add r0 1
cmp r0 16384
jlt xg_each
jmp x4up_finish
label xg_invalid
div r0 0

label x4up_finish
load8 r0 9080000000000000000
cmp r0 84
je x4up_halt
store8 9080000000000000000 84
store8 9080000000000000001 1
label x4up_halt
halt
