#!reverse-pc-machine-v1
load8 r0 9090000000000000000
cmp r0 85
jne denied
load8 r0 9090000000000000001
cmp r0 1
jne denied
load8 r0 9090000000000000002
cmp r0 2
jne denied
load8 r0 8300000000000000016
cmp r0 2
je denied
load8 r0 8300000000000000768
cmp r0 2
jne denied
load8 r0 8300000000000000773
cmp r0 1
jne denied
load8 r0 9090000000000000014
load8 r1 8460000000000000060
cmp r0 r1
jne denied
load8 r0 9090000000000000032
load8 r1 8300000000000000780
cmp r0 r1
jne denied
load8 r0 9090000000000000015
load8 r1 8460000000000000061
cmp r0 r1
jne denied
load8 r0 9090000000000000033
load8 r1 8300000000000000781
cmp r0 r1
jne denied
load8 r0 9090000000000000016
load8 r1 8460000000000000062
cmp r0 r1
jne denied
load8 r0 9090000000000000034
load8 r1 8300000000000000782
cmp r0 r1
jne denied
load8 r0 9090000000000000017
load8 r1 8460000000000000063
cmp r0 r1
jne denied
load8 r0 9090000000000000035
load8 r1 8300000000000000783
cmp r0 r1
jne denied
store8 9090000000000000002 3
store8 9090000000000000007 0
store8 9090000000000000020 0
set r0 0
label x5_clear_receipt_0
set r7 9090000000000000256
add r7 r0
store8 $r7 0
add r0 1
cmp r0 44
jlt x5_clear_receipt_0
set r0 0
label x5_clear_output_1
set r7 9090000000000000512
add r7 r0
store8 $r7 0
add r0 1
cmp r0 144
jlt x5_clear_output_1
set r0 0
label x5_prior_transient_2
set r7 8460000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 128
jlt x5_prior_transient_2
set r0 0
label x5_prior_ticket_3
set r7 8300000000000000768
add r7 r0
store8 $r7 0
add r0 1
cmp r0 18
jlt x5_prior_ticket_3
set r0 0
print r0
halt
label denied
set r0 1
print r0
halt
