#!reverse-pc-machine-v1
load8 r0 9060000000000000000
cmp r0 0
je x2up_unowned
cmp r0 82
jne x2up_refuse
load8 r0 9060000000000000001
cmp r0 1
jne x2up_refuse
load8 r0 9060000000000000002
cmp r0 32
jgt x2up_refuse
load8 r0 9060000000000000003
cmp r0 128
jgt x2up_refuse
jmp x2up_scratch
label x2up_unowned
set r0 0
label x2up_bank_scan
set r7 9060000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x2up_refuse
add r0 1
cmp r0 24576
jlt x2up_bank_scan
label x2up_scratch
set r0 0
label x2up_scratch_scan
set r7 9060000000000100000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x2up_refuse
add r0 1
cmp r0 2048
jlt x2up_scratch_scan
jmp x2up_parent
label x2up_refuse
set r0 0
mod r0 0

label x2up_parent
load8 r0 9050000000000000000
cmp r0 88
je x2up_owned
jmp x2up_old_upgrade
label x2up_owned
# Read-only namespace ownership guard. Run BEFORE transporting any lesson.
load8 r0 9050000000000000000
cmp r0 0
je x2own_empty
cmp r0 88
jne x2own_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x2own_invalid
load8 r0 9050000000000000002
cmp r0 128
jgt x2own_invalid
jmp x2up_finish
label x2own_empty
set r0 0
label x2own_each
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x2own_invalid
add r0 1
cmp r0 16384
jlt x2own_each
jmp x2up_finish
label x2own_invalid
div r0 0

label x2up_old_upgrade
# Read-only namespace ownership guard. Run BEFORE transporting any lesson.
load8 r0 9050000000000000000
cmp r0 0
je xg_empty
cmp r0 88
jne xg_invalid
load8 r0 9050000000000000001
cmp r0 1
jne xg_invalid
load8 r0 9050000000000000002
cmp r0 128
jgt xg_invalid
jmp x01_lesson_0
label xg_empty
set r0 0
label xg_each
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne xg_invalid
add r0 1
cmp r0 16384
jlt xg_each
jmp x01_lesson_0
label xg_invalid
div r0 0

label x01_lesson_0
store8 9050000000000000016 1
store8 9050000000000000017 1
store8 9050000000000000018 0
store8 9050000000000000019 4
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 104
store8 9050000000000000273 111
store8 9050000000000000274 108
store8 9050000000000000275 97
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_0_xt_blank
cmp r0 88
jne x01_0_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_0_xt_invalid
jmp x01_0_xt_validate
label x01_0_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_0_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_0_xt_invalid
add r0 1
cmp r0 16
jlt x01_0_xt_blank_header
set r0 32
label x01_0_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_0_xt_invalid
add r0 1
cmp r0 144
jlt x01_0_xt_blank_context
set r0 4096
label x01_0_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_0_xt_invalid
add r0 1
cmp r0 16384
jlt x01_0_xt_blank_bank
label x01_0_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_0_xt_invalid
cmp r0 0
je x01_0_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_0_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_0_xt_invalid
cmp r0 17
jgt x01_0_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_0_xt_invalid
label x01_0_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_0_xt_invalid
cmp r0 4
jgt x01_0_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_0_xt_invalid
cmp r0 1
jne x01_0_xt_modifier
cmp r1 1
jlt x01_0_xt_invalid
cmp r1 17
jgt x01_0_xt_invalid
jmp x01_0_xt_prepare
label x01_0_xt_modifier
cmp r1 0
jne x01_0_xt_invalid
cmp r2 0
jne x01_0_xt_invalid
label x01_0_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_0_xtn_begin
label x01_0_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_0_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_0_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_0_xt_invalid
set r10 0
label x01_0_xt_lookup
cmp r10 r6
jge x01_0_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_0_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_0_xt_next
set r0 0
label x01_0_xt_compare
cmp r0 r12
jge x01_0_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_0_xt_next
add r0 1
jmp x01_0_xt_compare
label x01_0_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_0_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_0_xt_correct
jmp x01_0_xt_clean
label x01_0_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_0_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_0_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_0_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_0_xt_clean
label x01_0_xt_next
add r10 1
jmp x01_0_xt_lookup
label x01_0_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_0_xt_invalid
cmp r6 128
jge x01_0_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_0_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_0_xt_invalid
add r0 1
cmp r0 96
jlt x01_0_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_0_xt_copy
cmp r0 r12
jge x01_0_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_0_xt_copy
label x01_0_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_0_xt_clean
set r0 16
label x01_0_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_0_xt_clean_mailbox
set r0 256
label x01_0_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_0_xt_clean_scratch
jmp x01_lesson_1
label x01_0_xt_invalid
div r0 0

label x01_0_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_0_xtn_done
cmp r9 255
jgt x01_0_xtn_done
label x01_0_xtn_each
cmp r0 r9
jge x01_0_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_0_xtn_inverted
cmp r3 195
je x01_0_xtn_accent
cmp r3 226
je x01_0_xtn_unicode_space
cmp r3 32
je x01_0_xtn_space
cmp r3 44
je x01_0_xtn_space
cmp r3 46
je x01_0_xtn_space
cmp r3 33
je x01_0_xtn_space
cmp r3 63
je x01_0_xtn_space
cmp r3 65
jlt x01_0_xtn_ascii
cmp r3 90
jgt x01_0_xtn_ascii
add r3 32
label x01_0_xtn_ascii
cmp r3 97
jlt x01_0_xtn_digit
cmp r3 122
jle x01_0_xtn_append
label x01_0_xtn_digit
cmp r3 48
jlt x01_0_xtn_done
cmp r3 57
jgt x01_0_xtn_done
jmp x01_0_xtn_append
label x01_0_xtn_inverted
add r0 1
cmp r0 r9
jge x01_0_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_0_xtn_space
cmp r3 191
je x01_0_xtn_space
cmp r3 161
je x01_0_xtn_space
jmp x01_0_xtn_done
label x01_0_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_0_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_0_xtn_done
add r0 1
cmp r0 r9
jge x01_0_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_0_xtn_space
cmp r3 175
je x01_0_xtn_space
jmp x01_0_xtn_done
label x01_0_xtn_accent
add r0 1
cmp r0 r9
jge x01_0_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_0_xtn_a
cmp r3 161
je x01_0_xtn_a
cmp r3 137
je x01_0_xtn_e
cmp r3 169
je x01_0_xtn_e
cmp r3 141
je x01_0_xtn_i
cmp r3 173
je x01_0_xtn_i
cmp r3 147
je x01_0_xtn_o
cmp r3 179
je x01_0_xtn_o
cmp r3 154
je x01_0_xtn_u
cmp r3 186
je x01_0_xtn_u
cmp r3 145
je x01_0_xtn_n
cmp r3 177
je x01_0_xtn_n
jmp x01_0_xtn_done
label x01_0_xtn_a
set r3 97
jmp x01_0_xtn_append
label x01_0_xtn_e
set r3 101
jmp x01_0_xtn_append
label x01_0_xtn_i
set r3 105
jmp x01_0_xtn_append
label x01_0_xtn_o
set r3 111
jmp x01_0_xtn_append
label x01_0_xtn_u
set r3 117
jmp x01_0_xtn_append
label x01_0_xtn_n
set r3 110
jmp x01_0_xtn_append
label x01_0_xtn_space
cmp r1 0
je x01_0_xtn_next
set r2 1
jmp x01_0_xtn_next
label x01_0_xtn_append
cmp r2 0
je x01_0_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_0_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_0_xtn_next
add r0 1
jmp x01_0_xtn_each
label x01_0_xtn_valid
cmp r1 0
je x01_0_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_0_xtn_done
jmp x01_0_xt_normalized

label x01_lesson_1
store8 9050000000000000016 1
store8 9050000000000000017 1
store8 9050000000000000018 0
store8 9050000000000000019 3
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 111
store8 9050000000000000273 121
store8 9050000000000000274 101
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_1_xt_blank
cmp r0 88
jne x01_1_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_1_xt_invalid
jmp x01_1_xt_validate
label x01_1_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_1_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_1_xt_invalid
add r0 1
cmp r0 16
jlt x01_1_xt_blank_header
set r0 32
label x01_1_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_1_xt_invalid
add r0 1
cmp r0 144
jlt x01_1_xt_blank_context
set r0 4096
label x01_1_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_1_xt_invalid
add r0 1
cmp r0 16384
jlt x01_1_xt_blank_bank
label x01_1_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_1_xt_invalid
cmp r0 0
je x01_1_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_1_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_1_xt_invalid
cmp r0 17
jgt x01_1_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_1_xt_invalid
label x01_1_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_1_xt_invalid
cmp r0 4
jgt x01_1_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_1_xt_invalid
cmp r0 1
jne x01_1_xt_modifier
cmp r1 1
jlt x01_1_xt_invalid
cmp r1 17
jgt x01_1_xt_invalid
jmp x01_1_xt_prepare
label x01_1_xt_modifier
cmp r1 0
jne x01_1_xt_invalid
cmp r2 0
jne x01_1_xt_invalid
label x01_1_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_1_xtn_begin
label x01_1_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_1_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_1_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_1_xt_invalid
set r10 0
label x01_1_xt_lookup
cmp r10 r6
jge x01_1_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_1_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_1_xt_next
set r0 0
label x01_1_xt_compare
cmp r0 r12
jge x01_1_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_1_xt_next
add r0 1
jmp x01_1_xt_compare
label x01_1_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_1_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_1_xt_correct
jmp x01_1_xt_clean
label x01_1_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_1_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_1_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_1_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_1_xt_clean
label x01_1_xt_next
add r10 1
jmp x01_1_xt_lookup
label x01_1_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_1_xt_invalid
cmp r6 128
jge x01_1_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_1_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_1_xt_invalid
add r0 1
cmp r0 96
jlt x01_1_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_1_xt_copy
cmp r0 r12
jge x01_1_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_1_xt_copy
label x01_1_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_1_xt_clean
set r0 16
label x01_1_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_1_xt_clean_mailbox
set r0 256
label x01_1_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_1_xt_clean_scratch
jmp x01_lesson_2
label x01_1_xt_invalid
div r0 0

label x01_1_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_1_xtn_done
cmp r9 255
jgt x01_1_xtn_done
label x01_1_xtn_each
cmp r0 r9
jge x01_1_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_1_xtn_inverted
cmp r3 195
je x01_1_xtn_accent
cmp r3 226
je x01_1_xtn_unicode_space
cmp r3 32
je x01_1_xtn_space
cmp r3 44
je x01_1_xtn_space
cmp r3 46
je x01_1_xtn_space
cmp r3 33
je x01_1_xtn_space
cmp r3 63
je x01_1_xtn_space
cmp r3 65
jlt x01_1_xtn_ascii
cmp r3 90
jgt x01_1_xtn_ascii
add r3 32
label x01_1_xtn_ascii
cmp r3 97
jlt x01_1_xtn_digit
cmp r3 122
jle x01_1_xtn_append
label x01_1_xtn_digit
cmp r3 48
jlt x01_1_xtn_done
cmp r3 57
jgt x01_1_xtn_done
jmp x01_1_xtn_append
label x01_1_xtn_inverted
add r0 1
cmp r0 r9
jge x01_1_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_1_xtn_space
cmp r3 191
je x01_1_xtn_space
cmp r3 161
je x01_1_xtn_space
jmp x01_1_xtn_done
label x01_1_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_1_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_1_xtn_done
add r0 1
cmp r0 r9
jge x01_1_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_1_xtn_space
cmp r3 175
je x01_1_xtn_space
jmp x01_1_xtn_done
label x01_1_xtn_accent
add r0 1
cmp r0 r9
jge x01_1_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_1_xtn_a
cmp r3 161
je x01_1_xtn_a
cmp r3 137
je x01_1_xtn_e
cmp r3 169
je x01_1_xtn_e
cmp r3 141
je x01_1_xtn_i
cmp r3 173
je x01_1_xtn_i
cmp r3 147
je x01_1_xtn_o
cmp r3 179
je x01_1_xtn_o
cmp r3 154
je x01_1_xtn_u
cmp r3 186
je x01_1_xtn_u
cmp r3 145
je x01_1_xtn_n
cmp r3 177
je x01_1_xtn_n
jmp x01_1_xtn_done
label x01_1_xtn_a
set r3 97
jmp x01_1_xtn_append
label x01_1_xtn_e
set r3 101
jmp x01_1_xtn_append
label x01_1_xtn_i
set r3 105
jmp x01_1_xtn_append
label x01_1_xtn_o
set r3 111
jmp x01_1_xtn_append
label x01_1_xtn_u
set r3 117
jmp x01_1_xtn_append
label x01_1_xtn_n
set r3 110
jmp x01_1_xtn_append
label x01_1_xtn_space
cmp r1 0
je x01_1_xtn_next
set r2 1
jmp x01_1_xtn_next
label x01_1_xtn_append
cmp r2 0
je x01_1_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_1_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_1_xtn_next
add r0 1
jmp x01_1_xtn_each
label x01_1_xtn_valid
cmp r1 0
je x01_1_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_1_xtn_done
jmp x01_1_xt_normalized

label x01_lesson_2
store8 9050000000000000016 1
store8 9050000000000000017 2
store8 9050000000000000018 1
store8 9050000000000000019 9
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 115
store8 9050000000000000273 105
store8 9050000000000000274 103
store8 9050000000000000275 117
store8 9050000000000000276 105
store8 9050000000000000277 101
store8 9050000000000000278 110
store8 9050000000000000279 116
store8 9050000000000000280 101
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_2_xt_blank
cmp r0 88
jne x01_2_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_2_xt_invalid
jmp x01_2_xt_validate
label x01_2_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_2_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_2_xt_invalid
add r0 1
cmp r0 16
jlt x01_2_xt_blank_header
set r0 32
label x01_2_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_2_xt_invalid
add r0 1
cmp r0 144
jlt x01_2_xt_blank_context
set r0 4096
label x01_2_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_2_xt_invalid
add r0 1
cmp r0 16384
jlt x01_2_xt_blank_bank
label x01_2_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_2_xt_invalid
cmp r0 0
je x01_2_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_2_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_2_xt_invalid
cmp r0 17
jgt x01_2_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_2_xt_invalid
label x01_2_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_2_xt_invalid
cmp r0 4
jgt x01_2_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_2_xt_invalid
cmp r0 1
jne x01_2_xt_modifier
cmp r1 1
jlt x01_2_xt_invalid
cmp r1 17
jgt x01_2_xt_invalid
jmp x01_2_xt_prepare
label x01_2_xt_modifier
cmp r1 0
jne x01_2_xt_invalid
cmp r2 0
jne x01_2_xt_invalid
label x01_2_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_2_xtn_begin
label x01_2_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_2_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_2_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_2_xt_invalid
set r10 0
label x01_2_xt_lookup
cmp r10 r6
jge x01_2_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_2_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_2_xt_next
set r0 0
label x01_2_xt_compare
cmp r0 r12
jge x01_2_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_2_xt_next
add r0 1
jmp x01_2_xt_compare
label x01_2_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_2_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_2_xt_correct
jmp x01_2_xt_clean
label x01_2_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_2_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_2_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_2_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_2_xt_clean
label x01_2_xt_next
add r10 1
jmp x01_2_xt_lookup
label x01_2_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_2_xt_invalid
cmp r6 128
jge x01_2_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_2_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_2_xt_invalid
add r0 1
cmp r0 96
jlt x01_2_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_2_xt_copy
cmp r0 r12
jge x01_2_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_2_xt_copy
label x01_2_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_2_xt_clean
set r0 16
label x01_2_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_2_xt_clean_mailbox
set r0 256
label x01_2_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_2_xt_clean_scratch
jmp x01_lesson_3
label x01_2_xt_invalid
div r0 0

label x01_2_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_2_xtn_done
cmp r9 255
jgt x01_2_xtn_done
label x01_2_xtn_each
cmp r0 r9
jge x01_2_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_2_xtn_inverted
cmp r3 195
je x01_2_xtn_accent
cmp r3 226
je x01_2_xtn_unicode_space
cmp r3 32
je x01_2_xtn_space
cmp r3 44
je x01_2_xtn_space
cmp r3 46
je x01_2_xtn_space
cmp r3 33
je x01_2_xtn_space
cmp r3 63
je x01_2_xtn_space
cmp r3 65
jlt x01_2_xtn_ascii
cmp r3 90
jgt x01_2_xtn_ascii
add r3 32
label x01_2_xtn_ascii
cmp r3 97
jlt x01_2_xtn_digit
cmp r3 122
jle x01_2_xtn_append
label x01_2_xtn_digit
cmp r3 48
jlt x01_2_xtn_done
cmp r3 57
jgt x01_2_xtn_done
jmp x01_2_xtn_append
label x01_2_xtn_inverted
add r0 1
cmp r0 r9
jge x01_2_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_2_xtn_space
cmp r3 191
je x01_2_xtn_space
cmp r3 161
je x01_2_xtn_space
jmp x01_2_xtn_done
label x01_2_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_2_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_2_xtn_done
add r0 1
cmp r0 r9
jge x01_2_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_2_xtn_space
cmp r3 175
je x01_2_xtn_space
jmp x01_2_xtn_done
label x01_2_xtn_accent
add r0 1
cmp r0 r9
jge x01_2_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_2_xtn_a
cmp r3 161
je x01_2_xtn_a
cmp r3 137
je x01_2_xtn_e
cmp r3 169
je x01_2_xtn_e
cmp r3 141
je x01_2_xtn_i
cmp r3 173
je x01_2_xtn_i
cmp r3 147
je x01_2_xtn_o
cmp r3 179
je x01_2_xtn_o
cmp r3 154
je x01_2_xtn_u
cmp r3 186
je x01_2_xtn_u
cmp r3 145
je x01_2_xtn_n
cmp r3 177
je x01_2_xtn_n
jmp x01_2_xtn_done
label x01_2_xtn_a
set r3 97
jmp x01_2_xtn_append
label x01_2_xtn_e
set r3 101
jmp x01_2_xtn_append
label x01_2_xtn_i
set r3 105
jmp x01_2_xtn_append
label x01_2_xtn_o
set r3 111
jmp x01_2_xtn_append
label x01_2_xtn_u
set r3 117
jmp x01_2_xtn_append
label x01_2_xtn_n
set r3 110
jmp x01_2_xtn_append
label x01_2_xtn_space
cmp r1 0
je x01_2_xtn_next
set r2 1
jmp x01_2_xtn_next
label x01_2_xtn_append
cmp r2 0
je x01_2_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_2_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_2_xtn_next
add r0 1
jmp x01_2_xtn_each
label x01_2_xtn_valid
cmp r1 0
je x01_2_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_2_xtn_done
jmp x01_2_xt_normalized

label x01_lesson_3
store8 9050000000000000016 1
store8 9050000000000000017 2
store8 9050000000000000018 1
store8 9050000000000000019 9
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 99
store8 9050000000000000273 111
store8 9050000000000000274 110
store8 9050000000000000275 116
store8 9050000000000000276 105
store8 9050000000000000277 110
store8 9050000000000000278 195
store8 9050000000000000279 186
store8 9050000000000000280 97
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_3_xt_blank
cmp r0 88
jne x01_3_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_3_xt_invalid
jmp x01_3_xt_validate
label x01_3_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_3_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_3_xt_invalid
add r0 1
cmp r0 16
jlt x01_3_xt_blank_header
set r0 32
label x01_3_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_3_xt_invalid
add r0 1
cmp r0 144
jlt x01_3_xt_blank_context
set r0 4096
label x01_3_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_3_xt_invalid
add r0 1
cmp r0 16384
jlt x01_3_xt_blank_bank
label x01_3_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_3_xt_invalid
cmp r0 0
je x01_3_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_3_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_3_xt_invalid
cmp r0 17
jgt x01_3_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_3_xt_invalid
label x01_3_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_3_xt_invalid
cmp r0 4
jgt x01_3_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_3_xt_invalid
cmp r0 1
jne x01_3_xt_modifier
cmp r1 1
jlt x01_3_xt_invalid
cmp r1 17
jgt x01_3_xt_invalid
jmp x01_3_xt_prepare
label x01_3_xt_modifier
cmp r1 0
jne x01_3_xt_invalid
cmp r2 0
jne x01_3_xt_invalid
label x01_3_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_3_xtn_begin
label x01_3_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_3_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_3_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_3_xt_invalid
set r10 0
label x01_3_xt_lookup
cmp r10 r6
jge x01_3_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_3_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_3_xt_next
set r0 0
label x01_3_xt_compare
cmp r0 r12
jge x01_3_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_3_xt_next
add r0 1
jmp x01_3_xt_compare
label x01_3_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_3_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_3_xt_correct
jmp x01_3_xt_clean
label x01_3_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_3_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_3_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_3_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_3_xt_clean
label x01_3_xt_next
add r10 1
jmp x01_3_xt_lookup
label x01_3_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_3_xt_invalid
cmp r6 128
jge x01_3_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_3_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_3_xt_invalid
add r0 1
cmp r0 96
jlt x01_3_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_3_xt_copy
cmp r0 r12
jge x01_3_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_3_xt_copy
label x01_3_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_3_xt_clean
set r0 16
label x01_3_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_3_xt_clean_mailbox
set r0 256
label x01_3_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_3_xt_clean_scratch
jmp x01_lesson_4
label x01_3_xt_invalid
div r0 0

label x01_3_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_3_xtn_done
cmp r9 255
jgt x01_3_xtn_done
label x01_3_xtn_each
cmp r0 r9
jge x01_3_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_3_xtn_inverted
cmp r3 195
je x01_3_xtn_accent
cmp r3 226
je x01_3_xtn_unicode_space
cmp r3 32
je x01_3_xtn_space
cmp r3 44
je x01_3_xtn_space
cmp r3 46
je x01_3_xtn_space
cmp r3 33
je x01_3_xtn_space
cmp r3 63
je x01_3_xtn_space
cmp r3 65
jlt x01_3_xtn_ascii
cmp r3 90
jgt x01_3_xtn_ascii
add r3 32
label x01_3_xtn_ascii
cmp r3 97
jlt x01_3_xtn_digit
cmp r3 122
jle x01_3_xtn_append
label x01_3_xtn_digit
cmp r3 48
jlt x01_3_xtn_done
cmp r3 57
jgt x01_3_xtn_done
jmp x01_3_xtn_append
label x01_3_xtn_inverted
add r0 1
cmp r0 r9
jge x01_3_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_3_xtn_space
cmp r3 191
je x01_3_xtn_space
cmp r3 161
je x01_3_xtn_space
jmp x01_3_xtn_done
label x01_3_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_3_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_3_xtn_done
add r0 1
cmp r0 r9
jge x01_3_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_3_xtn_space
cmp r3 175
je x01_3_xtn_space
jmp x01_3_xtn_done
label x01_3_xtn_accent
add r0 1
cmp r0 r9
jge x01_3_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_3_xtn_a
cmp r3 161
je x01_3_xtn_a
cmp r3 137
je x01_3_xtn_e
cmp r3 169
je x01_3_xtn_e
cmp r3 141
je x01_3_xtn_i
cmp r3 173
je x01_3_xtn_i
cmp r3 147
je x01_3_xtn_o
cmp r3 179
je x01_3_xtn_o
cmp r3 154
je x01_3_xtn_u
cmp r3 186
je x01_3_xtn_u
cmp r3 145
je x01_3_xtn_n
cmp r3 177
je x01_3_xtn_n
jmp x01_3_xtn_done
label x01_3_xtn_a
set r3 97
jmp x01_3_xtn_append
label x01_3_xtn_e
set r3 101
jmp x01_3_xtn_append
label x01_3_xtn_i
set r3 105
jmp x01_3_xtn_append
label x01_3_xtn_o
set r3 111
jmp x01_3_xtn_append
label x01_3_xtn_u
set r3 117
jmp x01_3_xtn_append
label x01_3_xtn_n
set r3 110
jmp x01_3_xtn_append
label x01_3_xtn_space
cmp r1 0
je x01_3_xtn_next
set r2 1
jmp x01_3_xtn_next
label x01_3_xtn_append
cmp r2 0
je x01_3_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_3_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_3_xtn_next
add r0 1
jmp x01_3_xtn_each
label x01_3_xtn_valid
cmp r1 0
je x01_3_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_3_xtn_done
jmp x01_3_xt_normalized

label x01_lesson_4
store8 9050000000000000016 1
store8 9050000000000000017 2
store8 9050000000000000018 1
store8 9050000000000000019 20
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 99
store8 9050000000000000273 111
store8 9050000000000000274 110
store8 9050000000000000275 116
store8 9050000000000000276 105
store8 9050000000000000277 110
store8 9050000000000000278 195
store8 9050000000000000279 186
store8 9050000000000000280 97
store8 9050000000000000281 32
store8 9050000000000000282 101
store8 9050000000000000283 108
store8 9050000000000000284 32
store8 9050000000000000285 116
store8 9050000000000000286 114
store8 9050000000000000287 97
store8 9050000000000000288 98
store8 9050000000000000289 97
store8 9050000000000000290 106
store8 9050000000000000291 111
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_4_xt_blank
cmp r0 88
jne x01_4_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_4_xt_invalid
jmp x01_4_xt_validate
label x01_4_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_4_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_4_xt_invalid
add r0 1
cmp r0 16
jlt x01_4_xt_blank_header
set r0 32
label x01_4_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_4_xt_invalid
add r0 1
cmp r0 144
jlt x01_4_xt_blank_context
set r0 4096
label x01_4_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_4_xt_invalid
add r0 1
cmp r0 16384
jlt x01_4_xt_blank_bank
label x01_4_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_4_xt_invalid
cmp r0 0
je x01_4_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_4_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_4_xt_invalid
cmp r0 17
jgt x01_4_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_4_xt_invalid
label x01_4_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_4_xt_invalid
cmp r0 4
jgt x01_4_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_4_xt_invalid
cmp r0 1
jne x01_4_xt_modifier
cmp r1 1
jlt x01_4_xt_invalid
cmp r1 17
jgt x01_4_xt_invalid
jmp x01_4_xt_prepare
label x01_4_xt_modifier
cmp r1 0
jne x01_4_xt_invalid
cmp r2 0
jne x01_4_xt_invalid
label x01_4_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_4_xtn_begin
label x01_4_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_4_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_4_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_4_xt_invalid
set r10 0
label x01_4_xt_lookup
cmp r10 r6
jge x01_4_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_4_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_4_xt_next
set r0 0
label x01_4_xt_compare
cmp r0 r12
jge x01_4_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_4_xt_next
add r0 1
jmp x01_4_xt_compare
label x01_4_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_4_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_4_xt_correct
jmp x01_4_xt_clean
label x01_4_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_4_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_4_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_4_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_4_xt_clean
label x01_4_xt_next
add r10 1
jmp x01_4_xt_lookup
label x01_4_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_4_xt_invalid
cmp r6 128
jge x01_4_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_4_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_4_xt_invalid
add r0 1
cmp r0 96
jlt x01_4_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_4_xt_copy
cmp r0 r12
jge x01_4_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_4_xt_copy
label x01_4_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_4_xt_clean
set r0 16
label x01_4_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_4_xt_clean_mailbox
set r0 256
label x01_4_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_4_xt_clean_scratch
jmp x01_lesson_5
label x01_4_xt_invalid
div r0 0

label x01_4_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_4_xtn_done
cmp r9 255
jgt x01_4_xtn_done
label x01_4_xtn_each
cmp r0 r9
jge x01_4_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_4_xtn_inverted
cmp r3 195
je x01_4_xtn_accent
cmp r3 226
je x01_4_xtn_unicode_space
cmp r3 32
je x01_4_xtn_space
cmp r3 44
je x01_4_xtn_space
cmp r3 46
je x01_4_xtn_space
cmp r3 33
je x01_4_xtn_space
cmp r3 63
je x01_4_xtn_space
cmp r3 65
jlt x01_4_xtn_ascii
cmp r3 90
jgt x01_4_xtn_ascii
add r3 32
label x01_4_xtn_ascii
cmp r3 97
jlt x01_4_xtn_digit
cmp r3 122
jle x01_4_xtn_append
label x01_4_xtn_digit
cmp r3 48
jlt x01_4_xtn_done
cmp r3 57
jgt x01_4_xtn_done
jmp x01_4_xtn_append
label x01_4_xtn_inverted
add r0 1
cmp r0 r9
jge x01_4_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_4_xtn_space
cmp r3 191
je x01_4_xtn_space
cmp r3 161
je x01_4_xtn_space
jmp x01_4_xtn_done
label x01_4_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_4_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_4_xtn_done
add r0 1
cmp r0 r9
jge x01_4_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_4_xtn_space
cmp r3 175
je x01_4_xtn_space
jmp x01_4_xtn_done
label x01_4_xtn_accent
add r0 1
cmp r0 r9
jge x01_4_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_4_xtn_a
cmp r3 161
je x01_4_xtn_a
cmp r3 137
je x01_4_xtn_e
cmp r3 169
je x01_4_xtn_e
cmp r3 141
je x01_4_xtn_i
cmp r3 173
je x01_4_xtn_i
cmp r3 147
je x01_4_xtn_o
cmp r3 179
je x01_4_xtn_o
cmp r3 154
je x01_4_xtn_u
cmp r3 186
je x01_4_xtn_u
cmp r3 145
je x01_4_xtn_n
cmp r3 177
je x01_4_xtn_n
jmp x01_4_xtn_done
label x01_4_xtn_a
set r3 97
jmp x01_4_xtn_append
label x01_4_xtn_e
set r3 101
jmp x01_4_xtn_append
label x01_4_xtn_i
set r3 105
jmp x01_4_xtn_append
label x01_4_xtn_o
set r3 111
jmp x01_4_xtn_append
label x01_4_xtn_u
set r3 117
jmp x01_4_xtn_append
label x01_4_xtn_n
set r3 110
jmp x01_4_xtn_append
label x01_4_xtn_space
cmp r1 0
je x01_4_xtn_next
set r2 1
jmp x01_4_xtn_next
label x01_4_xtn_append
cmp r2 0
je x01_4_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_4_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_4_xtn_next
add r0 1
jmp x01_4_xtn_each
label x01_4_xtn_valid
cmp r1 0
je x01_4_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_4_xtn_done
jmp x01_4_xt_normalized

label x01_lesson_5
store8 9050000000000000016 1
store8 9050000000000000017 2
store8 9050000000000000018 1
store8 9050000000000000019 21
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 99
store8 9050000000000000273 111
store8 9050000000000000274 110
store8 9050000000000000275 116
store8 9050000000000000276 105
store8 9050000000000000277 110
store8 9050000000000000278 195
store8 9050000000000000279 186
store8 9050000000000000280 97
store8 9050000000000000281 32
store8 9050000000000000282 101
store8 9050000000000000283 108
store8 9050000000000000284 32
store8 9050000000000000285 99
store8 9050000000000000286 105
store8 9050000000000000287 99
store8 9050000000000000288 108
store8 9050000000000000289 111
store8 9050000000000000290 32
store8 9050000000000000291 116
store8 9050000000000000292 117
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_5_xt_blank
cmp r0 88
jne x01_5_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_5_xt_invalid
jmp x01_5_xt_validate
label x01_5_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_5_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_5_xt_invalid
add r0 1
cmp r0 16
jlt x01_5_xt_blank_header
set r0 32
label x01_5_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_5_xt_invalid
add r0 1
cmp r0 144
jlt x01_5_xt_blank_context
set r0 4096
label x01_5_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_5_xt_invalid
add r0 1
cmp r0 16384
jlt x01_5_xt_blank_bank
label x01_5_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_5_xt_invalid
cmp r0 0
je x01_5_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_5_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_5_xt_invalid
cmp r0 17
jgt x01_5_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_5_xt_invalid
label x01_5_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_5_xt_invalid
cmp r0 4
jgt x01_5_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_5_xt_invalid
cmp r0 1
jne x01_5_xt_modifier
cmp r1 1
jlt x01_5_xt_invalid
cmp r1 17
jgt x01_5_xt_invalid
jmp x01_5_xt_prepare
label x01_5_xt_modifier
cmp r1 0
jne x01_5_xt_invalid
cmp r2 0
jne x01_5_xt_invalid
label x01_5_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_5_xtn_begin
label x01_5_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_5_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_5_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_5_xt_invalid
set r10 0
label x01_5_xt_lookup
cmp r10 r6
jge x01_5_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_5_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_5_xt_next
set r0 0
label x01_5_xt_compare
cmp r0 r12
jge x01_5_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_5_xt_next
add r0 1
jmp x01_5_xt_compare
label x01_5_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_5_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_5_xt_correct
jmp x01_5_xt_clean
label x01_5_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_5_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_5_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_5_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_5_xt_clean
label x01_5_xt_next
add r10 1
jmp x01_5_xt_lookup
label x01_5_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_5_xt_invalid
cmp r6 128
jge x01_5_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_5_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_5_xt_invalid
add r0 1
cmp r0 96
jlt x01_5_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_5_xt_copy
cmp r0 r12
jge x01_5_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_5_xt_copy
label x01_5_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_5_xt_clean
set r0 16
label x01_5_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_5_xt_clean_mailbox
set r0 256
label x01_5_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_5_xt_clean_scratch
jmp x01_lesson_6
label x01_5_xt_invalid
div r0 0

label x01_5_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_5_xtn_done
cmp r9 255
jgt x01_5_xtn_done
label x01_5_xtn_each
cmp r0 r9
jge x01_5_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_5_xtn_inverted
cmp r3 195
je x01_5_xtn_accent
cmp r3 226
je x01_5_xtn_unicode_space
cmp r3 32
je x01_5_xtn_space
cmp r3 44
je x01_5_xtn_space
cmp r3 46
je x01_5_xtn_space
cmp r3 33
je x01_5_xtn_space
cmp r3 63
je x01_5_xtn_space
cmp r3 65
jlt x01_5_xtn_ascii
cmp r3 90
jgt x01_5_xtn_ascii
add r3 32
label x01_5_xtn_ascii
cmp r3 97
jlt x01_5_xtn_digit
cmp r3 122
jle x01_5_xtn_append
label x01_5_xtn_digit
cmp r3 48
jlt x01_5_xtn_done
cmp r3 57
jgt x01_5_xtn_done
jmp x01_5_xtn_append
label x01_5_xtn_inverted
add r0 1
cmp r0 r9
jge x01_5_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_5_xtn_space
cmp r3 191
je x01_5_xtn_space
cmp r3 161
je x01_5_xtn_space
jmp x01_5_xtn_done
label x01_5_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_5_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_5_xtn_done
add r0 1
cmp r0 r9
jge x01_5_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_5_xtn_space
cmp r3 175
je x01_5_xtn_space
jmp x01_5_xtn_done
label x01_5_xtn_accent
add r0 1
cmp r0 r9
jge x01_5_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_5_xtn_a
cmp r3 161
je x01_5_xtn_a
cmp r3 137
je x01_5_xtn_e
cmp r3 169
je x01_5_xtn_e
cmp r3 141
je x01_5_xtn_i
cmp r3 173
je x01_5_xtn_i
cmp r3 147
je x01_5_xtn_o
cmp r3 179
je x01_5_xtn_o
cmp r3 154
je x01_5_xtn_u
cmp r3 186
je x01_5_xtn_u
cmp r3 145
je x01_5_xtn_n
cmp r3 177
je x01_5_xtn_n
jmp x01_5_xtn_done
label x01_5_xtn_a
set r3 97
jmp x01_5_xtn_append
label x01_5_xtn_e
set r3 101
jmp x01_5_xtn_append
label x01_5_xtn_i
set r3 105
jmp x01_5_xtn_append
label x01_5_xtn_o
set r3 111
jmp x01_5_xtn_append
label x01_5_xtn_u
set r3 117
jmp x01_5_xtn_append
label x01_5_xtn_n
set r3 110
jmp x01_5_xtn_append
label x01_5_xtn_space
cmp r1 0
je x01_5_xtn_next
set r2 1
jmp x01_5_xtn_next
label x01_5_xtn_append
cmp r2 0
je x01_5_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_5_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_5_xtn_next
add r0 1
jmp x01_5_xtn_each
label x01_5_xtn_valid
cmp r1 0
je x01_5_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_5_xtn_done
jmp x01_5_xt_normalized

label x01_lesson_6
store8 9050000000000000016 1
store8 9050000000000000017 2
store8 9050000000000000018 1
store8 9050000000000000019 15
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 105
store8 9050000000000000273 110
store8 9050000000000000274 105
store8 9050000000000000275 99
store8 9050000000000000276 105
store8 9050000000000000277 97
store8 9050000000000000278 32
store8 9050000000000000279 101
store8 9050000000000000280 108
store8 9050000000000000281 32
store8 9050000000000000282 99
store8 9050000000000000283 105
store8 9050000000000000284 99
store8 9050000000000000285 108
store8 9050000000000000286 111
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_6_xt_blank
cmp r0 88
jne x01_6_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_6_xt_invalid
jmp x01_6_xt_validate
label x01_6_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_6_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_6_xt_invalid
add r0 1
cmp r0 16
jlt x01_6_xt_blank_header
set r0 32
label x01_6_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_6_xt_invalid
add r0 1
cmp r0 144
jlt x01_6_xt_blank_context
set r0 4096
label x01_6_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_6_xt_invalid
add r0 1
cmp r0 16384
jlt x01_6_xt_blank_bank
label x01_6_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_6_xt_invalid
cmp r0 0
je x01_6_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_6_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_6_xt_invalid
cmp r0 17
jgt x01_6_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_6_xt_invalid
label x01_6_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_6_xt_invalid
cmp r0 4
jgt x01_6_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_6_xt_invalid
cmp r0 1
jne x01_6_xt_modifier
cmp r1 1
jlt x01_6_xt_invalid
cmp r1 17
jgt x01_6_xt_invalid
jmp x01_6_xt_prepare
label x01_6_xt_modifier
cmp r1 0
jne x01_6_xt_invalid
cmp r2 0
jne x01_6_xt_invalid
label x01_6_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_6_xtn_begin
label x01_6_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_6_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_6_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_6_xt_invalid
set r10 0
label x01_6_xt_lookup
cmp r10 r6
jge x01_6_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_6_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_6_xt_next
set r0 0
label x01_6_xt_compare
cmp r0 r12
jge x01_6_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_6_xt_next
add r0 1
jmp x01_6_xt_compare
label x01_6_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_6_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_6_xt_correct
jmp x01_6_xt_clean
label x01_6_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_6_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_6_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_6_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_6_xt_clean
label x01_6_xt_next
add r10 1
jmp x01_6_xt_lookup
label x01_6_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_6_xt_invalid
cmp r6 128
jge x01_6_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_6_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_6_xt_invalid
add r0 1
cmp r0 96
jlt x01_6_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_6_xt_copy
cmp r0 r12
jge x01_6_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_6_xt_copy
label x01_6_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_6_xt_clean
set r0 16
label x01_6_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_6_xt_clean_mailbox
set r0 256
label x01_6_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_6_xt_clean_scratch
jmp x01_lesson_7
label x01_6_xt_invalid
div r0 0

label x01_6_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_6_xtn_done
cmp r9 255
jgt x01_6_xtn_done
label x01_6_xtn_each
cmp r0 r9
jge x01_6_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_6_xtn_inverted
cmp r3 195
je x01_6_xtn_accent
cmp r3 226
je x01_6_xtn_unicode_space
cmp r3 32
je x01_6_xtn_space
cmp r3 44
je x01_6_xtn_space
cmp r3 46
je x01_6_xtn_space
cmp r3 33
je x01_6_xtn_space
cmp r3 63
je x01_6_xtn_space
cmp r3 65
jlt x01_6_xtn_ascii
cmp r3 90
jgt x01_6_xtn_ascii
add r3 32
label x01_6_xtn_ascii
cmp r3 97
jlt x01_6_xtn_digit
cmp r3 122
jle x01_6_xtn_append
label x01_6_xtn_digit
cmp r3 48
jlt x01_6_xtn_done
cmp r3 57
jgt x01_6_xtn_done
jmp x01_6_xtn_append
label x01_6_xtn_inverted
add r0 1
cmp r0 r9
jge x01_6_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_6_xtn_space
cmp r3 191
je x01_6_xtn_space
cmp r3 161
je x01_6_xtn_space
jmp x01_6_xtn_done
label x01_6_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_6_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_6_xtn_done
add r0 1
cmp r0 r9
jge x01_6_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_6_xtn_space
cmp r3 175
je x01_6_xtn_space
jmp x01_6_xtn_done
label x01_6_xtn_accent
add r0 1
cmp r0 r9
jge x01_6_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_6_xtn_a
cmp r3 161
je x01_6_xtn_a
cmp r3 137
je x01_6_xtn_e
cmp r3 169
je x01_6_xtn_e
cmp r3 141
je x01_6_xtn_i
cmp r3 173
je x01_6_xtn_i
cmp r3 147
je x01_6_xtn_o
cmp r3 179
je x01_6_xtn_o
cmp r3 154
je x01_6_xtn_u
cmp r3 186
je x01_6_xtn_u
cmp r3 145
je x01_6_xtn_n
cmp r3 177
je x01_6_xtn_n
jmp x01_6_xtn_done
label x01_6_xtn_a
set r3 97
jmp x01_6_xtn_append
label x01_6_xtn_e
set r3 101
jmp x01_6_xtn_append
label x01_6_xtn_i
set r3 105
jmp x01_6_xtn_append
label x01_6_xtn_o
set r3 111
jmp x01_6_xtn_append
label x01_6_xtn_u
set r3 117
jmp x01_6_xtn_append
label x01_6_xtn_n
set r3 110
jmp x01_6_xtn_append
label x01_6_xtn_space
cmp r1 0
je x01_6_xtn_next
set r2 1
jmp x01_6_xtn_next
label x01_6_xtn_append
cmp r2 0
je x01_6_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_6_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_6_xtn_next
add r0 1
jmp x01_6_xtn_each
label x01_6_xtn_valid
cmp r1 0
je x01_6_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_6_xtn_done
jmp x01_6_xt_normalized

label x01_lesson_7
store8 9050000000000000016 1
store8 9050000000000000017 2
store8 9050000000000000018 1
store8 9050000000000000019 20
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 105
store8 9050000000000000273 110
store8 9050000000000000274 105
store8 9050000000000000275 99
store8 9050000000000000276 105
store8 9050000000000000277 97
store8 9050000000000000278 108
store8 9050000000000000279 111
store8 9050000000000000280 32
store8 9050000000000000281 97
store8 9050000000000000282 104
store8 9050000000000000283 111
store8 9050000000000000284 114
store8 9050000000000000285 97
store8 9050000000000000286 32
store8 9050000000000000287 109
store8 9050000000000000288 105
store8 9050000000000000289 115
store8 9050000000000000290 109
store8 9050000000000000291 111
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_7_xt_blank
cmp r0 88
jne x01_7_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_7_xt_invalid
jmp x01_7_xt_validate
label x01_7_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_7_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_7_xt_invalid
add r0 1
cmp r0 16
jlt x01_7_xt_blank_header
set r0 32
label x01_7_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_7_xt_invalid
add r0 1
cmp r0 144
jlt x01_7_xt_blank_context
set r0 4096
label x01_7_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_7_xt_invalid
add r0 1
cmp r0 16384
jlt x01_7_xt_blank_bank
label x01_7_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_7_xt_invalid
cmp r0 0
je x01_7_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_7_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_7_xt_invalid
cmp r0 17
jgt x01_7_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_7_xt_invalid
label x01_7_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_7_xt_invalid
cmp r0 4
jgt x01_7_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_7_xt_invalid
cmp r0 1
jne x01_7_xt_modifier
cmp r1 1
jlt x01_7_xt_invalid
cmp r1 17
jgt x01_7_xt_invalid
jmp x01_7_xt_prepare
label x01_7_xt_modifier
cmp r1 0
jne x01_7_xt_invalid
cmp r2 0
jne x01_7_xt_invalid
label x01_7_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_7_xtn_begin
label x01_7_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_7_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_7_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_7_xt_invalid
set r10 0
label x01_7_xt_lookup
cmp r10 r6
jge x01_7_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_7_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_7_xt_next
set r0 0
label x01_7_xt_compare
cmp r0 r12
jge x01_7_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_7_xt_next
add r0 1
jmp x01_7_xt_compare
label x01_7_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_7_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_7_xt_correct
jmp x01_7_xt_clean
label x01_7_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_7_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_7_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_7_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_7_xt_clean
label x01_7_xt_next
add r10 1
jmp x01_7_xt_lookup
label x01_7_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_7_xt_invalid
cmp r6 128
jge x01_7_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_7_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_7_xt_invalid
add r0 1
cmp r0 96
jlt x01_7_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_7_xt_copy
cmp r0 r12
jge x01_7_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_7_xt_copy
label x01_7_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_7_xt_clean
set r0 16
label x01_7_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_7_xt_clean_mailbox
set r0 256
label x01_7_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_7_xt_clean_scratch
jmp x01_lesson_8
label x01_7_xt_invalid
div r0 0

label x01_7_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_7_xtn_done
cmp r9 255
jgt x01_7_xtn_done
label x01_7_xtn_each
cmp r0 r9
jge x01_7_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_7_xtn_inverted
cmp r3 195
je x01_7_xtn_accent
cmp r3 226
je x01_7_xtn_unicode_space
cmp r3 32
je x01_7_xtn_space
cmp r3 44
je x01_7_xtn_space
cmp r3 46
je x01_7_xtn_space
cmp r3 33
je x01_7_xtn_space
cmp r3 63
je x01_7_xtn_space
cmp r3 65
jlt x01_7_xtn_ascii
cmp r3 90
jgt x01_7_xtn_ascii
add r3 32
label x01_7_xtn_ascii
cmp r3 97
jlt x01_7_xtn_digit
cmp r3 122
jle x01_7_xtn_append
label x01_7_xtn_digit
cmp r3 48
jlt x01_7_xtn_done
cmp r3 57
jgt x01_7_xtn_done
jmp x01_7_xtn_append
label x01_7_xtn_inverted
add r0 1
cmp r0 r9
jge x01_7_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_7_xtn_space
cmp r3 191
je x01_7_xtn_space
cmp r3 161
je x01_7_xtn_space
jmp x01_7_xtn_done
label x01_7_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_7_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_7_xtn_done
add r0 1
cmp r0 r9
jge x01_7_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_7_xtn_space
cmp r3 175
je x01_7_xtn_space
jmp x01_7_xtn_done
label x01_7_xtn_accent
add r0 1
cmp r0 r9
jge x01_7_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_7_xtn_a
cmp r3 161
je x01_7_xtn_a
cmp r3 137
je x01_7_xtn_e
cmp r3 169
je x01_7_xtn_e
cmp r3 141
je x01_7_xtn_i
cmp r3 173
je x01_7_xtn_i
cmp r3 147
je x01_7_xtn_o
cmp r3 179
je x01_7_xtn_o
cmp r3 154
je x01_7_xtn_u
cmp r3 186
je x01_7_xtn_u
cmp r3 145
je x01_7_xtn_n
cmp r3 177
je x01_7_xtn_n
jmp x01_7_xtn_done
label x01_7_xtn_a
set r3 97
jmp x01_7_xtn_append
label x01_7_xtn_e
set r3 101
jmp x01_7_xtn_append
label x01_7_xtn_i
set r3 105
jmp x01_7_xtn_append
label x01_7_xtn_o
set r3 111
jmp x01_7_xtn_append
label x01_7_xtn_u
set r3 117
jmp x01_7_xtn_append
label x01_7_xtn_n
set r3 110
jmp x01_7_xtn_append
label x01_7_xtn_space
cmp r1 0
je x01_7_xtn_next
set r2 1
jmp x01_7_xtn_next
label x01_7_xtn_append
cmp r2 0
je x01_7_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_7_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_7_xtn_next
add r0 1
jmp x01_7_xtn_each
label x01_7_xtn_valid
cmp r1 0
je x01_7_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_7_xtn_done
jmp x01_7_xt_normalized

label x01_lesson_8
store8 9050000000000000016 1
store8 9050000000000000017 2
store8 9050000000000000018 1
store8 9050000000000000019 5
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 104
store8 9050000000000000273 97
store8 9050000000000000274 122
store8 9050000000000000275 108
store8 9050000000000000276 111
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_8_xt_blank
cmp r0 88
jne x01_8_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_8_xt_invalid
jmp x01_8_xt_validate
label x01_8_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_8_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_8_xt_invalid
add r0 1
cmp r0 16
jlt x01_8_xt_blank_header
set r0 32
label x01_8_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_8_xt_invalid
add r0 1
cmp r0 144
jlt x01_8_xt_blank_context
set r0 4096
label x01_8_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_8_xt_invalid
add r0 1
cmp r0 16384
jlt x01_8_xt_blank_bank
label x01_8_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_8_xt_invalid
cmp r0 0
je x01_8_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_8_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_8_xt_invalid
cmp r0 17
jgt x01_8_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_8_xt_invalid
label x01_8_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_8_xt_invalid
cmp r0 4
jgt x01_8_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_8_xt_invalid
cmp r0 1
jne x01_8_xt_modifier
cmp r1 1
jlt x01_8_xt_invalid
cmp r1 17
jgt x01_8_xt_invalid
jmp x01_8_xt_prepare
label x01_8_xt_modifier
cmp r1 0
jne x01_8_xt_invalid
cmp r2 0
jne x01_8_xt_invalid
label x01_8_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_8_xtn_begin
label x01_8_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_8_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_8_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_8_xt_invalid
set r10 0
label x01_8_xt_lookup
cmp r10 r6
jge x01_8_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_8_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_8_xt_next
set r0 0
label x01_8_xt_compare
cmp r0 r12
jge x01_8_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_8_xt_next
add r0 1
jmp x01_8_xt_compare
label x01_8_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_8_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_8_xt_correct
jmp x01_8_xt_clean
label x01_8_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_8_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_8_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_8_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_8_xt_clean
label x01_8_xt_next
add r10 1
jmp x01_8_xt_lookup
label x01_8_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_8_xt_invalid
cmp r6 128
jge x01_8_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_8_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_8_xt_invalid
add r0 1
cmp r0 96
jlt x01_8_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_8_xt_copy
cmp r0 r12
jge x01_8_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_8_xt_copy
label x01_8_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_8_xt_clean
set r0 16
label x01_8_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_8_xt_clean_mailbox
set r0 256
label x01_8_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_8_xt_clean_scratch
jmp x01_lesson_9
label x01_8_xt_invalid
div r0 0

label x01_8_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_8_xtn_done
cmp r9 255
jgt x01_8_xtn_done
label x01_8_xtn_each
cmp r0 r9
jge x01_8_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_8_xtn_inverted
cmp r3 195
je x01_8_xtn_accent
cmp r3 226
je x01_8_xtn_unicode_space
cmp r3 32
je x01_8_xtn_space
cmp r3 44
je x01_8_xtn_space
cmp r3 46
je x01_8_xtn_space
cmp r3 33
je x01_8_xtn_space
cmp r3 63
je x01_8_xtn_space
cmp r3 65
jlt x01_8_xtn_ascii
cmp r3 90
jgt x01_8_xtn_ascii
add r3 32
label x01_8_xtn_ascii
cmp r3 97
jlt x01_8_xtn_digit
cmp r3 122
jle x01_8_xtn_append
label x01_8_xtn_digit
cmp r3 48
jlt x01_8_xtn_done
cmp r3 57
jgt x01_8_xtn_done
jmp x01_8_xtn_append
label x01_8_xtn_inverted
add r0 1
cmp r0 r9
jge x01_8_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_8_xtn_space
cmp r3 191
je x01_8_xtn_space
cmp r3 161
je x01_8_xtn_space
jmp x01_8_xtn_done
label x01_8_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_8_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_8_xtn_done
add r0 1
cmp r0 r9
jge x01_8_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_8_xtn_space
cmp r3 175
je x01_8_xtn_space
jmp x01_8_xtn_done
label x01_8_xtn_accent
add r0 1
cmp r0 r9
jge x01_8_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_8_xtn_a
cmp r3 161
je x01_8_xtn_a
cmp r3 137
je x01_8_xtn_e
cmp r3 169
je x01_8_xtn_e
cmp r3 141
je x01_8_xtn_i
cmp r3 173
je x01_8_xtn_i
cmp r3 147
je x01_8_xtn_o
cmp r3 179
je x01_8_xtn_o
cmp r3 154
je x01_8_xtn_u
cmp r3 186
je x01_8_xtn_u
cmp r3 145
je x01_8_xtn_n
cmp r3 177
je x01_8_xtn_n
jmp x01_8_xtn_done
label x01_8_xtn_a
set r3 97
jmp x01_8_xtn_append
label x01_8_xtn_e
set r3 101
jmp x01_8_xtn_append
label x01_8_xtn_i
set r3 105
jmp x01_8_xtn_append
label x01_8_xtn_o
set r3 111
jmp x01_8_xtn_append
label x01_8_xtn_u
set r3 117
jmp x01_8_xtn_append
label x01_8_xtn_n
set r3 110
jmp x01_8_xtn_append
label x01_8_xtn_space
cmp r1 0
je x01_8_xtn_next
set r2 1
jmp x01_8_xtn_next
label x01_8_xtn_append
cmp r2 0
je x01_8_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_8_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_8_xtn_next
add r0 1
jmp x01_8_xtn_each
label x01_8_xtn_valid
cmp r1 0
je x01_8_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_8_xtn_done
jmp x01_8_xt_normalized

label x01_lesson_9
store8 9050000000000000016 1
store8 9050000000000000017 2
store8 9050000000000000018 1
store8 9050000000000000019 12
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 104
store8 9050000000000000273 97
store8 9050000000000000274 103
store8 9050000000000000275 97
store8 9050000000000000276 109
store8 9050000000000000277 111
store8 9050000000000000278 115
store8 9050000000000000279 108
store8 9050000000000000280 111
store8 9050000000000000281 32
store8 9050000000000000282 121
store8 9050000000000000283 97
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_9_xt_blank
cmp r0 88
jne x01_9_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_9_xt_invalid
jmp x01_9_xt_validate
label x01_9_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_9_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_9_xt_invalid
add r0 1
cmp r0 16
jlt x01_9_xt_blank_header
set r0 32
label x01_9_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_9_xt_invalid
add r0 1
cmp r0 144
jlt x01_9_xt_blank_context
set r0 4096
label x01_9_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_9_xt_invalid
add r0 1
cmp r0 16384
jlt x01_9_xt_blank_bank
label x01_9_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_9_xt_invalid
cmp r0 0
je x01_9_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_9_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_9_xt_invalid
cmp r0 17
jgt x01_9_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_9_xt_invalid
label x01_9_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_9_xt_invalid
cmp r0 4
jgt x01_9_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_9_xt_invalid
cmp r0 1
jne x01_9_xt_modifier
cmp r1 1
jlt x01_9_xt_invalid
cmp r1 17
jgt x01_9_xt_invalid
jmp x01_9_xt_prepare
label x01_9_xt_modifier
cmp r1 0
jne x01_9_xt_invalid
cmp r2 0
jne x01_9_xt_invalid
label x01_9_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_9_xtn_begin
label x01_9_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_9_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_9_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_9_xt_invalid
set r10 0
label x01_9_xt_lookup
cmp r10 r6
jge x01_9_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_9_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_9_xt_next
set r0 0
label x01_9_xt_compare
cmp r0 r12
jge x01_9_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_9_xt_next
add r0 1
jmp x01_9_xt_compare
label x01_9_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_9_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_9_xt_correct
jmp x01_9_xt_clean
label x01_9_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_9_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_9_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_9_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_9_xt_clean
label x01_9_xt_next
add r10 1
jmp x01_9_xt_lookup
label x01_9_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_9_xt_invalid
cmp r6 128
jge x01_9_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_9_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_9_xt_invalid
add r0 1
cmp r0 96
jlt x01_9_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_9_xt_copy
cmp r0 r12
jge x01_9_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_9_xt_copy
label x01_9_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_9_xt_clean
set r0 16
label x01_9_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_9_xt_clean_mailbox
set r0 256
label x01_9_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_9_xt_clean_scratch
jmp x01_lesson_10
label x01_9_xt_invalid
div r0 0

label x01_9_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_9_xtn_done
cmp r9 255
jgt x01_9_xtn_done
label x01_9_xtn_each
cmp r0 r9
jge x01_9_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_9_xtn_inverted
cmp r3 195
je x01_9_xtn_accent
cmp r3 226
je x01_9_xtn_unicode_space
cmp r3 32
je x01_9_xtn_space
cmp r3 44
je x01_9_xtn_space
cmp r3 46
je x01_9_xtn_space
cmp r3 33
je x01_9_xtn_space
cmp r3 63
je x01_9_xtn_space
cmp r3 65
jlt x01_9_xtn_ascii
cmp r3 90
jgt x01_9_xtn_ascii
add r3 32
label x01_9_xtn_ascii
cmp r3 97
jlt x01_9_xtn_digit
cmp r3 122
jle x01_9_xtn_append
label x01_9_xtn_digit
cmp r3 48
jlt x01_9_xtn_done
cmp r3 57
jgt x01_9_xtn_done
jmp x01_9_xtn_append
label x01_9_xtn_inverted
add r0 1
cmp r0 r9
jge x01_9_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_9_xtn_space
cmp r3 191
je x01_9_xtn_space
cmp r3 161
je x01_9_xtn_space
jmp x01_9_xtn_done
label x01_9_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_9_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_9_xtn_done
add r0 1
cmp r0 r9
jge x01_9_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_9_xtn_space
cmp r3 175
je x01_9_xtn_space
jmp x01_9_xtn_done
label x01_9_xtn_accent
add r0 1
cmp r0 r9
jge x01_9_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_9_xtn_a
cmp r3 161
je x01_9_xtn_a
cmp r3 137
je x01_9_xtn_e
cmp r3 169
je x01_9_xtn_e
cmp r3 141
je x01_9_xtn_i
cmp r3 173
je x01_9_xtn_i
cmp r3 147
je x01_9_xtn_o
cmp r3 179
je x01_9_xtn_o
cmp r3 154
je x01_9_xtn_u
cmp r3 186
je x01_9_xtn_u
cmp r3 145
je x01_9_xtn_n
cmp r3 177
je x01_9_xtn_n
jmp x01_9_xtn_done
label x01_9_xtn_a
set r3 97
jmp x01_9_xtn_append
label x01_9_xtn_e
set r3 101
jmp x01_9_xtn_append
label x01_9_xtn_i
set r3 105
jmp x01_9_xtn_append
label x01_9_xtn_o
set r3 111
jmp x01_9_xtn_append
label x01_9_xtn_u
set r3 117
jmp x01_9_xtn_append
label x01_9_xtn_n
set r3 110
jmp x01_9_xtn_append
label x01_9_xtn_space
cmp r1 0
je x01_9_xtn_next
set r2 1
jmp x01_9_xtn_next
label x01_9_xtn_append
cmp r2 0
je x01_9_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_9_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_9_xtn_next
add r0 1
jmp x01_9_xtn_each
label x01_9_xtn_valid
cmp r1 0
je x01_9_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_9_xtn_done
jmp x01_9_xt_normalized

label x01_lesson_10
store8 9050000000000000016 1
store8 9050000000000000017 2
store8 9050000000000000018 1
store8 9050000000000000019 18
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 104
store8 9050000000000000273 97
store8 9050000000000000274 122
store8 9050000000000000275 32
store8 9050000000000000276 101
store8 9050000000000000277 108
store8 9050000000000000278 32
store8 9050000000000000279 99
store8 9050000000000000280 105
store8 9050000000000000281 99
store8 9050000000000000282 108
store8 9050000000000000283 111
store8 9050000000000000284 32
store8 9050000000000000285 97
store8 9050000000000000286 104
store8 9050000000000000287 111
store8 9050000000000000288 114
store8 9050000000000000289 97
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_10_xt_blank
cmp r0 88
jne x01_10_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_10_xt_invalid
jmp x01_10_xt_validate
label x01_10_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_10_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_10_xt_invalid
add r0 1
cmp r0 16
jlt x01_10_xt_blank_header
set r0 32
label x01_10_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_10_xt_invalid
add r0 1
cmp r0 144
jlt x01_10_xt_blank_context
set r0 4096
label x01_10_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_10_xt_invalid
add r0 1
cmp r0 16384
jlt x01_10_xt_blank_bank
label x01_10_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_10_xt_invalid
cmp r0 0
je x01_10_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_10_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_10_xt_invalid
cmp r0 17
jgt x01_10_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_10_xt_invalid
label x01_10_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_10_xt_invalid
cmp r0 4
jgt x01_10_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_10_xt_invalid
cmp r0 1
jne x01_10_xt_modifier
cmp r1 1
jlt x01_10_xt_invalid
cmp r1 17
jgt x01_10_xt_invalid
jmp x01_10_xt_prepare
label x01_10_xt_modifier
cmp r1 0
jne x01_10_xt_invalid
cmp r2 0
jne x01_10_xt_invalid
label x01_10_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_10_xtn_begin
label x01_10_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_10_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_10_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_10_xt_invalid
set r10 0
label x01_10_xt_lookup
cmp r10 r6
jge x01_10_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_10_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_10_xt_next
set r0 0
label x01_10_xt_compare
cmp r0 r12
jge x01_10_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_10_xt_next
add r0 1
jmp x01_10_xt_compare
label x01_10_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_10_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_10_xt_correct
jmp x01_10_xt_clean
label x01_10_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_10_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_10_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_10_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_10_xt_clean
label x01_10_xt_next
add r10 1
jmp x01_10_xt_lookup
label x01_10_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_10_xt_invalid
cmp r6 128
jge x01_10_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_10_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_10_xt_invalid
add r0 1
cmp r0 96
jlt x01_10_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_10_xt_copy
cmp r0 r12
jge x01_10_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_10_xt_copy
label x01_10_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_10_xt_clean
set r0 16
label x01_10_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_10_xt_clean_mailbox
set r0 256
label x01_10_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_10_xt_clean_scratch
jmp x01_lesson_11
label x01_10_xt_invalid
div r0 0

label x01_10_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_10_xtn_done
cmp r9 255
jgt x01_10_xtn_done
label x01_10_xtn_each
cmp r0 r9
jge x01_10_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_10_xtn_inverted
cmp r3 195
je x01_10_xtn_accent
cmp r3 226
je x01_10_xtn_unicode_space
cmp r3 32
je x01_10_xtn_space
cmp r3 44
je x01_10_xtn_space
cmp r3 46
je x01_10_xtn_space
cmp r3 33
je x01_10_xtn_space
cmp r3 63
je x01_10_xtn_space
cmp r3 65
jlt x01_10_xtn_ascii
cmp r3 90
jgt x01_10_xtn_ascii
add r3 32
label x01_10_xtn_ascii
cmp r3 97
jlt x01_10_xtn_digit
cmp r3 122
jle x01_10_xtn_append
label x01_10_xtn_digit
cmp r3 48
jlt x01_10_xtn_done
cmp r3 57
jgt x01_10_xtn_done
jmp x01_10_xtn_append
label x01_10_xtn_inverted
add r0 1
cmp r0 r9
jge x01_10_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_10_xtn_space
cmp r3 191
je x01_10_xtn_space
cmp r3 161
je x01_10_xtn_space
jmp x01_10_xtn_done
label x01_10_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_10_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_10_xtn_done
add r0 1
cmp r0 r9
jge x01_10_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_10_xtn_space
cmp r3 175
je x01_10_xtn_space
jmp x01_10_xtn_done
label x01_10_xtn_accent
add r0 1
cmp r0 r9
jge x01_10_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_10_xtn_a
cmp r3 161
je x01_10_xtn_a
cmp r3 137
je x01_10_xtn_e
cmp r3 169
je x01_10_xtn_e
cmp r3 141
je x01_10_xtn_i
cmp r3 173
je x01_10_xtn_i
cmp r3 147
je x01_10_xtn_o
cmp r3 179
je x01_10_xtn_o
cmp r3 154
je x01_10_xtn_u
cmp r3 186
je x01_10_xtn_u
cmp r3 145
je x01_10_xtn_n
cmp r3 177
je x01_10_xtn_n
jmp x01_10_xtn_done
label x01_10_xtn_a
set r3 97
jmp x01_10_xtn_append
label x01_10_xtn_e
set r3 101
jmp x01_10_xtn_append
label x01_10_xtn_i
set r3 105
jmp x01_10_xtn_append
label x01_10_xtn_o
set r3 111
jmp x01_10_xtn_append
label x01_10_xtn_u
set r3 117
jmp x01_10_xtn_append
label x01_10_xtn_n
set r3 110
jmp x01_10_xtn_append
label x01_10_xtn_space
cmp r1 0
je x01_10_xtn_next
set r2 1
jmp x01_10_xtn_next
label x01_10_xtn_append
cmp r2 0
je x01_10_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_10_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_10_xtn_next
add r0 1
jmp x01_10_xtn_each
label x01_10_xtn_valid
cmp r1 0
je x01_10_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_10_xtn_done
jmp x01_10_xt_normalized

label x01_lesson_11
store8 9050000000000000016 1
store8 9050000000000000017 2
store8 9050000000000000018 1
store8 9050000000000000019 41
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 104
store8 9050000000000000273 97
store8 9050000000000000274 122
store8 9050000000000000275 108
store8 9050000000000000276 111
store8 9050000000000000277 32
store8 9050000000000000278 105
store8 9050000000000000279 109
store8 9050000000000000280 112
store8 9050000000000000281 108
store8 9050000000000000282 101
store8 9050000000000000283 109
store8 9050000000000000284 101
store8 9050000000000000285 110
store8 9050000000000000286 116
store8 9050000000000000287 97
store8 9050000000000000288 32
store8 9050000000000000289 116
store8 9050000000000000290 111
store8 9050000000000000291 100
store8 9050000000000000292 111
store8 9050000000000000293 32
store8 9050000000000000294 108
store8 9050000000000000295 111
store8 9050000000000000296 32
store8 9050000000000000297 113
store8 9050000000000000298 121
store8 9050000000000000299 101
store8 9050000000000000300 32
store8 9050000000000000301 115
store8 9050000000000000302 105
store8 9050000000000000303 32
store8 9050000000000000304 110
store8 9050000000000000305 105
store8 9050000000000000306 115
store8 9050000000000000307 32
store8 9050000000000000308 115
store8 9050000000000000309 105
store8 9050000000000000310 114
store8 9050000000000000311 118
store8 9050000000000000312 101
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_11_xt_blank
cmp r0 88
jne x01_11_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_11_xt_invalid
jmp x01_11_xt_validate
label x01_11_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_11_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_11_xt_invalid
add r0 1
cmp r0 16
jlt x01_11_xt_blank_header
set r0 32
label x01_11_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_11_xt_invalid
add r0 1
cmp r0 144
jlt x01_11_xt_blank_context
set r0 4096
label x01_11_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_11_xt_invalid
add r0 1
cmp r0 16384
jlt x01_11_xt_blank_bank
label x01_11_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_11_xt_invalid
cmp r0 0
je x01_11_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_11_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_11_xt_invalid
cmp r0 17
jgt x01_11_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_11_xt_invalid
label x01_11_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_11_xt_invalid
cmp r0 4
jgt x01_11_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_11_xt_invalid
cmp r0 1
jne x01_11_xt_modifier
cmp r1 1
jlt x01_11_xt_invalid
cmp r1 17
jgt x01_11_xt_invalid
jmp x01_11_xt_prepare
label x01_11_xt_modifier
cmp r1 0
jne x01_11_xt_invalid
cmp r2 0
jne x01_11_xt_invalid
label x01_11_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_11_xtn_begin
label x01_11_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_11_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_11_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_11_xt_invalid
set r10 0
label x01_11_xt_lookup
cmp r10 r6
jge x01_11_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_11_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_11_xt_next
set r0 0
label x01_11_xt_compare
cmp r0 r12
jge x01_11_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_11_xt_next
add r0 1
jmp x01_11_xt_compare
label x01_11_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_11_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_11_xt_correct
jmp x01_11_xt_clean
label x01_11_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_11_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_11_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_11_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_11_xt_clean
label x01_11_xt_next
add r10 1
jmp x01_11_xt_lookup
label x01_11_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_11_xt_invalid
cmp r6 128
jge x01_11_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_11_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_11_xt_invalid
add r0 1
cmp r0 96
jlt x01_11_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_11_xt_copy
cmp r0 r12
jge x01_11_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_11_xt_copy
label x01_11_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_11_xt_clean
set r0 16
label x01_11_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_11_xt_clean_mailbox
set r0 256
label x01_11_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_11_xt_clean_scratch
jmp x01_lesson_12
label x01_11_xt_invalid
div r0 0

label x01_11_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_11_xtn_done
cmp r9 255
jgt x01_11_xtn_done
label x01_11_xtn_each
cmp r0 r9
jge x01_11_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_11_xtn_inverted
cmp r3 195
je x01_11_xtn_accent
cmp r3 226
je x01_11_xtn_unicode_space
cmp r3 32
je x01_11_xtn_space
cmp r3 44
je x01_11_xtn_space
cmp r3 46
je x01_11_xtn_space
cmp r3 33
je x01_11_xtn_space
cmp r3 63
je x01_11_xtn_space
cmp r3 65
jlt x01_11_xtn_ascii
cmp r3 90
jgt x01_11_xtn_ascii
add r3 32
label x01_11_xtn_ascii
cmp r3 97
jlt x01_11_xtn_digit
cmp r3 122
jle x01_11_xtn_append
label x01_11_xtn_digit
cmp r3 48
jlt x01_11_xtn_done
cmp r3 57
jgt x01_11_xtn_done
jmp x01_11_xtn_append
label x01_11_xtn_inverted
add r0 1
cmp r0 r9
jge x01_11_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_11_xtn_space
cmp r3 191
je x01_11_xtn_space
cmp r3 161
je x01_11_xtn_space
jmp x01_11_xtn_done
label x01_11_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_11_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_11_xtn_done
add r0 1
cmp r0 r9
jge x01_11_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_11_xtn_space
cmp r3 175
je x01_11_xtn_space
jmp x01_11_xtn_done
label x01_11_xtn_accent
add r0 1
cmp r0 r9
jge x01_11_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_11_xtn_a
cmp r3 161
je x01_11_xtn_a
cmp r3 137
je x01_11_xtn_e
cmp r3 169
je x01_11_xtn_e
cmp r3 141
je x01_11_xtn_i
cmp r3 173
je x01_11_xtn_i
cmp r3 147
je x01_11_xtn_o
cmp r3 179
je x01_11_xtn_o
cmp r3 154
je x01_11_xtn_u
cmp r3 186
je x01_11_xtn_u
cmp r3 145
je x01_11_xtn_n
cmp r3 177
je x01_11_xtn_n
jmp x01_11_xtn_done
label x01_11_xtn_a
set r3 97
jmp x01_11_xtn_append
label x01_11_xtn_e
set r3 101
jmp x01_11_xtn_append
label x01_11_xtn_i
set r3 105
jmp x01_11_xtn_append
label x01_11_xtn_o
set r3 111
jmp x01_11_xtn_append
label x01_11_xtn_u
set r3 117
jmp x01_11_xtn_append
label x01_11_xtn_n
set r3 110
jmp x01_11_xtn_append
label x01_11_xtn_space
cmp r1 0
je x01_11_xtn_next
set r2 1
jmp x01_11_xtn_next
label x01_11_xtn_append
cmp r2 0
je x01_11_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_11_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_11_xtn_next
add r0 1
jmp x01_11_xtn_each
label x01_11_xtn_valid
cmp r1 0
je x01_11_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_11_xtn_done
jmp x01_11_xt_normalized

label x01_lesson_12
store8 9050000000000000016 1
store8 9050000000000000017 3
store8 9050000000000000018 1
store8 9050000000000000019 10
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 101
store8 9050000000000000273 110
store8 9050000000000000274 32
store8 9050000000000000275 114
store8 9050000000000000276 101
store8 9050000000000000277 115
store8 9050000000000000278 117
store8 9050000000000000279 109
store8 9050000000000000280 101
store8 9050000000000000281 110
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_12_xt_blank
cmp r0 88
jne x01_12_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_12_xt_invalid
jmp x01_12_xt_validate
label x01_12_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_12_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_12_xt_invalid
add r0 1
cmp r0 16
jlt x01_12_xt_blank_header
set r0 32
label x01_12_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_12_xt_invalid
add r0 1
cmp r0 144
jlt x01_12_xt_blank_context
set r0 4096
label x01_12_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_12_xt_invalid
add r0 1
cmp r0 16384
jlt x01_12_xt_blank_bank
label x01_12_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_12_xt_invalid
cmp r0 0
je x01_12_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_12_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_12_xt_invalid
cmp r0 17
jgt x01_12_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_12_xt_invalid
label x01_12_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_12_xt_invalid
cmp r0 4
jgt x01_12_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_12_xt_invalid
cmp r0 1
jne x01_12_xt_modifier
cmp r1 1
jlt x01_12_xt_invalid
cmp r1 17
jgt x01_12_xt_invalid
jmp x01_12_xt_prepare
label x01_12_xt_modifier
cmp r1 0
jne x01_12_xt_invalid
cmp r2 0
jne x01_12_xt_invalid
label x01_12_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_12_xtn_begin
label x01_12_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_12_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_12_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_12_xt_invalid
set r10 0
label x01_12_xt_lookup
cmp r10 r6
jge x01_12_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_12_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_12_xt_next
set r0 0
label x01_12_xt_compare
cmp r0 r12
jge x01_12_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_12_xt_next
add r0 1
jmp x01_12_xt_compare
label x01_12_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_12_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_12_xt_correct
jmp x01_12_xt_clean
label x01_12_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_12_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_12_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_12_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_12_xt_clean
label x01_12_xt_next
add r10 1
jmp x01_12_xt_lookup
label x01_12_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_12_xt_invalid
cmp r6 128
jge x01_12_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_12_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_12_xt_invalid
add r0 1
cmp r0 96
jlt x01_12_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_12_xt_copy
cmp r0 r12
jge x01_12_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_12_xt_copy
label x01_12_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_12_xt_clean
set r0 16
label x01_12_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_12_xt_clean_mailbox
set r0 256
label x01_12_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_12_xt_clean_scratch
jmp x01_lesson_13
label x01_12_xt_invalid
div r0 0

label x01_12_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_12_xtn_done
cmp r9 255
jgt x01_12_xtn_done
label x01_12_xtn_each
cmp r0 r9
jge x01_12_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_12_xtn_inverted
cmp r3 195
je x01_12_xtn_accent
cmp r3 226
je x01_12_xtn_unicode_space
cmp r3 32
je x01_12_xtn_space
cmp r3 44
je x01_12_xtn_space
cmp r3 46
je x01_12_xtn_space
cmp r3 33
je x01_12_xtn_space
cmp r3 63
je x01_12_xtn_space
cmp r3 65
jlt x01_12_xtn_ascii
cmp r3 90
jgt x01_12_xtn_ascii
add r3 32
label x01_12_xtn_ascii
cmp r3 97
jlt x01_12_xtn_digit
cmp r3 122
jle x01_12_xtn_append
label x01_12_xtn_digit
cmp r3 48
jlt x01_12_xtn_done
cmp r3 57
jgt x01_12_xtn_done
jmp x01_12_xtn_append
label x01_12_xtn_inverted
add r0 1
cmp r0 r9
jge x01_12_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_12_xtn_space
cmp r3 191
je x01_12_xtn_space
cmp r3 161
je x01_12_xtn_space
jmp x01_12_xtn_done
label x01_12_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_12_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_12_xtn_done
add r0 1
cmp r0 r9
jge x01_12_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_12_xtn_space
cmp r3 175
je x01_12_xtn_space
jmp x01_12_xtn_done
label x01_12_xtn_accent
add r0 1
cmp r0 r9
jge x01_12_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_12_xtn_a
cmp r3 161
je x01_12_xtn_a
cmp r3 137
je x01_12_xtn_e
cmp r3 169
je x01_12_xtn_e
cmp r3 141
je x01_12_xtn_i
cmp r3 173
je x01_12_xtn_i
cmp r3 147
je x01_12_xtn_o
cmp r3 179
je x01_12_xtn_o
cmp r3 154
je x01_12_xtn_u
cmp r3 186
je x01_12_xtn_u
cmp r3 145
je x01_12_xtn_n
cmp r3 177
je x01_12_xtn_n
jmp x01_12_xtn_done
label x01_12_xtn_a
set r3 97
jmp x01_12_xtn_append
label x01_12_xtn_e
set r3 101
jmp x01_12_xtn_append
label x01_12_xtn_i
set r3 105
jmp x01_12_xtn_append
label x01_12_xtn_o
set r3 111
jmp x01_12_xtn_append
label x01_12_xtn_u
set r3 117
jmp x01_12_xtn_append
label x01_12_xtn_n
set r3 110
jmp x01_12_xtn_append
label x01_12_xtn_space
cmp r1 0
je x01_12_xtn_next
set r2 1
jmp x01_12_xtn_next
label x01_12_xtn_append
cmp r2 0
je x01_12_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_12_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_12_xtn_next
add r0 1
jmp x01_12_xtn_each
label x01_12_xtn_valid
cmp r1 0
je x01_12_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_12_xtn_done
jmp x01_12_xt_normalized

label x01_lesson_13
store8 9050000000000000016 1
store8 9050000000000000017 3
store8 9050000000000000018 1
store8 9050000000000000019 7
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 114
store8 9050000000000000273 101
store8 9050000000000000274 115
store8 9050000000000000275 117
store8 9050000000000000276 109
store8 9050000000000000277 101
store8 9050000000000000278 110
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_13_xt_blank
cmp r0 88
jne x01_13_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_13_xt_invalid
jmp x01_13_xt_validate
label x01_13_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_13_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_13_xt_invalid
add r0 1
cmp r0 16
jlt x01_13_xt_blank_header
set r0 32
label x01_13_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_13_xt_invalid
add r0 1
cmp r0 144
jlt x01_13_xt_blank_context
set r0 4096
label x01_13_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_13_xt_invalid
add r0 1
cmp r0 16384
jlt x01_13_xt_blank_bank
label x01_13_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_13_xt_invalid
cmp r0 0
je x01_13_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_13_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_13_xt_invalid
cmp r0 17
jgt x01_13_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_13_xt_invalid
label x01_13_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_13_xt_invalid
cmp r0 4
jgt x01_13_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_13_xt_invalid
cmp r0 1
jne x01_13_xt_modifier
cmp r1 1
jlt x01_13_xt_invalid
cmp r1 17
jgt x01_13_xt_invalid
jmp x01_13_xt_prepare
label x01_13_xt_modifier
cmp r1 0
jne x01_13_xt_invalid
cmp r2 0
jne x01_13_xt_invalid
label x01_13_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_13_xtn_begin
label x01_13_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_13_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_13_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_13_xt_invalid
set r10 0
label x01_13_xt_lookup
cmp r10 r6
jge x01_13_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_13_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_13_xt_next
set r0 0
label x01_13_xt_compare
cmp r0 r12
jge x01_13_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_13_xt_next
add r0 1
jmp x01_13_xt_compare
label x01_13_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_13_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_13_xt_correct
jmp x01_13_xt_clean
label x01_13_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_13_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_13_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_13_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_13_xt_clean
label x01_13_xt_next
add r10 1
jmp x01_13_xt_lookup
label x01_13_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_13_xt_invalid
cmp r6 128
jge x01_13_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_13_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_13_xt_invalid
add r0 1
cmp r0 96
jlt x01_13_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_13_xt_copy
cmp r0 r12
jge x01_13_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_13_xt_copy
label x01_13_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_13_xt_clean
set r0 16
label x01_13_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_13_xt_clean_mailbox
set r0 256
label x01_13_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_13_xt_clean_scratch
jmp x01_lesson_14
label x01_13_xt_invalid
div r0 0

label x01_13_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_13_xtn_done
cmp r9 255
jgt x01_13_xtn_done
label x01_13_xtn_each
cmp r0 r9
jge x01_13_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_13_xtn_inverted
cmp r3 195
je x01_13_xtn_accent
cmp r3 226
je x01_13_xtn_unicode_space
cmp r3 32
je x01_13_xtn_space
cmp r3 44
je x01_13_xtn_space
cmp r3 46
je x01_13_xtn_space
cmp r3 33
je x01_13_xtn_space
cmp r3 63
je x01_13_xtn_space
cmp r3 65
jlt x01_13_xtn_ascii
cmp r3 90
jgt x01_13_xtn_ascii
add r3 32
label x01_13_xtn_ascii
cmp r3 97
jlt x01_13_xtn_digit
cmp r3 122
jle x01_13_xtn_append
label x01_13_xtn_digit
cmp r3 48
jlt x01_13_xtn_done
cmp r3 57
jgt x01_13_xtn_done
jmp x01_13_xtn_append
label x01_13_xtn_inverted
add r0 1
cmp r0 r9
jge x01_13_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_13_xtn_space
cmp r3 191
je x01_13_xtn_space
cmp r3 161
je x01_13_xtn_space
jmp x01_13_xtn_done
label x01_13_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_13_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_13_xtn_done
add r0 1
cmp r0 r9
jge x01_13_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_13_xtn_space
cmp r3 175
je x01_13_xtn_space
jmp x01_13_xtn_done
label x01_13_xtn_accent
add r0 1
cmp r0 r9
jge x01_13_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_13_xtn_a
cmp r3 161
je x01_13_xtn_a
cmp r3 137
je x01_13_xtn_e
cmp r3 169
je x01_13_xtn_e
cmp r3 141
je x01_13_xtn_i
cmp r3 173
je x01_13_xtn_i
cmp r3 147
je x01_13_xtn_o
cmp r3 179
je x01_13_xtn_o
cmp r3 154
je x01_13_xtn_u
cmp r3 186
je x01_13_xtn_u
cmp r3 145
je x01_13_xtn_n
cmp r3 177
je x01_13_xtn_n
jmp x01_13_xtn_done
label x01_13_xtn_a
set r3 97
jmp x01_13_xtn_append
label x01_13_xtn_e
set r3 101
jmp x01_13_xtn_append
label x01_13_xtn_i
set r3 105
jmp x01_13_xtn_append
label x01_13_xtn_o
set r3 111
jmp x01_13_xtn_append
label x01_13_xtn_u
set r3 117
jmp x01_13_xtn_append
label x01_13_xtn_n
set r3 110
jmp x01_13_xtn_append
label x01_13_xtn_space
cmp r1 0
je x01_13_xtn_next
set r2 1
jmp x01_13_xtn_next
label x01_13_xtn_append
cmp r2 0
je x01_13_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_13_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_13_xtn_next
add r0 1
jmp x01_13_xtn_each
label x01_13_xtn_valid
cmp r1 0
je x01_13_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_13_xtn_done
jmp x01_13_xt_normalized

label x01_lesson_14
store8 9050000000000000016 1
store8 9050000000000000017 3
store8 9050000000000000018 1
store8 9050000000000000019 14
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 101
store8 9050000000000000273 110
store8 9050000000000000274 32
store8 9050000000000000275 114
store8 9050000000000000276 101
store8 9050000000000000277 115
store8 9050000000000000278 117
store8 9050000000000000279 109
store8 9050000000000000280 101
store8 9050000000000000281 110
store8 9050000000000000282 32
store8 9050000000000000283 113
store8 9050000000000000284 117
store8 9050000000000000285 101
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_14_xt_blank
cmp r0 88
jne x01_14_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_14_xt_invalid
jmp x01_14_xt_validate
label x01_14_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_14_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_14_xt_invalid
add r0 1
cmp r0 16
jlt x01_14_xt_blank_header
set r0 32
label x01_14_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_14_xt_invalid
add r0 1
cmp r0 144
jlt x01_14_xt_blank_context
set r0 4096
label x01_14_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_14_xt_invalid
add r0 1
cmp r0 16384
jlt x01_14_xt_blank_bank
label x01_14_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_14_xt_invalid
cmp r0 0
je x01_14_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_14_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_14_xt_invalid
cmp r0 17
jgt x01_14_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_14_xt_invalid
label x01_14_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_14_xt_invalid
cmp r0 4
jgt x01_14_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_14_xt_invalid
cmp r0 1
jne x01_14_xt_modifier
cmp r1 1
jlt x01_14_xt_invalid
cmp r1 17
jgt x01_14_xt_invalid
jmp x01_14_xt_prepare
label x01_14_xt_modifier
cmp r1 0
jne x01_14_xt_invalid
cmp r2 0
jne x01_14_xt_invalid
label x01_14_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_14_xtn_begin
label x01_14_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_14_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_14_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_14_xt_invalid
set r10 0
label x01_14_xt_lookup
cmp r10 r6
jge x01_14_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_14_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_14_xt_next
set r0 0
label x01_14_xt_compare
cmp r0 r12
jge x01_14_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_14_xt_next
add r0 1
jmp x01_14_xt_compare
label x01_14_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_14_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_14_xt_correct
jmp x01_14_xt_clean
label x01_14_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_14_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_14_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_14_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_14_xt_clean
label x01_14_xt_next
add r10 1
jmp x01_14_xt_lookup
label x01_14_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_14_xt_invalid
cmp r6 128
jge x01_14_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_14_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_14_xt_invalid
add r0 1
cmp r0 96
jlt x01_14_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_14_xt_copy
cmp r0 r12
jge x01_14_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_14_xt_copy
label x01_14_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_14_xt_clean
set r0 16
label x01_14_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_14_xt_clean_mailbox
set r0 256
label x01_14_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_14_xt_clean_scratch
jmp x01_lesson_15
label x01_14_xt_invalid
div r0 0

label x01_14_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_14_xtn_done
cmp r9 255
jgt x01_14_xtn_done
label x01_14_xtn_each
cmp r0 r9
jge x01_14_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_14_xtn_inverted
cmp r3 195
je x01_14_xtn_accent
cmp r3 226
je x01_14_xtn_unicode_space
cmp r3 32
je x01_14_xtn_space
cmp r3 44
je x01_14_xtn_space
cmp r3 46
je x01_14_xtn_space
cmp r3 33
je x01_14_xtn_space
cmp r3 63
je x01_14_xtn_space
cmp r3 65
jlt x01_14_xtn_ascii
cmp r3 90
jgt x01_14_xtn_ascii
add r3 32
label x01_14_xtn_ascii
cmp r3 97
jlt x01_14_xtn_digit
cmp r3 122
jle x01_14_xtn_append
label x01_14_xtn_digit
cmp r3 48
jlt x01_14_xtn_done
cmp r3 57
jgt x01_14_xtn_done
jmp x01_14_xtn_append
label x01_14_xtn_inverted
add r0 1
cmp r0 r9
jge x01_14_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_14_xtn_space
cmp r3 191
je x01_14_xtn_space
cmp r3 161
je x01_14_xtn_space
jmp x01_14_xtn_done
label x01_14_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_14_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_14_xtn_done
add r0 1
cmp r0 r9
jge x01_14_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_14_xtn_space
cmp r3 175
je x01_14_xtn_space
jmp x01_14_xtn_done
label x01_14_xtn_accent
add r0 1
cmp r0 r9
jge x01_14_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_14_xtn_a
cmp r3 161
je x01_14_xtn_a
cmp r3 137
je x01_14_xtn_e
cmp r3 169
je x01_14_xtn_e
cmp r3 141
je x01_14_xtn_i
cmp r3 173
je x01_14_xtn_i
cmp r3 147
je x01_14_xtn_o
cmp r3 179
je x01_14_xtn_o
cmp r3 154
je x01_14_xtn_u
cmp r3 186
je x01_14_xtn_u
cmp r3 145
je x01_14_xtn_n
cmp r3 177
je x01_14_xtn_n
jmp x01_14_xtn_done
label x01_14_xtn_a
set r3 97
jmp x01_14_xtn_append
label x01_14_xtn_e
set r3 101
jmp x01_14_xtn_append
label x01_14_xtn_i
set r3 105
jmp x01_14_xtn_append
label x01_14_xtn_o
set r3 111
jmp x01_14_xtn_append
label x01_14_xtn_u
set r3 117
jmp x01_14_xtn_append
label x01_14_xtn_n
set r3 110
jmp x01_14_xtn_append
label x01_14_xtn_space
cmp r1 0
je x01_14_xtn_next
set r2 1
jmp x01_14_xtn_next
label x01_14_xtn_append
cmp r2 0
je x01_14_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_14_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_14_xtn_next
add r0 1
jmp x01_14_xtn_each
label x01_14_xtn_valid
cmp r1 0
je x01_14_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_14_xtn_done
jmp x01_14_xt_normalized

label x01_lesson_15
store8 9050000000000000016 1
store8 9050000000000000017 3
store8 9050000000000000018 1
store8 9050000000000000019 19
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 101
store8 9050000000000000273 110
store8 9050000000000000274 32
store8 9050000000000000275 114
store8 9050000000000000276 101
store8 9050000000000000277 115
store8 9050000000000000278 117
store8 9050000000000000279 109
store8 9050000000000000280 101
store8 9050000000000000281 110
store8 9050000000000000282 32
store8 9050000000000000283 110
store8 9050000000000000284 97
store8 9050000000000000285 100
store8 9050000000000000286 97
store8 9050000000000000287 32
store8 9050000000000000288 97
store8 9050000000000000289 117
store8 9050000000000000290 110
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_15_xt_blank
cmp r0 88
jne x01_15_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_15_xt_invalid
jmp x01_15_xt_validate
label x01_15_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_15_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_15_xt_invalid
add r0 1
cmp r0 16
jlt x01_15_xt_blank_header
set r0 32
label x01_15_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_15_xt_invalid
add r0 1
cmp r0 144
jlt x01_15_xt_blank_context
set r0 4096
label x01_15_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_15_xt_invalid
add r0 1
cmp r0 16384
jlt x01_15_xt_blank_bank
label x01_15_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_15_xt_invalid
cmp r0 0
je x01_15_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_15_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_15_xt_invalid
cmp r0 17
jgt x01_15_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_15_xt_invalid
label x01_15_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_15_xt_invalid
cmp r0 4
jgt x01_15_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_15_xt_invalid
cmp r0 1
jne x01_15_xt_modifier
cmp r1 1
jlt x01_15_xt_invalid
cmp r1 17
jgt x01_15_xt_invalid
jmp x01_15_xt_prepare
label x01_15_xt_modifier
cmp r1 0
jne x01_15_xt_invalid
cmp r2 0
jne x01_15_xt_invalid
label x01_15_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_15_xtn_begin
label x01_15_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_15_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_15_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_15_xt_invalid
set r10 0
label x01_15_xt_lookup
cmp r10 r6
jge x01_15_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_15_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_15_xt_next
set r0 0
label x01_15_xt_compare
cmp r0 r12
jge x01_15_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_15_xt_next
add r0 1
jmp x01_15_xt_compare
label x01_15_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_15_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_15_xt_correct
jmp x01_15_xt_clean
label x01_15_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_15_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_15_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_15_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_15_xt_clean
label x01_15_xt_next
add r10 1
jmp x01_15_xt_lookup
label x01_15_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_15_xt_invalid
cmp r6 128
jge x01_15_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_15_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_15_xt_invalid
add r0 1
cmp r0 96
jlt x01_15_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_15_xt_copy
cmp r0 r12
jge x01_15_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_15_xt_copy
label x01_15_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_15_xt_clean
set r0 16
label x01_15_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_15_xt_clean_mailbox
set r0 256
label x01_15_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_15_xt_clean_scratch
jmp x01_lesson_16
label x01_15_xt_invalid
div r0 0

label x01_15_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_15_xtn_done
cmp r9 255
jgt x01_15_xtn_done
label x01_15_xtn_each
cmp r0 r9
jge x01_15_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_15_xtn_inverted
cmp r3 195
je x01_15_xtn_accent
cmp r3 226
je x01_15_xtn_unicode_space
cmp r3 32
je x01_15_xtn_space
cmp r3 44
je x01_15_xtn_space
cmp r3 46
je x01_15_xtn_space
cmp r3 33
je x01_15_xtn_space
cmp r3 63
je x01_15_xtn_space
cmp r3 65
jlt x01_15_xtn_ascii
cmp r3 90
jgt x01_15_xtn_ascii
add r3 32
label x01_15_xtn_ascii
cmp r3 97
jlt x01_15_xtn_digit
cmp r3 122
jle x01_15_xtn_append
label x01_15_xtn_digit
cmp r3 48
jlt x01_15_xtn_done
cmp r3 57
jgt x01_15_xtn_done
jmp x01_15_xtn_append
label x01_15_xtn_inverted
add r0 1
cmp r0 r9
jge x01_15_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_15_xtn_space
cmp r3 191
je x01_15_xtn_space
cmp r3 161
je x01_15_xtn_space
jmp x01_15_xtn_done
label x01_15_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_15_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_15_xtn_done
add r0 1
cmp r0 r9
jge x01_15_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_15_xtn_space
cmp r3 175
je x01_15_xtn_space
jmp x01_15_xtn_done
label x01_15_xtn_accent
add r0 1
cmp r0 r9
jge x01_15_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_15_xtn_a
cmp r3 161
je x01_15_xtn_a
cmp r3 137
je x01_15_xtn_e
cmp r3 169
je x01_15_xtn_e
cmp r3 141
je x01_15_xtn_i
cmp r3 173
je x01_15_xtn_i
cmp r3 147
je x01_15_xtn_o
cmp r3 179
je x01_15_xtn_o
cmp r3 154
je x01_15_xtn_u
cmp r3 186
je x01_15_xtn_u
cmp r3 145
je x01_15_xtn_n
cmp r3 177
je x01_15_xtn_n
jmp x01_15_xtn_done
label x01_15_xtn_a
set r3 97
jmp x01_15_xtn_append
label x01_15_xtn_e
set r3 101
jmp x01_15_xtn_append
label x01_15_xtn_i
set r3 105
jmp x01_15_xtn_append
label x01_15_xtn_o
set r3 111
jmp x01_15_xtn_append
label x01_15_xtn_u
set r3 117
jmp x01_15_xtn_append
label x01_15_xtn_n
set r3 110
jmp x01_15_xtn_append
label x01_15_xtn_space
cmp r1 0
je x01_15_xtn_next
set r2 1
jmp x01_15_xtn_next
label x01_15_xtn_append
cmp r2 0
je x01_15_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_15_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_15_xtn_next
add r0 1
jmp x01_15_xtn_each
label x01_15_xtn_valid
cmp r1 0
je x01_15_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_15_xtn_done
jmp x01_15_xt_normalized

label x01_lesson_16
store8 9050000000000000016 1
store8 9050000000000000017 4
store8 9050000000000000018 0
store8 9050000000000000019 11
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 110
store8 9050000000000000273 111
store8 9050000000000000274 32
store8 9050000000000000275 101
store8 9050000000000000276 110
store8 9050000000000000277 116
store8 9050000000000000278 101
store8 9050000000000000279 110
store8 9050000000000000280 100
store8 9050000000000000281 195
store8 9050000000000000282 173
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_16_xt_blank
cmp r0 88
jne x01_16_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_16_xt_invalid
jmp x01_16_xt_validate
label x01_16_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_16_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_16_xt_invalid
add r0 1
cmp r0 16
jlt x01_16_xt_blank_header
set r0 32
label x01_16_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_16_xt_invalid
add r0 1
cmp r0 144
jlt x01_16_xt_blank_context
set r0 4096
label x01_16_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_16_xt_invalid
add r0 1
cmp r0 16384
jlt x01_16_xt_blank_bank
label x01_16_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_16_xt_invalid
cmp r0 0
je x01_16_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_16_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_16_xt_invalid
cmp r0 17
jgt x01_16_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_16_xt_invalid
label x01_16_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_16_xt_invalid
cmp r0 4
jgt x01_16_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_16_xt_invalid
cmp r0 1
jne x01_16_xt_modifier
cmp r1 1
jlt x01_16_xt_invalid
cmp r1 17
jgt x01_16_xt_invalid
jmp x01_16_xt_prepare
label x01_16_xt_modifier
cmp r1 0
jne x01_16_xt_invalid
cmp r2 0
jne x01_16_xt_invalid
label x01_16_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_16_xtn_begin
label x01_16_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_16_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_16_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_16_xt_invalid
set r10 0
label x01_16_xt_lookup
cmp r10 r6
jge x01_16_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_16_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_16_xt_next
set r0 0
label x01_16_xt_compare
cmp r0 r12
jge x01_16_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_16_xt_next
add r0 1
jmp x01_16_xt_compare
label x01_16_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_16_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_16_xt_correct
jmp x01_16_xt_clean
label x01_16_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_16_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_16_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_16_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_16_xt_clean
label x01_16_xt_next
add r10 1
jmp x01_16_xt_lookup
label x01_16_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_16_xt_invalid
cmp r6 128
jge x01_16_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_16_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_16_xt_invalid
add r0 1
cmp r0 96
jlt x01_16_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_16_xt_copy
cmp r0 r12
jge x01_16_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_16_xt_copy
label x01_16_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_16_xt_clean
set r0 16
label x01_16_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_16_xt_clean_mailbox
set r0 256
label x01_16_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_16_xt_clean_scratch
jmp x01_lesson_17
label x01_16_xt_invalid
div r0 0

label x01_16_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_16_xtn_done
cmp r9 255
jgt x01_16_xtn_done
label x01_16_xtn_each
cmp r0 r9
jge x01_16_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_16_xtn_inverted
cmp r3 195
je x01_16_xtn_accent
cmp r3 226
je x01_16_xtn_unicode_space
cmp r3 32
je x01_16_xtn_space
cmp r3 44
je x01_16_xtn_space
cmp r3 46
je x01_16_xtn_space
cmp r3 33
je x01_16_xtn_space
cmp r3 63
je x01_16_xtn_space
cmp r3 65
jlt x01_16_xtn_ascii
cmp r3 90
jgt x01_16_xtn_ascii
add r3 32
label x01_16_xtn_ascii
cmp r3 97
jlt x01_16_xtn_digit
cmp r3 122
jle x01_16_xtn_append
label x01_16_xtn_digit
cmp r3 48
jlt x01_16_xtn_done
cmp r3 57
jgt x01_16_xtn_done
jmp x01_16_xtn_append
label x01_16_xtn_inverted
add r0 1
cmp r0 r9
jge x01_16_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_16_xtn_space
cmp r3 191
je x01_16_xtn_space
cmp r3 161
je x01_16_xtn_space
jmp x01_16_xtn_done
label x01_16_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_16_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_16_xtn_done
add r0 1
cmp r0 r9
jge x01_16_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_16_xtn_space
cmp r3 175
je x01_16_xtn_space
jmp x01_16_xtn_done
label x01_16_xtn_accent
add r0 1
cmp r0 r9
jge x01_16_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_16_xtn_a
cmp r3 161
je x01_16_xtn_a
cmp r3 137
je x01_16_xtn_e
cmp r3 169
je x01_16_xtn_e
cmp r3 141
je x01_16_xtn_i
cmp r3 173
je x01_16_xtn_i
cmp r3 147
je x01_16_xtn_o
cmp r3 179
je x01_16_xtn_o
cmp r3 154
je x01_16_xtn_u
cmp r3 186
je x01_16_xtn_u
cmp r3 145
je x01_16_xtn_n
cmp r3 177
je x01_16_xtn_n
jmp x01_16_xtn_done
label x01_16_xtn_a
set r3 97
jmp x01_16_xtn_append
label x01_16_xtn_e
set r3 101
jmp x01_16_xtn_append
label x01_16_xtn_i
set r3 105
jmp x01_16_xtn_append
label x01_16_xtn_o
set r3 111
jmp x01_16_xtn_append
label x01_16_xtn_u
set r3 117
jmp x01_16_xtn_append
label x01_16_xtn_n
set r3 110
jmp x01_16_xtn_append
label x01_16_xtn_space
cmp r1 0
je x01_16_xtn_next
set r2 1
jmp x01_16_xtn_next
label x01_16_xtn_append
cmp r2 0
je x01_16_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_16_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_16_xtn_next
add r0 1
jmp x01_16_xtn_each
label x01_16_xtn_valid
cmp r1 0
je x01_16_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_16_xtn_done
jmp x01_16_xt_normalized

label x01_lesson_17
store8 9050000000000000016 1
store8 9050000000000000017 4
store8 9050000000000000018 0
store8 9050000000000000019 14
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 109
store8 9050000000000000273 101
store8 9050000000000000274 32
store8 9050000000000000275 99
store8 9050000000000000276 111
store8 9050000000000000277 110
store8 9050000000000000278 102
store8 9050000000000000279 117
store8 9050000000000000280 110
store8 9050000000000000281 100
store8 9050000000000000282 105
store8 9050000000000000283 115
store8 9050000000000000284 116
store8 9050000000000000285 101
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_17_xt_blank
cmp r0 88
jne x01_17_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_17_xt_invalid
jmp x01_17_xt_validate
label x01_17_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_17_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_17_xt_invalid
add r0 1
cmp r0 16
jlt x01_17_xt_blank_header
set r0 32
label x01_17_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_17_xt_invalid
add r0 1
cmp r0 144
jlt x01_17_xt_blank_context
set r0 4096
label x01_17_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_17_xt_invalid
add r0 1
cmp r0 16384
jlt x01_17_xt_blank_bank
label x01_17_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_17_xt_invalid
cmp r0 0
je x01_17_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_17_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_17_xt_invalid
cmp r0 17
jgt x01_17_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_17_xt_invalid
label x01_17_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_17_xt_invalid
cmp r0 4
jgt x01_17_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_17_xt_invalid
cmp r0 1
jne x01_17_xt_modifier
cmp r1 1
jlt x01_17_xt_invalid
cmp r1 17
jgt x01_17_xt_invalid
jmp x01_17_xt_prepare
label x01_17_xt_modifier
cmp r1 0
jne x01_17_xt_invalid
cmp r2 0
jne x01_17_xt_invalid
label x01_17_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_17_xtn_begin
label x01_17_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_17_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_17_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_17_xt_invalid
set r10 0
label x01_17_xt_lookup
cmp r10 r6
jge x01_17_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_17_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_17_xt_next
set r0 0
label x01_17_xt_compare
cmp r0 r12
jge x01_17_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_17_xt_next
add r0 1
jmp x01_17_xt_compare
label x01_17_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_17_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_17_xt_correct
jmp x01_17_xt_clean
label x01_17_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_17_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_17_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_17_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_17_xt_clean
label x01_17_xt_next
add r10 1
jmp x01_17_xt_lookup
label x01_17_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_17_xt_invalid
cmp r6 128
jge x01_17_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_17_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_17_xt_invalid
add r0 1
cmp r0 96
jlt x01_17_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_17_xt_copy
cmp r0 r12
jge x01_17_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_17_xt_copy
label x01_17_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_17_xt_clean
set r0 16
label x01_17_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_17_xt_clean_mailbox
set r0 256
label x01_17_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_17_xt_clean_scratch
jmp x01_lesson_18
label x01_17_xt_invalid
div r0 0

label x01_17_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_17_xtn_done
cmp r9 255
jgt x01_17_xtn_done
label x01_17_xtn_each
cmp r0 r9
jge x01_17_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_17_xtn_inverted
cmp r3 195
je x01_17_xtn_accent
cmp r3 226
je x01_17_xtn_unicode_space
cmp r3 32
je x01_17_xtn_space
cmp r3 44
je x01_17_xtn_space
cmp r3 46
je x01_17_xtn_space
cmp r3 33
je x01_17_xtn_space
cmp r3 63
je x01_17_xtn_space
cmp r3 65
jlt x01_17_xtn_ascii
cmp r3 90
jgt x01_17_xtn_ascii
add r3 32
label x01_17_xtn_ascii
cmp r3 97
jlt x01_17_xtn_digit
cmp r3 122
jle x01_17_xtn_append
label x01_17_xtn_digit
cmp r3 48
jlt x01_17_xtn_done
cmp r3 57
jgt x01_17_xtn_done
jmp x01_17_xtn_append
label x01_17_xtn_inverted
add r0 1
cmp r0 r9
jge x01_17_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_17_xtn_space
cmp r3 191
je x01_17_xtn_space
cmp r3 161
je x01_17_xtn_space
jmp x01_17_xtn_done
label x01_17_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_17_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_17_xtn_done
add r0 1
cmp r0 r9
jge x01_17_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_17_xtn_space
cmp r3 175
je x01_17_xtn_space
jmp x01_17_xtn_done
label x01_17_xtn_accent
add r0 1
cmp r0 r9
jge x01_17_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_17_xtn_a
cmp r3 161
je x01_17_xtn_a
cmp r3 137
je x01_17_xtn_e
cmp r3 169
je x01_17_xtn_e
cmp r3 141
je x01_17_xtn_i
cmp r3 173
je x01_17_xtn_i
cmp r3 147
je x01_17_xtn_o
cmp r3 179
je x01_17_xtn_o
cmp r3 154
je x01_17_xtn_u
cmp r3 186
je x01_17_xtn_u
cmp r3 145
je x01_17_xtn_n
cmp r3 177
je x01_17_xtn_n
jmp x01_17_xtn_done
label x01_17_xtn_a
set r3 97
jmp x01_17_xtn_append
label x01_17_xtn_e
set r3 101
jmp x01_17_xtn_append
label x01_17_xtn_i
set r3 105
jmp x01_17_xtn_append
label x01_17_xtn_o
set r3 111
jmp x01_17_xtn_append
label x01_17_xtn_u
set r3 117
jmp x01_17_xtn_append
label x01_17_xtn_n
set r3 110
jmp x01_17_xtn_append
label x01_17_xtn_space
cmp r1 0
je x01_17_xtn_next
set r2 1
jmp x01_17_xtn_next
label x01_17_xtn_append
cmp r2 0
je x01_17_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_17_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_17_xtn_next
add r0 1
jmp x01_17_xtn_each
label x01_17_xtn_valid
cmp r1 0
je x01_17_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_17_xtn_done
jmp x01_17_xt_normalized

label x01_lesson_18
store8 9050000000000000016 1
store8 9050000000000000017 4
store8 9050000000000000018 0
store8 9050000000000000019 12
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 109
store8 9050000000000000273 101
store8 9050000000000000274 32
store8 9050000000000000275 99
store8 9050000000000000276 111
store8 9050000000000000277 110
store8 9050000000000000278 102
store8 9050000000000000279 117
store8 9050000000000000280 110
store8 9050000000000000281 100
store8 9050000000000000282 101
store8 9050000000000000283 115
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_18_xt_blank
cmp r0 88
jne x01_18_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_18_xt_invalid
jmp x01_18_xt_validate
label x01_18_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_18_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_18_xt_invalid
add r0 1
cmp r0 16
jlt x01_18_xt_blank_header
set r0 32
label x01_18_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_18_xt_invalid
add r0 1
cmp r0 144
jlt x01_18_xt_blank_context
set r0 4096
label x01_18_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_18_xt_invalid
add r0 1
cmp r0 16384
jlt x01_18_xt_blank_bank
label x01_18_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_18_xt_invalid
cmp r0 0
je x01_18_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_18_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_18_xt_invalid
cmp r0 17
jgt x01_18_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_18_xt_invalid
label x01_18_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_18_xt_invalid
cmp r0 4
jgt x01_18_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_18_xt_invalid
cmp r0 1
jne x01_18_xt_modifier
cmp r1 1
jlt x01_18_xt_invalid
cmp r1 17
jgt x01_18_xt_invalid
jmp x01_18_xt_prepare
label x01_18_xt_modifier
cmp r1 0
jne x01_18_xt_invalid
cmp r2 0
jne x01_18_xt_invalid
label x01_18_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_18_xtn_begin
label x01_18_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_18_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_18_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_18_xt_invalid
set r10 0
label x01_18_xt_lookup
cmp r10 r6
jge x01_18_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_18_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_18_xt_next
set r0 0
label x01_18_xt_compare
cmp r0 r12
jge x01_18_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_18_xt_next
add r0 1
jmp x01_18_xt_compare
label x01_18_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_18_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_18_xt_correct
jmp x01_18_xt_clean
label x01_18_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_18_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_18_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_18_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_18_xt_clean
label x01_18_xt_next
add r10 1
jmp x01_18_xt_lookup
label x01_18_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_18_xt_invalid
cmp r6 128
jge x01_18_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_18_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_18_xt_invalid
add r0 1
cmp r0 96
jlt x01_18_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_18_xt_copy
cmp r0 r12
jge x01_18_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_18_xt_copy
label x01_18_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_18_xt_clean
set r0 16
label x01_18_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_18_xt_clean_mailbox
set r0 256
label x01_18_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_18_xt_clean_scratch
jmp x01_lesson_19
label x01_18_xt_invalid
div r0 0

label x01_18_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_18_xtn_done
cmp r9 255
jgt x01_18_xtn_done
label x01_18_xtn_each
cmp r0 r9
jge x01_18_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_18_xtn_inverted
cmp r3 195
je x01_18_xtn_accent
cmp r3 226
je x01_18_xtn_unicode_space
cmp r3 32
je x01_18_xtn_space
cmp r3 44
je x01_18_xtn_space
cmp r3 46
je x01_18_xtn_space
cmp r3 33
je x01_18_xtn_space
cmp r3 63
je x01_18_xtn_space
cmp r3 65
jlt x01_18_xtn_ascii
cmp r3 90
jgt x01_18_xtn_ascii
add r3 32
label x01_18_xtn_ascii
cmp r3 97
jlt x01_18_xtn_digit
cmp r3 122
jle x01_18_xtn_append
label x01_18_xtn_digit
cmp r3 48
jlt x01_18_xtn_done
cmp r3 57
jgt x01_18_xtn_done
jmp x01_18_xtn_append
label x01_18_xtn_inverted
add r0 1
cmp r0 r9
jge x01_18_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_18_xtn_space
cmp r3 191
je x01_18_xtn_space
cmp r3 161
je x01_18_xtn_space
jmp x01_18_xtn_done
label x01_18_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_18_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_18_xtn_done
add r0 1
cmp r0 r9
jge x01_18_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_18_xtn_space
cmp r3 175
je x01_18_xtn_space
jmp x01_18_xtn_done
label x01_18_xtn_accent
add r0 1
cmp r0 r9
jge x01_18_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_18_xtn_a
cmp r3 161
je x01_18_xtn_a
cmp r3 137
je x01_18_xtn_e
cmp r3 169
je x01_18_xtn_e
cmp r3 141
je x01_18_xtn_i
cmp r3 173
je x01_18_xtn_i
cmp r3 147
je x01_18_xtn_o
cmp r3 179
je x01_18_xtn_o
cmp r3 154
je x01_18_xtn_u
cmp r3 186
je x01_18_xtn_u
cmp r3 145
je x01_18_xtn_n
cmp r3 177
je x01_18_xtn_n
jmp x01_18_xtn_done
label x01_18_xtn_a
set r3 97
jmp x01_18_xtn_append
label x01_18_xtn_e
set r3 101
jmp x01_18_xtn_append
label x01_18_xtn_i
set r3 105
jmp x01_18_xtn_append
label x01_18_xtn_o
set r3 111
jmp x01_18_xtn_append
label x01_18_xtn_u
set r3 117
jmp x01_18_xtn_append
label x01_18_xtn_n
set r3 110
jmp x01_18_xtn_append
label x01_18_xtn_space
cmp r1 0
je x01_18_xtn_next
set r2 1
jmp x01_18_xtn_next
label x01_18_xtn_append
cmp r2 0
je x01_18_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_18_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_18_xtn_next
add r0 1
jmp x01_18_xtn_each
label x01_18_xtn_valid
cmp r1 0
je x01_18_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_18_xtn_done
jmp x01_18_xt_normalized

label x01_lesson_19
store8 9050000000000000016 1
store8 9050000000000000017 16
store8 9050000000000000018 1
store8 9050000000000000019 10
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 113
store8 9050000000000000273 117
store8 9050000000000000274 101
store8 9050000000000000275 32
store8 9050000000000000276 104
store8 9050000000000000277 99
store8 9050000000000000278 105
store8 9050000000000000279 115
store8 9050000000000000280 116
store8 9050000000000000281 101
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_19_xt_blank
cmp r0 88
jne x01_19_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_19_xt_invalid
jmp x01_19_xt_validate
label x01_19_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_19_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_19_xt_invalid
add r0 1
cmp r0 16
jlt x01_19_xt_blank_header
set r0 32
label x01_19_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_19_xt_invalid
add r0 1
cmp r0 144
jlt x01_19_xt_blank_context
set r0 4096
label x01_19_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_19_xt_invalid
add r0 1
cmp r0 16384
jlt x01_19_xt_blank_bank
label x01_19_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_19_xt_invalid
cmp r0 0
je x01_19_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_19_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_19_xt_invalid
cmp r0 17
jgt x01_19_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_19_xt_invalid
label x01_19_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_19_xt_invalid
cmp r0 4
jgt x01_19_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_19_xt_invalid
cmp r0 1
jne x01_19_xt_modifier
cmp r1 1
jlt x01_19_xt_invalid
cmp r1 17
jgt x01_19_xt_invalid
jmp x01_19_xt_prepare
label x01_19_xt_modifier
cmp r1 0
jne x01_19_xt_invalid
cmp r2 0
jne x01_19_xt_invalid
label x01_19_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_19_xtn_begin
label x01_19_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_19_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_19_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_19_xt_invalid
set r10 0
label x01_19_xt_lookup
cmp r10 r6
jge x01_19_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_19_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_19_xt_next
set r0 0
label x01_19_xt_compare
cmp r0 r12
jge x01_19_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_19_xt_next
add r0 1
jmp x01_19_xt_compare
label x01_19_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_19_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_19_xt_correct
jmp x01_19_xt_clean
label x01_19_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_19_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_19_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_19_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_19_xt_clean
label x01_19_xt_next
add r10 1
jmp x01_19_xt_lookup
label x01_19_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_19_xt_invalid
cmp r6 128
jge x01_19_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_19_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_19_xt_invalid
add r0 1
cmp r0 96
jlt x01_19_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_19_xt_copy
cmp r0 r12
jge x01_19_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_19_xt_copy
label x01_19_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_19_xt_clean
set r0 16
label x01_19_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_19_xt_clean_mailbox
set r0 256
label x01_19_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_19_xt_clean_scratch
jmp x01_lesson_20
label x01_19_xt_invalid
div r0 0

label x01_19_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_19_xtn_done
cmp r9 255
jgt x01_19_xtn_done
label x01_19_xtn_each
cmp r0 r9
jge x01_19_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_19_xtn_inverted
cmp r3 195
je x01_19_xtn_accent
cmp r3 226
je x01_19_xtn_unicode_space
cmp r3 32
je x01_19_xtn_space
cmp r3 44
je x01_19_xtn_space
cmp r3 46
je x01_19_xtn_space
cmp r3 33
je x01_19_xtn_space
cmp r3 63
je x01_19_xtn_space
cmp r3 65
jlt x01_19_xtn_ascii
cmp r3 90
jgt x01_19_xtn_ascii
add r3 32
label x01_19_xtn_ascii
cmp r3 97
jlt x01_19_xtn_digit
cmp r3 122
jle x01_19_xtn_append
label x01_19_xtn_digit
cmp r3 48
jlt x01_19_xtn_done
cmp r3 57
jgt x01_19_xtn_done
jmp x01_19_xtn_append
label x01_19_xtn_inverted
add r0 1
cmp r0 r9
jge x01_19_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_19_xtn_space
cmp r3 191
je x01_19_xtn_space
cmp r3 161
je x01_19_xtn_space
jmp x01_19_xtn_done
label x01_19_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_19_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_19_xtn_done
add r0 1
cmp r0 r9
jge x01_19_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_19_xtn_space
cmp r3 175
je x01_19_xtn_space
jmp x01_19_xtn_done
label x01_19_xtn_accent
add r0 1
cmp r0 r9
jge x01_19_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_19_xtn_a
cmp r3 161
je x01_19_xtn_a
cmp r3 137
je x01_19_xtn_e
cmp r3 169
je x01_19_xtn_e
cmp r3 141
je x01_19_xtn_i
cmp r3 173
je x01_19_xtn_i
cmp r3 147
je x01_19_xtn_o
cmp r3 179
je x01_19_xtn_o
cmp r3 154
je x01_19_xtn_u
cmp r3 186
je x01_19_xtn_u
cmp r3 145
je x01_19_xtn_n
cmp r3 177
je x01_19_xtn_n
jmp x01_19_xtn_done
label x01_19_xtn_a
set r3 97
jmp x01_19_xtn_append
label x01_19_xtn_e
set r3 101
jmp x01_19_xtn_append
label x01_19_xtn_i
set r3 105
jmp x01_19_xtn_append
label x01_19_xtn_o
set r3 111
jmp x01_19_xtn_append
label x01_19_xtn_u
set r3 117
jmp x01_19_xtn_append
label x01_19_xtn_n
set r3 110
jmp x01_19_xtn_append
label x01_19_xtn_space
cmp r1 0
je x01_19_xtn_next
set r2 1
jmp x01_19_xtn_next
label x01_19_xtn_append
cmp r2 0
je x01_19_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_19_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_19_xtn_next
add r0 1
jmp x01_19_xtn_each
label x01_19_xtn_valid
cmp r1 0
je x01_19_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_19_xtn_done
jmp x01_19_xt_normalized

label x01_lesson_20
store8 9050000000000000016 1
store8 9050000000000000017 16
store8 9050000000000000018 1
store8 9050000000000000019 13
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 121
store8 9050000000000000273 32
store8 9050000000000000274 113
store8 9050000000000000275 117
store8 9050000000000000276 101
store8 9050000000000000277 32
store8 9050000000000000278 102
store8 9050000000000000279 117
store8 9050000000000000280 101
store8 9050000000000000281 32
store8 9050000000000000282 101
store8 9050000000000000283 115
store8 9050000000000000284 111
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_20_xt_blank
cmp r0 88
jne x01_20_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_20_xt_invalid
jmp x01_20_xt_validate
label x01_20_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_20_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_20_xt_invalid
add r0 1
cmp r0 16
jlt x01_20_xt_blank_header
set r0 32
label x01_20_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_20_xt_invalid
add r0 1
cmp r0 144
jlt x01_20_xt_blank_context
set r0 4096
label x01_20_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_20_xt_invalid
add r0 1
cmp r0 16384
jlt x01_20_xt_blank_bank
label x01_20_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_20_xt_invalid
cmp r0 0
je x01_20_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_20_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_20_xt_invalid
cmp r0 17
jgt x01_20_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_20_xt_invalid
label x01_20_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_20_xt_invalid
cmp r0 4
jgt x01_20_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_20_xt_invalid
cmp r0 1
jne x01_20_xt_modifier
cmp r1 1
jlt x01_20_xt_invalid
cmp r1 17
jgt x01_20_xt_invalid
jmp x01_20_xt_prepare
label x01_20_xt_modifier
cmp r1 0
jne x01_20_xt_invalid
cmp r2 0
jne x01_20_xt_invalid
label x01_20_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_20_xtn_begin
label x01_20_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_20_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_20_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_20_xt_invalid
set r10 0
label x01_20_xt_lookup
cmp r10 r6
jge x01_20_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_20_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_20_xt_next
set r0 0
label x01_20_xt_compare
cmp r0 r12
jge x01_20_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_20_xt_next
add r0 1
jmp x01_20_xt_compare
label x01_20_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_20_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_20_xt_correct
jmp x01_20_xt_clean
label x01_20_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_20_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_20_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_20_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_20_xt_clean
label x01_20_xt_next
add r10 1
jmp x01_20_xt_lookup
label x01_20_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_20_xt_invalid
cmp r6 128
jge x01_20_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_20_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_20_xt_invalid
add r0 1
cmp r0 96
jlt x01_20_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_20_xt_copy
cmp r0 r12
jge x01_20_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_20_xt_copy
label x01_20_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_20_xt_clean
set r0 16
label x01_20_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_20_xt_clean_mailbox
set r0 256
label x01_20_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_20_xt_clean_scratch
jmp x01_lesson_21
label x01_20_xt_invalid
div r0 0

label x01_20_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_20_xtn_done
cmp r9 255
jgt x01_20_xtn_done
label x01_20_xtn_each
cmp r0 r9
jge x01_20_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_20_xtn_inverted
cmp r3 195
je x01_20_xtn_accent
cmp r3 226
je x01_20_xtn_unicode_space
cmp r3 32
je x01_20_xtn_space
cmp r3 44
je x01_20_xtn_space
cmp r3 46
je x01_20_xtn_space
cmp r3 33
je x01_20_xtn_space
cmp r3 63
je x01_20_xtn_space
cmp r3 65
jlt x01_20_xtn_ascii
cmp r3 90
jgt x01_20_xtn_ascii
add r3 32
label x01_20_xtn_ascii
cmp r3 97
jlt x01_20_xtn_digit
cmp r3 122
jle x01_20_xtn_append
label x01_20_xtn_digit
cmp r3 48
jlt x01_20_xtn_done
cmp r3 57
jgt x01_20_xtn_done
jmp x01_20_xtn_append
label x01_20_xtn_inverted
add r0 1
cmp r0 r9
jge x01_20_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_20_xtn_space
cmp r3 191
je x01_20_xtn_space
cmp r3 161
je x01_20_xtn_space
jmp x01_20_xtn_done
label x01_20_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_20_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_20_xtn_done
add r0 1
cmp r0 r9
jge x01_20_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_20_xtn_space
cmp r3 175
je x01_20_xtn_space
jmp x01_20_xtn_done
label x01_20_xtn_accent
add r0 1
cmp r0 r9
jge x01_20_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_20_xtn_a
cmp r3 161
je x01_20_xtn_a
cmp r3 137
je x01_20_xtn_e
cmp r3 169
je x01_20_xtn_e
cmp r3 141
je x01_20_xtn_i
cmp r3 173
je x01_20_xtn_i
cmp r3 147
je x01_20_xtn_o
cmp r3 179
je x01_20_xtn_o
cmp r3 154
je x01_20_xtn_u
cmp r3 186
je x01_20_xtn_u
cmp r3 145
je x01_20_xtn_n
cmp r3 177
je x01_20_xtn_n
jmp x01_20_xtn_done
label x01_20_xtn_a
set r3 97
jmp x01_20_xtn_append
label x01_20_xtn_e
set r3 101
jmp x01_20_xtn_append
label x01_20_xtn_i
set r3 105
jmp x01_20_xtn_append
label x01_20_xtn_o
set r3 111
jmp x01_20_xtn_append
label x01_20_xtn_u
set r3 117
jmp x01_20_xtn_append
label x01_20_xtn_n
set r3 110
jmp x01_20_xtn_append
label x01_20_xtn_space
cmp r1 0
je x01_20_xtn_next
set r2 1
jmp x01_20_xtn_next
label x01_20_xtn_append
cmp r2 0
je x01_20_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_20_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_20_xtn_next
add r0 1
jmp x01_20_xtn_each
label x01_20_xtn_valid
cmp r1 0
je x01_20_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_20_xtn_done
jmp x01_20_xt_normalized

label x01_lesson_21
store8 9050000000000000016 1
store8 9050000000000000017 16
store8 9050000000000000018 1
store8 9050000000000000019 13
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 121
store8 9050000000000000273 32
store8 9050000000000000274 113
store8 9050000000000000275 117
store8 9050000000000000276 101
store8 9050000000000000277 32
store8 9050000000000000278 115
store8 9050000000000000279 117
store8 9050000000000000280 99
store8 9050000000000000281 101
store8 9050000000000000282 100
store8 9050000000000000283 105
store8 9050000000000000284 111
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_21_xt_blank
cmp r0 88
jne x01_21_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_21_xt_invalid
jmp x01_21_xt_validate
label x01_21_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_21_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_21_xt_invalid
add r0 1
cmp r0 16
jlt x01_21_xt_blank_header
set r0 32
label x01_21_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_21_xt_invalid
add r0 1
cmp r0 144
jlt x01_21_xt_blank_context
set r0 4096
label x01_21_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_21_xt_invalid
add r0 1
cmp r0 16384
jlt x01_21_xt_blank_bank
label x01_21_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_21_xt_invalid
cmp r0 0
je x01_21_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_21_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_21_xt_invalid
cmp r0 17
jgt x01_21_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_21_xt_invalid
label x01_21_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_21_xt_invalid
cmp r0 4
jgt x01_21_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_21_xt_invalid
cmp r0 1
jne x01_21_xt_modifier
cmp r1 1
jlt x01_21_xt_invalid
cmp r1 17
jgt x01_21_xt_invalid
jmp x01_21_xt_prepare
label x01_21_xt_modifier
cmp r1 0
jne x01_21_xt_invalid
cmp r2 0
jne x01_21_xt_invalid
label x01_21_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_21_xtn_begin
label x01_21_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_21_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_21_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_21_xt_invalid
set r10 0
label x01_21_xt_lookup
cmp r10 r6
jge x01_21_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_21_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_21_xt_next
set r0 0
label x01_21_xt_compare
cmp r0 r12
jge x01_21_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_21_xt_next
add r0 1
jmp x01_21_xt_compare
label x01_21_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_21_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_21_xt_correct
jmp x01_21_xt_clean
label x01_21_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_21_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_21_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_21_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_21_xt_clean
label x01_21_xt_next
add r10 1
jmp x01_21_xt_lookup
label x01_21_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_21_xt_invalid
cmp r6 128
jge x01_21_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_21_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_21_xt_invalid
add r0 1
cmp r0 96
jlt x01_21_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_21_xt_copy
cmp r0 r12
jge x01_21_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_21_xt_copy
label x01_21_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_21_xt_clean
set r0 16
label x01_21_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_21_xt_clean_mailbox
set r0 256
label x01_21_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_21_xt_clean_scratch
jmp x01_lesson_22
label x01_21_xt_invalid
div r0 0

label x01_21_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_21_xtn_done
cmp r9 255
jgt x01_21_xtn_done
label x01_21_xtn_each
cmp r0 r9
jge x01_21_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_21_xtn_inverted
cmp r3 195
je x01_21_xtn_accent
cmp r3 226
je x01_21_xtn_unicode_space
cmp r3 32
je x01_21_xtn_space
cmp r3 44
je x01_21_xtn_space
cmp r3 46
je x01_21_xtn_space
cmp r3 33
je x01_21_xtn_space
cmp r3 63
je x01_21_xtn_space
cmp r3 65
jlt x01_21_xtn_ascii
cmp r3 90
jgt x01_21_xtn_ascii
add r3 32
label x01_21_xtn_ascii
cmp r3 97
jlt x01_21_xtn_digit
cmp r3 122
jle x01_21_xtn_append
label x01_21_xtn_digit
cmp r3 48
jlt x01_21_xtn_done
cmp r3 57
jgt x01_21_xtn_done
jmp x01_21_xtn_append
label x01_21_xtn_inverted
add r0 1
cmp r0 r9
jge x01_21_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_21_xtn_space
cmp r3 191
je x01_21_xtn_space
cmp r3 161
je x01_21_xtn_space
jmp x01_21_xtn_done
label x01_21_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_21_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_21_xtn_done
add r0 1
cmp r0 r9
jge x01_21_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_21_xtn_space
cmp r3 175
je x01_21_xtn_space
jmp x01_21_xtn_done
label x01_21_xtn_accent
add r0 1
cmp r0 r9
jge x01_21_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_21_xtn_a
cmp r3 161
je x01_21_xtn_a
cmp r3 137
je x01_21_xtn_e
cmp r3 169
je x01_21_xtn_e
cmp r3 141
je x01_21_xtn_i
cmp r3 173
je x01_21_xtn_i
cmp r3 147
je x01_21_xtn_o
cmp r3 179
je x01_21_xtn_o
cmp r3 154
je x01_21_xtn_u
cmp r3 186
je x01_21_xtn_u
cmp r3 145
je x01_21_xtn_n
cmp r3 177
je x01_21_xtn_n
jmp x01_21_xtn_done
label x01_21_xtn_a
set r3 97
jmp x01_21_xtn_append
label x01_21_xtn_e
set r3 101
jmp x01_21_xtn_append
label x01_21_xtn_i
set r3 105
jmp x01_21_xtn_append
label x01_21_xtn_o
set r3 111
jmp x01_21_xtn_append
label x01_21_xtn_u
set r3 117
jmp x01_21_xtn_append
label x01_21_xtn_n
set r3 110
jmp x01_21_xtn_append
label x01_21_xtn_space
cmp r1 0
je x01_21_xtn_next
set r2 1
jmp x01_21_xtn_next
label x01_21_xtn_append
cmp r2 0
je x01_21_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_21_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_21_xtn_next
add r0 1
jmp x01_21_xtn_each
label x01_21_xtn_valid
cmp r1 0
je x01_21_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_21_xtn_done
jmp x01_21_xt_normalized

label x01_lesson_22
store8 9050000000000000016 1
store8 9050000000000000017 5
store8 9050000000000000018 0
store8 9050000000000000019 6
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 101
store8 9050000000000000273 115
store8 9050000000000000274 112
store8 9050000000000000275 101
store8 9050000000000000276 114
store8 9050000000000000277 97
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_22_xt_blank
cmp r0 88
jne x01_22_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_22_xt_invalid
jmp x01_22_xt_validate
label x01_22_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_22_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_22_xt_invalid
add r0 1
cmp r0 16
jlt x01_22_xt_blank_header
set r0 32
label x01_22_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_22_xt_invalid
add r0 1
cmp r0 144
jlt x01_22_xt_blank_context
set r0 4096
label x01_22_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_22_xt_invalid
add r0 1
cmp r0 16384
jlt x01_22_xt_blank_bank
label x01_22_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_22_xt_invalid
cmp r0 0
je x01_22_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_22_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_22_xt_invalid
cmp r0 17
jgt x01_22_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_22_xt_invalid
label x01_22_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_22_xt_invalid
cmp r0 4
jgt x01_22_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_22_xt_invalid
cmp r0 1
jne x01_22_xt_modifier
cmp r1 1
jlt x01_22_xt_invalid
cmp r1 17
jgt x01_22_xt_invalid
jmp x01_22_xt_prepare
label x01_22_xt_modifier
cmp r1 0
jne x01_22_xt_invalid
cmp r2 0
jne x01_22_xt_invalid
label x01_22_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_22_xtn_begin
label x01_22_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_22_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_22_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_22_xt_invalid
set r10 0
label x01_22_xt_lookup
cmp r10 r6
jge x01_22_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_22_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_22_xt_next
set r0 0
label x01_22_xt_compare
cmp r0 r12
jge x01_22_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_22_xt_next
add r0 1
jmp x01_22_xt_compare
label x01_22_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_22_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_22_xt_correct
jmp x01_22_xt_clean
label x01_22_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_22_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_22_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_22_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_22_xt_clean
label x01_22_xt_next
add r10 1
jmp x01_22_xt_lookup
label x01_22_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_22_xt_invalid
cmp r6 128
jge x01_22_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_22_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_22_xt_invalid
add r0 1
cmp r0 96
jlt x01_22_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_22_xt_copy
cmp r0 r12
jge x01_22_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_22_xt_copy
label x01_22_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_22_xt_clean
set r0 16
label x01_22_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_22_xt_clean_mailbox
set r0 256
label x01_22_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_22_xt_clean_scratch
jmp x01_lesson_23
label x01_22_xt_invalid
div r0 0

label x01_22_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_22_xtn_done
cmp r9 255
jgt x01_22_xtn_done
label x01_22_xtn_each
cmp r0 r9
jge x01_22_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_22_xtn_inverted
cmp r3 195
je x01_22_xtn_accent
cmp r3 226
je x01_22_xtn_unicode_space
cmp r3 32
je x01_22_xtn_space
cmp r3 44
je x01_22_xtn_space
cmp r3 46
je x01_22_xtn_space
cmp r3 33
je x01_22_xtn_space
cmp r3 63
je x01_22_xtn_space
cmp r3 65
jlt x01_22_xtn_ascii
cmp r3 90
jgt x01_22_xtn_ascii
add r3 32
label x01_22_xtn_ascii
cmp r3 97
jlt x01_22_xtn_digit
cmp r3 122
jle x01_22_xtn_append
label x01_22_xtn_digit
cmp r3 48
jlt x01_22_xtn_done
cmp r3 57
jgt x01_22_xtn_done
jmp x01_22_xtn_append
label x01_22_xtn_inverted
add r0 1
cmp r0 r9
jge x01_22_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_22_xtn_space
cmp r3 191
je x01_22_xtn_space
cmp r3 161
je x01_22_xtn_space
jmp x01_22_xtn_done
label x01_22_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_22_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_22_xtn_done
add r0 1
cmp r0 r9
jge x01_22_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_22_xtn_space
cmp r3 175
je x01_22_xtn_space
jmp x01_22_xtn_done
label x01_22_xtn_accent
add r0 1
cmp r0 r9
jge x01_22_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_22_xtn_a
cmp r3 161
je x01_22_xtn_a
cmp r3 137
je x01_22_xtn_e
cmp r3 169
je x01_22_xtn_e
cmp r3 141
je x01_22_xtn_i
cmp r3 173
je x01_22_xtn_i
cmp r3 147
je x01_22_xtn_o
cmp r3 179
je x01_22_xtn_o
cmp r3 154
je x01_22_xtn_u
cmp r3 186
je x01_22_xtn_u
cmp r3 145
je x01_22_xtn_n
cmp r3 177
je x01_22_xtn_n
jmp x01_22_xtn_done
label x01_22_xtn_a
set r3 97
jmp x01_22_xtn_append
label x01_22_xtn_e
set r3 101
jmp x01_22_xtn_append
label x01_22_xtn_i
set r3 105
jmp x01_22_xtn_append
label x01_22_xtn_o
set r3 111
jmp x01_22_xtn_append
label x01_22_xtn_u
set r3 117
jmp x01_22_xtn_append
label x01_22_xtn_n
set r3 110
jmp x01_22_xtn_append
label x01_22_xtn_space
cmp r1 0
je x01_22_xtn_next
set r2 1
jmp x01_22_xtn_next
label x01_22_xtn_append
cmp r2 0
je x01_22_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_22_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_22_xtn_next
add r0 1
jmp x01_22_xtn_each
label x01_22_xtn_valid
cmp r1 0
je x01_22_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_22_xtn_done
jmp x01_22_xt_normalized

label x01_lesson_23
store8 9050000000000000016 1
store8 9050000000000000017 5
store8 9050000000000000018 0
store8 9050000000000000019 13
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 110
store8 9050000000000000273 111
store8 9050000000000000274 32
store8 9050000000000000275 104
store8 9050000000000000276 97
store8 9050000000000000277 103
store8 9050000000000000278 97
store8 9050000000000000279 115
store8 9050000000000000280 32
store8 9050000000000000281 110
store8 9050000000000000282 97
store8 9050000000000000283 100
store8 9050000000000000284 97
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_23_xt_blank
cmp r0 88
jne x01_23_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_23_xt_invalid
jmp x01_23_xt_validate
label x01_23_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_23_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_23_xt_invalid
add r0 1
cmp r0 16
jlt x01_23_xt_blank_header
set r0 32
label x01_23_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_23_xt_invalid
add r0 1
cmp r0 144
jlt x01_23_xt_blank_context
set r0 4096
label x01_23_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_23_xt_invalid
add r0 1
cmp r0 16384
jlt x01_23_xt_blank_bank
label x01_23_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_23_xt_invalid
cmp r0 0
je x01_23_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_23_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_23_xt_invalid
cmp r0 17
jgt x01_23_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_23_xt_invalid
label x01_23_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_23_xt_invalid
cmp r0 4
jgt x01_23_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_23_xt_invalid
cmp r0 1
jne x01_23_xt_modifier
cmp r1 1
jlt x01_23_xt_invalid
cmp r1 17
jgt x01_23_xt_invalid
jmp x01_23_xt_prepare
label x01_23_xt_modifier
cmp r1 0
jne x01_23_xt_invalid
cmp r2 0
jne x01_23_xt_invalid
label x01_23_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_23_xtn_begin
label x01_23_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_23_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_23_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_23_xt_invalid
set r10 0
label x01_23_xt_lookup
cmp r10 r6
jge x01_23_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_23_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_23_xt_next
set r0 0
label x01_23_xt_compare
cmp r0 r12
jge x01_23_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_23_xt_next
add r0 1
jmp x01_23_xt_compare
label x01_23_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_23_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_23_xt_correct
jmp x01_23_xt_clean
label x01_23_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_23_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_23_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_23_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_23_xt_clean
label x01_23_xt_next
add r10 1
jmp x01_23_xt_lookup
label x01_23_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_23_xt_invalid
cmp r6 128
jge x01_23_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_23_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_23_xt_invalid
add r0 1
cmp r0 96
jlt x01_23_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_23_xt_copy
cmp r0 r12
jge x01_23_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_23_xt_copy
label x01_23_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_23_xt_clean
set r0 16
label x01_23_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_23_xt_clean_mailbox
set r0 256
label x01_23_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_23_xt_clean_scratch
jmp x01_lesson_24
label x01_23_xt_invalid
div r0 0

label x01_23_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_23_xtn_done
cmp r9 255
jgt x01_23_xtn_done
label x01_23_xtn_each
cmp r0 r9
jge x01_23_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_23_xtn_inverted
cmp r3 195
je x01_23_xtn_accent
cmp r3 226
je x01_23_xtn_unicode_space
cmp r3 32
je x01_23_xtn_space
cmp r3 44
je x01_23_xtn_space
cmp r3 46
je x01_23_xtn_space
cmp r3 33
je x01_23_xtn_space
cmp r3 63
je x01_23_xtn_space
cmp r3 65
jlt x01_23_xtn_ascii
cmp r3 90
jgt x01_23_xtn_ascii
add r3 32
label x01_23_xtn_ascii
cmp r3 97
jlt x01_23_xtn_digit
cmp r3 122
jle x01_23_xtn_append
label x01_23_xtn_digit
cmp r3 48
jlt x01_23_xtn_done
cmp r3 57
jgt x01_23_xtn_done
jmp x01_23_xtn_append
label x01_23_xtn_inverted
add r0 1
cmp r0 r9
jge x01_23_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_23_xtn_space
cmp r3 191
je x01_23_xtn_space
cmp r3 161
je x01_23_xtn_space
jmp x01_23_xtn_done
label x01_23_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_23_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_23_xtn_done
add r0 1
cmp r0 r9
jge x01_23_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_23_xtn_space
cmp r3 175
je x01_23_xtn_space
jmp x01_23_xtn_done
label x01_23_xtn_accent
add r0 1
cmp r0 r9
jge x01_23_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_23_xtn_a
cmp r3 161
je x01_23_xtn_a
cmp r3 137
je x01_23_xtn_e
cmp r3 169
je x01_23_xtn_e
cmp r3 141
je x01_23_xtn_i
cmp r3 173
je x01_23_xtn_i
cmp r3 147
je x01_23_xtn_o
cmp r3 179
je x01_23_xtn_o
cmp r3 154
je x01_23_xtn_u
cmp r3 186
je x01_23_xtn_u
cmp r3 145
je x01_23_xtn_n
cmp r3 177
je x01_23_xtn_n
jmp x01_23_xtn_done
label x01_23_xtn_a
set r3 97
jmp x01_23_xtn_append
label x01_23_xtn_e
set r3 101
jmp x01_23_xtn_append
label x01_23_xtn_i
set r3 105
jmp x01_23_xtn_append
label x01_23_xtn_o
set r3 111
jmp x01_23_xtn_append
label x01_23_xtn_u
set r3 117
jmp x01_23_xtn_append
label x01_23_xtn_n
set r3 110
jmp x01_23_xtn_append
label x01_23_xtn_space
cmp r1 0
je x01_23_xtn_next
set r2 1
jmp x01_23_xtn_next
label x01_23_xtn_append
cmp r2 0
je x01_23_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_23_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_23_xtn_next
add r0 1
jmp x01_23_xtn_each
label x01_23_xtn_valid
cmp r1 0
je x01_23_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_23_xtn_done
jmp x01_23_xt_normalized

label x01_lesson_24
store8 9050000000000000016 1
store8 9050000000000000017 6
store8 9050000000000000018 1
store8 9050000000000000019 9
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 115
store8 9050000000000000273 111
store8 9050000000000000274 108
store8 9050000000000000275 111
store8 9050000000000000276 32
store8 9050000000000000277 100
store8 9050000000000000278 105
store8 9050000000000000279 109
store8 9050000000000000280 101
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_24_xt_blank
cmp r0 88
jne x01_24_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_24_xt_invalid
jmp x01_24_xt_validate
label x01_24_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_24_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_24_xt_invalid
add r0 1
cmp r0 16
jlt x01_24_xt_blank_header
set r0 32
label x01_24_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_24_xt_invalid
add r0 1
cmp r0 144
jlt x01_24_xt_blank_context
set r0 4096
label x01_24_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_24_xt_invalid
add r0 1
cmp r0 16384
jlt x01_24_xt_blank_bank
label x01_24_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_24_xt_invalid
cmp r0 0
je x01_24_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_24_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_24_xt_invalid
cmp r0 17
jgt x01_24_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_24_xt_invalid
label x01_24_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_24_xt_invalid
cmp r0 4
jgt x01_24_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_24_xt_invalid
cmp r0 1
jne x01_24_xt_modifier
cmp r1 1
jlt x01_24_xt_invalid
cmp r1 17
jgt x01_24_xt_invalid
jmp x01_24_xt_prepare
label x01_24_xt_modifier
cmp r1 0
jne x01_24_xt_invalid
cmp r2 0
jne x01_24_xt_invalid
label x01_24_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_24_xtn_begin
label x01_24_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_24_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_24_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_24_xt_invalid
set r10 0
label x01_24_xt_lookup
cmp r10 r6
jge x01_24_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_24_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_24_xt_next
set r0 0
label x01_24_xt_compare
cmp r0 r12
jge x01_24_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_24_xt_next
add r0 1
jmp x01_24_xt_compare
label x01_24_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_24_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_24_xt_correct
jmp x01_24_xt_clean
label x01_24_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_24_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_24_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_24_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_24_xt_clean
label x01_24_xt_next
add r10 1
jmp x01_24_xt_lookup
label x01_24_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_24_xt_invalid
cmp r6 128
jge x01_24_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_24_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_24_xt_invalid
add r0 1
cmp r0 96
jlt x01_24_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_24_xt_copy
cmp r0 r12
jge x01_24_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_24_xt_copy
label x01_24_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_24_xt_clean
set r0 16
label x01_24_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_24_xt_clean_mailbox
set r0 256
label x01_24_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_24_xt_clean_scratch
jmp x01_lesson_25
label x01_24_xt_invalid
div r0 0

label x01_24_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_24_xtn_done
cmp r9 255
jgt x01_24_xtn_done
label x01_24_xtn_each
cmp r0 r9
jge x01_24_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_24_xtn_inverted
cmp r3 195
je x01_24_xtn_accent
cmp r3 226
je x01_24_xtn_unicode_space
cmp r3 32
je x01_24_xtn_space
cmp r3 44
je x01_24_xtn_space
cmp r3 46
je x01_24_xtn_space
cmp r3 33
je x01_24_xtn_space
cmp r3 63
je x01_24_xtn_space
cmp r3 65
jlt x01_24_xtn_ascii
cmp r3 90
jgt x01_24_xtn_ascii
add r3 32
label x01_24_xtn_ascii
cmp r3 97
jlt x01_24_xtn_digit
cmp r3 122
jle x01_24_xtn_append
label x01_24_xtn_digit
cmp r3 48
jlt x01_24_xtn_done
cmp r3 57
jgt x01_24_xtn_done
jmp x01_24_xtn_append
label x01_24_xtn_inverted
add r0 1
cmp r0 r9
jge x01_24_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_24_xtn_space
cmp r3 191
je x01_24_xtn_space
cmp r3 161
je x01_24_xtn_space
jmp x01_24_xtn_done
label x01_24_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_24_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_24_xtn_done
add r0 1
cmp r0 r9
jge x01_24_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_24_xtn_space
cmp r3 175
je x01_24_xtn_space
jmp x01_24_xtn_done
label x01_24_xtn_accent
add r0 1
cmp r0 r9
jge x01_24_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_24_xtn_a
cmp r3 161
je x01_24_xtn_a
cmp r3 137
je x01_24_xtn_e
cmp r3 169
je x01_24_xtn_e
cmp r3 141
je x01_24_xtn_i
cmp r3 173
je x01_24_xtn_i
cmp r3 147
je x01_24_xtn_o
cmp r3 179
je x01_24_xtn_o
cmp r3 154
je x01_24_xtn_u
cmp r3 186
je x01_24_xtn_u
cmp r3 145
je x01_24_xtn_n
cmp r3 177
je x01_24_xtn_n
jmp x01_24_xtn_done
label x01_24_xtn_a
set r3 97
jmp x01_24_xtn_append
label x01_24_xtn_e
set r3 101
jmp x01_24_xtn_append
label x01_24_xtn_i
set r3 105
jmp x01_24_xtn_append
label x01_24_xtn_o
set r3 111
jmp x01_24_xtn_append
label x01_24_xtn_u
set r3 117
jmp x01_24_xtn_append
label x01_24_xtn_n
set r3 110
jmp x01_24_xtn_append
label x01_24_xtn_space
cmp r1 0
je x01_24_xtn_next
set r2 1
jmp x01_24_xtn_next
label x01_24_xtn_append
cmp r2 0
je x01_24_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_24_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_24_xtn_next
add r0 1
jmp x01_24_xtn_each
label x01_24_xtn_valid
cmp r1 0
je x01_24_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_24_xtn_done
jmp x01_24_xt_normalized

label x01_lesson_25
store8 9050000000000000016 1
store8 9050000000000000017 6
store8 9050000000000000018 1
store8 9050000000000000019 23
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 110
store8 9050000000000000273 111
store8 9050000000000000274 32
store8 9050000000000000275 104
store8 9050000000000000276 97
store8 9050000000000000277 103
store8 9050000000000000278 97
store8 9050000000000000279 115
store8 9050000000000000280 32
store8 9050000000000000281 110
store8 9050000000000000282 97
store8 9050000000000000283 100
store8 9050000000000000284 97
store8 9050000000000000285 32
store8 9050000000000000286 115
store8 9050000000000000287 111
store8 9050000000000000288 108
store8 9050000000000000289 111
store8 9050000000000000290 32
store8 9050000000000000291 100
store8 9050000000000000292 105
store8 9050000000000000293 109
store8 9050000000000000294 101
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_25_xt_blank
cmp r0 88
jne x01_25_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_25_xt_invalid
jmp x01_25_xt_validate
label x01_25_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_25_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_25_xt_invalid
add r0 1
cmp r0 16
jlt x01_25_xt_blank_header
set r0 32
label x01_25_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_25_xt_invalid
add r0 1
cmp r0 144
jlt x01_25_xt_blank_context
set r0 4096
label x01_25_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_25_xt_invalid
add r0 1
cmp r0 16384
jlt x01_25_xt_blank_bank
label x01_25_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_25_xt_invalid
cmp r0 0
je x01_25_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_25_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_25_xt_invalid
cmp r0 17
jgt x01_25_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_25_xt_invalid
label x01_25_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_25_xt_invalid
cmp r0 4
jgt x01_25_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_25_xt_invalid
cmp r0 1
jne x01_25_xt_modifier
cmp r1 1
jlt x01_25_xt_invalid
cmp r1 17
jgt x01_25_xt_invalid
jmp x01_25_xt_prepare
label x01_25_xt_modifier
cmp r1 0
jne x01_25_xt_invalid
cmp r2 0
jne x01_25_xt_invalid
label x01_25_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_25_xtn_begin
label x01_25_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_25_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_25_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_25_xt_invalid
set r10 0
label x01_25_xt_lookup
cmp r10 r6
jge x01_25_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_25_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_25_xt_next
set r0 0
label x01_25_xt_compare
cmp r0 r12
jge x01_25_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_25_xt_next
add r0 1
jmp x01_25_xt_compare
label x01_25_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_25_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_25_xt_correct
jmp x01_25_xt_clean
label x01_25_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_25_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_25_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_25_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_25_xt_clean
label x01_25_xt_next
add r10 1
jmp x01_25_xt_lookup
label x01_25_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_25_xt_invalid
cmp r6 128
jge x01_25_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_25_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_25_xt_invalid
add r0 1
cmp r0 96
jlt x01_25_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_25_xt_copy
cmp r0 r12
jge x01_25_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_25_xt_copy
label x01_25_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_25_xt_clean
set r0 16
label x01_25_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_25_xt_clean_mailbox
set r0 256
label x01_25_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_25_xt_clean_scratch
jmp x01_lesson_26
label x01_25_xt_invalid
div r0 0

label x01_25_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_25_xtn_done
cmp r9 255
jgt x01_25_xtn_done
label x01_25_xtn_each
cmp r0 r9
jge x01_25_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_25_xtn_inverted
cmp r3 195
je x01_25_xtn_accent
cmp r3 226
je x01_25_xtn_unicode_space
cmp r3 32
je x01_25_xtn_space
cmp r3 44
je x01_25_xtn_space
cmp r3 46
je x01_25_xtn_space
cmp r3 33
je x01_25_xtn_space
cmp r3 63
je x01_25_xtn_space
cmp r3 65
jlt x01_25_xtn_ascii
cmp r3 90
jgt x01_25_xtn_ascii
add r3 32
label x01_25_xtn_ascii
cmp r3 97
jlt x01_25_xtn_digit
cmp r3 122
jle x01_25_xtn_append
label x01_25_xtn_digit
cmp r3 48
jlt x01_25_xtn_done
cmp r3 57
jgt x01_25_xtn_done
jmp x01_25_xtn_append
label x01_25_xtn_inverted
add r0 1
cmp r0 r9
jge x01_25_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_25_xtn_space
cmp r3 191
je x01_25_xtn_space
cmp r3 161
je x01_25_xtn_space
jmp x01_25_xtn_done
label x01_25_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_25_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_25_xtn_done
add r0 1
cmp r0 r9
jge x01_25_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_25_xtn_space
cmp r3 175
je x01_25_xtn_space
jmp x01_25_xtn_done
label x01_25_xtn_accent
add r0 1
cmp r0 r9
jge x01_25_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_25_xtn_a
cmp r3 161
je x01_25_xtn_a
cmp r3 137
je x01_25_xtn_e
cmp r3 169
je x01_25_xtn_e
cmp r3 141
je x01_25_xtn_i
cmp r3 173
je x01_25_xtn_i
cmp r3 147
je x01_25_xtn_o
cmp r3 179
je x01_25_xtn_o
cmp r3 154
je x01_25_xtn_u
cmp r3 186
je x01_25_xtn_u
cmp r3 145
je x01_25_xtn_n
cmp r3 177
je x01_25_xtn_n
jmp x01_25_xtn_done
label x01_25_xtn_a
set r3 97
jmp x01_25_xtn_append
label x01_25_xtn_e
set r3 101
jmp x01_25_xtn_append
label x01_25_xtn_i
set r3 105
jmp x01_25_xtn_append
label x01_25_xtn_o
set r3 111
jmp x01_25_xtn_append
label x01_25_xtn_u
set r3 117
jmp x01_25_xtn_append
label x01_25_xtn_n
set r3 110
jmp x01_25_xtn_append
label x01_25_xtn_space
cmp r1 0
je x01_25_xtn_next
set r2 1
jmp x01_25_xtn_next
label x01_25_xtn_append
cmp r2 0
je x01_25_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_25_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_25_xtn_next
add r0 1
jmp x01_25_xtn_each
label x01_25_xtn_valid
cmp r1 0
je x01_25_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_25_xtn_done
jmp x01_25_xt_normalized

label x01_lesson_26
store8 9050000000000000016 1
store8 9050000000000000017 7
store8 9050000000000000018 1
store8 9050000000000000019 45
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 115
store8 9050000000000000273 105
store8 9050000000000000274 110
store8 9050000000000000275 32
store8 9050000000000000276 101
store8 9050000000000000277 106
store8 9050000000000000278 101
store8 9050000000000000279 99
store8 9050000000000000280 117
store8 9050000000000000281 116
store8 9050000000000000282 97
store8 9050000000000000283 114
store8 9050000000000000284 32
store8 9050000000000000285 110
store8 9050000000000000286 97
store8 9050000000000000287 100
store8 9050000000000000288 97
store8 9050000000000000289 32
store8 9050000000000000290 97
store8 9050000000000000291 110
store8 9050000000000000292 116
store8 9050000000000000293 101
store8 9050000000000000294 115
store8 9050000000000000295 32
store8 9050000000000000296 100
store8 9050000000000000297 101
store8 9050000000000000298 32
store8 9050000000000000299 100
store8 9050000000000000300 101
store8 9050000000000000301 99
store8 9050000000000000302 105
store8 9050000000000000303 114
store8 9050000000000000304 109
store8 9050000000000000305 101
store8 9050000000000000306 108
store8 9050000000000000307 111
store8 9050000000000000308 32
store8 9050000000000000309 101
store8 9050000000000000310 110
store8 9050000000000000311 32
store8 9050000000000000312 116
store8 9050000000000000313 101
store8 9050000000000000314 120
store8 9050000000000000315 116
store8 9050000000000000316 111
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_26_xt_blank
cmp r0 88
jne x01_26_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_26_xt_invalid
jmp x01_26_xt_validate
label x01_26_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_26_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_26_xt_invalid
add r0 1
cmp r0 16
jlt x01_26_xt_blank_header
set r0 32
label x01_26_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_26_xt_invalid
add r0 1
cmp r0 144
jlt x01_26_xt_blank_context
set r0 4096
label x01_26_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_26_xt_invalid
add r0 1
cmp r0 16384
jlt x01_26_xt_blank_bank
label x01_26_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_26_xt_invalid
cmp r0 0
je x01_26_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_26_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_26_xt_invalid
cmp r0 17
jgt x01_26_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_26_xt_invalid
label x01_26_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_26_xt_invalid
cmp r0 4
jgt x01_26_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_26_xt_invalid
cmp r0 1
jne x01_26_xt_modifier
cmp r1 1
jlt x01_26_xt_invalid
cmp r1 17
jgt x01_26_xt_invalid
jmp x01_26_xt_prepare
label x01_26_xt_modifier
cmp r1 0
jne x01_26_xt_invalid
cmp r2 0
jne x01_26_xt_invalid
label x01_26_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_26_xtn_begin
label x01_26_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_26_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_26_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_26_xt_invalid
set r10 0
label x01_26_xt_lookup
cmp r10 r6
jge x01_26_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_26_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_26_xt_next
set r0 0
label x01_26_xt_compare
cmp r0 r12
jge x01_26_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_26_xt_next
add r0 1
jmp x01_26_xt_compare
label x01_26_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_26_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_26_xt_correct
jmp x01_26_xt_clean
label x01_26_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_26_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_26_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_26_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_26_xt_clean
label x01_26_xt_next
add r10 1
jmp x01_26_xt_lookup
label x01_26_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_26_xt_invalid
cmp r6 128
jge x01_26_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_26_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_26_xt_invalid
add r0 1
cmp r0 96
jlt x01_26_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_26_xt_copy
cmp r0 r12
jge x01_26_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_26_xt_copy
label x01_26_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_26_xt_clean
set r0 16
label x01_26_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_26_xt_clean_mailbox
set r0 256
label x01_26_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_26_xt_clean_scratch
jmp x01_lesson_27
label x01_26_xt_invalid
div r0 0

label x01_26_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_26_xtn_done
cmp r9 255
jgt x01_26_xtn_done
label x01_26_xtn_each
cmp r0 r9
jge x01_26_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_26_xtn_inverted
cmp r3 195
je x01_26_xtn_accent
cmp r3 226
je x01_26_xtn_unicode_space
cmp r3 32
je x01_26_xtn_space
cmp r3 44
je x01_26_xtn_space
cmp r3 46
je x01_26_xtn_space
cmp r3 33
je x01_26_xtn_space
cmp r3 63
je x01_26_xtn_space
cmp r3 65
jlt x01_26_xtn_ascii
cmp r3 90
jgt x01_26_xtn_ascii
add r3 32
label x01_26_xtn_ascii
cmp r3 97
jlt x01_26_xtn_digit
cmp r3 122
jle x01_26_xtn_append
label x01_26_xtn_digit
cmp r3 48
jlt x01_26_xtn_done
cmp r3 57
jgt x01_26_xtn_done
jmp x01_26_xtn_append
label x01_26_xtn_inverted
add r0 1
cmp r0 r9
jge x01_26_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_26_xtn_space
cmp r3 191
je x01_26_xtn_space
cmp r3 161
je x01_26_xtn_space
jmp x01_26_xtn_done
label x01_26_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_26_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_26_xtn_done
add r0 1
cmp r0 r9
jge x01_26_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_26_xtn_space
cmp r3 175
je x01_26_xtn_space
jmp x01_26_xtn_done
label x01_26_xtn_accent
add r0 1
cmp r0 r9
jge x01_26_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_26_xtn_a
cmp r3 161
je x01_26_xtn_a
cmp r3 137
je x01_26_xtn_e
cmp r3 169
je x01_26_xtn_e
cmp r3 141
je x01_26_xtn_i
cmp r3 173
je x01_26_xtn_i
cmp r3 147
je x01_26_xtn_o
cmp r3 179
je x01_26_xtn_o
cmp r3 154
je x01_26_xtn_u
cmp r3 186
je x01_26_xtn_u
cmp r3 145
je x01_26_xtn_n
cmp r3 177
je x01_26_xtn_n
jmp x01_26_xtn_done
label x01_26_xtn_a
set r3 97
jmp x01_26_xtn_append
label x01_26_xtn_e
set r3 101
jmp x01_26_xtn_append
label x01_26_xtn_i
set r3 105
jmp x01_26_xtn_append
label x01_26_xtn_o
set r3 111
jmp x01_26_xtn_append
label x01_26_xtn_u
set r3 117
jmp x01_26_xtn_append
label x01_26_xtn_n
set r3 110
jmp x01_26_xtn_append
label x01_26_xtn_space
cmp r1 0
je x01_26_xtn_next
set r2 1
jmp x01_26_xtn_next
label x01_26_xtn_append
cmp r2 0
je x01_26_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_26_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_26_xtn_next
add r0 1
jmp x01_26_xtn_each
label x01_26_xtn_valid
cmp r1 0
je x01_26_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_26_xtn_done
jmp x01_26_xt_normalized

label x01_lesson_27
store8 9050000000000000016 1
store8 9050000000000000017 8
store8 9050000000000000018 1
store8 9050000000000000019 21
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 117
store8 9050000000000000273 115
store8 9050000000000000274 97
store8 9050000000000000275 32
store8 9050000000000000276 109
store8 9050000000000000277 105
store8 9050000000000000278 32
store8 9050000000000000279 116
store8 9050000000000000280 101
store8 9050000000000000281 99
store8 9050000000000000282 110
store8 9050000000000000283 111
store8 9050000000000000284 108
store8 9050000000000000285 111
store8 9050000000000000286 103
store8 9050000000000000287 195
store8 9050000000000000288 173
store8 9050000000000000289 97
store8 9050000000000000290 32
store8 9050000000000000291 110
store8 9050000000000000292 111
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_27_xt_blank
cmp r0 88
jne x01_27_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_27_xt_invalid
jmp x01_27_xt_validate
label x01_27_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_27_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_27_xt_invalid
add r0 1
cmp r0 16
jlt x01_27_xt_blank_header
set r0 32
label x01_27_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_27_xt_invalid
add r0 1
cmp r0 144
jlt x01_27_xt_blank_context
set r0 4096
label x01_27_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_27_xt_invalid
add r0 1
cmp r0 16384
jlt x01_27_xt_blank_bank
label x01_27_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_27_xt_invalid
cmp r0 0
je x01_27_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_27_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_27_xt_invalid
cmp r0 17
jgt x01_27_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_27_xt_invalid
label x01_27_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_27_xt_invalid
cmp r0 4
jgt x01_27_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_27_xt_invalid
cmp r0 1
jne x01_27_xt_modifier
cmp r1 1
jlt x01_27_xt_invalid
cmp r1 17
jgt x01_27_xt_invalid
jmp x01_27_xt_prepare
label x01_27_xt_modifier
cmp r1 0
jne x01_27_xt_invalid
cmp r2 0
jne x01_27_xt_invalid
label x01_27_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_27_xtn_begin
label x01_27_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_27_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_27_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_27_xt_invalid
set r10 0
label x01_27_xt_lookup
cmp r10 r6
jge x01_27_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_27_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_27_xt_next
set r0 0
label x01_27_xt_compare
cmp r0 r12
jge x01_27_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_27_xt_next
add r0 1
jmp x01_27_xt_compare
label x01_27_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_27_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_27_xt_correct
jmp x01_27_xt_clean
label x01_27_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_27_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_27_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_27_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_27_xt_clean
label x01_27_xt_next
add r10 1
jmp x01_27_xt_lookup
label x01_27_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_27_xt_invalid
cmp r6 128
jge x01_27_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_27_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_27_xt_invalid
add r0 1
cmp r0 96
jlt x01_27_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_27_xt_copy
cmp r0 r12
jge x01_27_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_27_xt_copy
label x01_27_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_27_xt_clean
set r0 16
label x01_27_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_27_xt_clean_mailbox
set r0 256
label x01_27_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_27_xt_clean_scratch
jmp x01_lesson_28
label x01_27_xt_invalid
div r0 0

label x01_27_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_27_xtn_done
cmp r9 255
jgt x01_27_xtn_done
label x01_27_xtn_each
cmp r0 r9
jge x01_27_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_27_xtn_inverted
cmp r3 195
je x01_27_xtn_accent
cmp r3 226
je x01_27_xtn_unicode_space
cmp r3 32
je x01_27_xtn_space
cmp r3 44
je x01_27_xtn_space
cmp r3 46
je x01_27_xtn_space
cmp r3 33
je x01_27_xtn_space
cmp r3 63
je x01_27_xtn_space
cmp r3 65
jlt x01_27_xtn_ascii
cmp r3 90
jgt x01_27_xtn_ascii
add r3 32
label x01_27_xtn_ascii
cmp r3 97
jlt x01_27_xtn_digit
cmp r3 122
jle x01_27_xtn_append
label x01_27_xtn_digit
cmp r3 48
jlt x01_27_xtn_done
cmp r3 57
jgt x01_27_xtn_done
jmp x01_27_xtn_append
label x01_27_xtn_inverted
add r0 1
cmp r0 r9
jge x01_27_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_27_xtn_space
cmp r3 191
je x01_27_xtn_space
cmp r3 161
je x01_27_xtn_space
jmp x01_27_xtn_done
label x01_27_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_27_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_27_xtn_done
add r0 1
cmp r0 r9
jge x01_27_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_27_xtn_space
cmp r3 175
je x01_27_xtn_space
jmp x01_27_xtn_done
label x01_27_xtn_accent
add r0 1
cmp r0 r9
jge x01_27_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_27_xtn_a
cmp r3 161
je x01_27_xtn_a
cmp r3 137
je x01_27_xtn_e
cmp r3 169
je x01_27_xtn_e
cmp r3 141
je x01_27_xtn_i
cmp r3 173
je x01_27_xtn_i
cmp r3 147
je x01_27_xtn_o
cmp r3 179
je x01_27_xtn_o
cmp r3 154
je x01_27_xtn_u
cmp r3 186
je x01_27_xtn_u
cmp r3 145
je x01_27_xtn_n
cmp r3 177
je x01_27_xtn_n
jmp x01_27_xtn_done
label x01_27_xtn_a
set r3 97
jmp x01_27_xtn_append
label x01_27_xtn_e
set r3 101
jmp x01_27_xtn_append
label x01_27_xtn_i
set r3 105
jmp x01_27_xtn_append
label x01_27_xtn_o
set r3 111
jmp x01_27_xtn_append
label x01_27_xtn_u
set r3 117
jmp x01_27_xtn_append
label x01_27_xtn_n
set r3 110
jmp x01_27_xtn_append
label x01_27_xtn_space
cmp r1 0
je x01_27_xtn_next
set r2 1
jmp x01_27_xtn_next
label x01_27_xtn_append
cmp r2 0
je x01_27_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_27_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_27_xtn_next
add r0 1
jmp x01_27_xtn_each
label x01_27_xtn_valid
cmp r1 0
je x01_27_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_27_xtn_done
jmp x01_27_xt_normalized

label x01_lesson_28
store8 9050000000000000016 1
store8 9050000000000000017 8
store8 9050000000000000018 1
store8 9050000000000000019 16
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 115
store8 9050000000000000273 111
store8 9050000000000000274 108
store8 9050000000000000275 111
store8 9050000000000000276 32
store8 9050000000000000277 109
store8 9050000000000000278 105
store8 9050000000000000279 32
store8 9050000000000000280 108
store8 9050000000000000281 101
store8 9050000000000000282 110
store8 9050000000000000283 103
store8 9050000000000000284 117
store8 9050000000000000285 97
store8 9050000000000000286 106
store8 9050000000000000287 101
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_28_xt_blank
cmp r0 88
jne x01_28_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_28_xt_invalid
jmp x01_28_xt_validate
label x01_28_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_28_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_28_xt_invalid
add r0 1
cmp r0 16
jlt x01_28_xt_blank_header
set r0 32
label x01_28_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_28_xt_invalid
add r0 1
cmp r0 144
jlt x01_28_xt_blank_context
set r0 4096
label x01_28_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_28_xt_invalid
add r0 1
cmp r0 16384
jlt x01_28_xt_blank_bank
label x01_28_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_28_xt_invalid
cmp r0 0
je x01_28_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_28_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_28_xt_invalid
cmp r0 17
jgt x01_28_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_28_xt_invalid
label x01_28_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_28_xt_invalid
cmp r0 4
jgt x01_28_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_28_xt_invalid
cmp r0 1
jne x01_28_xt_modifier
cmp r1 1
jlt x01_28_xt_invalid
cmp r1 17
jgt x01_28_xt_invalid
jmp x01_28_xt_prepare
label x01_28_xt_modifier
cmp r1 0
jne x01_28_xt_invalid
cmp r2 0
jne x01_28_xt_invalid
label x01_28_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_28_xtn_begin
label x01_28_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_28_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_28_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_28_xt_invalid
set r10 0
label x01_28_xt_lookup
cmp r10 r6
jge x01_28_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_28_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_28_xt_next
set r0 0
label x01_28_xt_compare
cmp r0 r12
jge x01_28_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_28_xt_next
add r0 1
jmp x01_28_xt_compare
label x01_28_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_28_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_28_xt_correct
jmp x01_28_xt_clean
label x01_28_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_28_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_28_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_28_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_28_xt_clean
label x01_28_xt_next
add r10 1
jmp x01_28_xt_lookup
label x01_28_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_28_xt_invalid
cmp r6 128
jge x01_28_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_28_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_28_xt_invalid
add r0 1
cmp r0 96
jlt x01_28_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_28_xt_copy
cmp r0 r12
jge x01_28_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_28_xt_copy
label x01_28_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_28_xt_clean
set r0 16
label x01_28_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_28_xt_clean_mailbox
set r0 256
label x01_28_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_28_xt_clean_scratch
jmp x01_lesson_29
label x01_28_xt_invalid
div r0 0

label x01_28_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_28_xtn_done
cmp r9 255
jgt x01_28_xtn_done
label x01_28_xtn_each
cmp r0 r9
jge x01_28_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_28_xtn_inverted
cmp r3 195
je x01_28_xtn_accent
cmp r3 226
je x01_28_xtn_unicode_space
cmp r3 32
je x01_28_xtn_space
cmp r3 44
je x01_28_xtn_space
cmp r3 46
je x01_28_xtn_space
cmp r3 33
je x01_28_xtn_space
cmp r3 63
je x01_28_xtn_space
cmp r3 65
jlt x01_28_xtn_ascii
cmp r3 90
jgt x01_28_xtn_ascii
add r3 32
label x01_28_xtn_ascii
cmp r3 97
jlt x01_28_xtn_digit
cmp r3 122
jle x01_28_xtn_append
label x01_28_xtn_digit
cmp r3 48
jlt x01_28_xtn_done
cmp r3 57
jgt x01_28_xtn_done
jmp x01_28_xtn_append
label x01_28_xtn_inverted
add r0 1
cmp r0 r9
jge x01_28_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_28_xtn_space
cmp r3 191
je x01_28_xtn_space
cmp r3 161
je x01_28_xtn_space
jmp x01_28_xtn_done
label x01_28_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_28_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_28_xtn_done
add r0 1
cmp r0 r9
jge x01_28_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_28_xtn_space
cmp r3 175
je x01_28_xtn_space
jmp x01_28_xtn_done
label x01_28_xtn_accent
add r0 1
cmp r0 r9
jge x01_28_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_28_xtn_a
cmp r3 161
je x01_28_xtn_a
cmp r3 137
je x01_28_xtn_e
cmp r3 169
je x01_28_xtn_e
cmp r3 141
je x01_28_xtn_i
cmp r3 173
je x01_28_xtn_i
cmp r3 147
je x01_28_xtn_o
cmp r3 179
je x01_28_xtn_o
cmp r3 154
je x01_28_xtn_u
cmp r3 186
je x01_28_xtn_u
cmp r3 145
je x01_28_xtn_n
cmp r3 177
je x01_28_xtn_n
jmp x01_28_xtn_done
label x01_28_xtn_a
set r3 97
jmp x01_28_xtn_append
label x01_28_xtn_e
set r3 101
jmp x01_28_xtn_append
label x01_28_xtn_i
set r3 105
jmp x01_28_xtn_append
label x01_28_xtn_o
set r3 111
jmp x01_28_xtn_append
label x01_28_xtn_u
set r3 117
jmp x01_28_xtn_append
label x01_28_xtn_n
set r3 110
jmp x01_28_xtn_append
label x01_28_xtn_space
cmp r1 0
je x01_28_xtn_next
set r2 1
jmp x01_28_xtn_next
label x01_28_xtn_append
cmp r2 0
je x01_28_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_28_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_28_xtn_next
add r0 1
jmp x01_28_xtn_each
label x01_28_xtn_valid
cmp r1 0
je x01_28_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_28_xtn_done
jmp x01_28_xt_normalized

label x01_lesson_29
store8 9050000000000000016 1
store8 9050000000000000017 8
store8 9050000000000000018 1
store8 9050000000000000019 48
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 113
store8 9050000000000000273 117
store8 9050000000000000274 101
store8 9050000000000000275 32
store8 9050000000000000276 101
store8 9050000000000000277 108
store8 9050000000000000278 32
store8 9050000000000000279 112
store8 9050000000000000280 114
store8 9050000000000000281 105
store8 9050000000000000282 110
store8 9050000000000000283 99
store8 9050000000000000284 105
store8 9050000000000000285 112
store8 9050000000000000286 105
store8 9050000000000000287 111
store8 9050000000000000288 32
store8 9050000000000000289 115
store8 9050000000000000290 101
store8 9050000000000000291 97
store8 9050000000000000292 32
store8 9050000000000000293 101
store8 9050000000000000294 115
store8 9050000000000000295 116
store8 9050000000000000296 97
store8 9050000000000000297 100
store8 9050000000000000298 111
store8 9050000000000000299 115
store8 9050000000000000300 32
store8 9050000000000000301 109
store8 9050000000000000302 195
store8 9050000000000000303 173
store8 9050000000000000304 110
store8 9050000000000000305 105
store8 9050000000000000306 109
store8 9050000000000000307 111
store8 9050000000000000308 115
store8 9050000000000000309 32
store8 9050000000000000310 121
store8 9050000000000000311 32
store8 9050000000000000312 112
store8 9050000000000000313 111
store8 9050000000000000314 114
store8 9050000000000000315 32
store8 9050000000000000316 101
store8 9050000000000000317 116
store8 9050000000000000318 101
store8 9050000000000000319 114
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_29_xt_blank
cmp r0 88
jne x01_29_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_29_xt_invalid
jmp x01_29_xt_validate
label x01_29_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_29_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_29_xt_invalid
add r0 1
cmp r0 16
jlt x01_29_xt_blank_header
set r0 32
label x01_29_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_29_xt_invalid
add r0 1
cmp r0 144
jlt x01_29_xt_blank_context
set r0 4096
label x01_29_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_29_xt_invalid
add r0 1
cmp r0 16384
jlt x01_29_xt_blank_bank
label x01_29_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_29_xt_invalid
cmp r0 0
je x01_29_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_29_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_29_xt_invalid
cmp r0 17
jgt x01_29_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_29_xt_invalid
label x01_29_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_29_xt_invalid
cmp r0 4
jgt x01_29_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_29_xt_invalid
cmp r0 1
jne x01_29_xt_modifier
cmp r1 1
jlt x01_29_xt_invalid
cmp r1 17
jgt x01_29_xt_invalid
jmp x01_29_xt_prepare
label x01_29_xt_modifier
cmp r1 0
jne x01_29_xt_invalid
cmp r2 0
jne x01_29_xt_invalid
label x01_29_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_29_xtn_begin
label x01_29_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_29_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_29_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_29_xt_invalid
set r10 0
label x01_29_xt_lookup
cmp r10 r6
jge x01_29_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_29_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_29_xt_next
set r0 0
label x01_29_xt_compare
cmp r0 r12
jge x01_29_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_29_xt_next
add r0 1
jmp x01_29_xt_compare
label x01_29_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_29_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_29_xt_correct
jmp x01_29_xt_clean
label x01_29_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_29_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_29_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_29_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_29_xt_clean
label x01_29_xt_next
add r10 1
jmp x01_29_xt_lookup
label x01_29_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_29_xt_invalid
cmp r6 128
jge x01_29_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_29_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_29_xt_invalid
add r0 1
cmp r0 96
jlt x01_29_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_29_xt_copy
cmp r0 r12
jge x01_29_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_29_xt_copy
label x01_29_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_29_xt_clean
set r0 16
label x01_29_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_29_xt_clean_mailbox
set r0 256
label x01_29_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_29_xt_clean_scratch
jmp x01_lesson_30
label x01_29_xt_invalid
div r0 0

label x01_29_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_29_xtn_done
cmp r9 255
jgt x01_29_xtn_done
label x01_29_xtn_each
cmp r0 r9
jge x01_29_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_29_xtn_inverted
cmp r3 195
je x01_29_xtn_accent
cmp r3 226
je x01_29_xtn_unicode_space
cmp r3 32
je x01_29_xtn_space
cmp r3 44
je x01_29_xtn_space
cmp r3 46
je x01_29_xtn_space
cmp r3 33
je x01_29_xtn_space
cmp r3 63
je x01_29_xtn_space
cmp r3 65
jlt x01_29_xtn_ascii
cmp r3 90
jgt x01_29_xtn_ascii
add r3 32
label x01_29_xtn_ascii
cmp r3 97
jlt x01_29_xtn_digit
cmp r3 122
jle x01_29_xtn_append
label x01_29_xtn_digit
cmp r3 48
jlt x01_29_xtn_done
cmp r3 57
jgt x01_29_xtn_done
jmp x01_29_xtn_append
label x01_29_xtn_inverted
add r0 1
cmp r0 r9
jge x01_29_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_29_xtn_space
cmp r3 191
je x01_29_xtn_space
cmp r3 161
je x01_29_xtn_space
jmp x01_29_xtn_done
label x01_29_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_29_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_29_xtn_done
add r0 1
cmp r0 r9
jge x01_29_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_29_xtn_space
cmp r3 175
je x01_29_xtn_space
jmp x01_29_xtn_done
label x01_29_xtn_accent
add r0 1
cmp r0 r9
jge x01_29_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_29_xtn_a
cmp r3 161
je x01_29_xtn_a
cmp r3 137
je x01_29_xtn_e
cmp r3 169
je x01_29_xtn_e
cmp r3 141
je x01_29_xtn_i
cmp r3 173
je x01_29_xtn_i
cmp r3 147
je x01_29_xtn_o
cmp r3 179
je x01_29_xtn_o
cmp r3 154
je x01_29_xtn_u
cmp r3 186
je x01_29_xtn_u
cmp r3 145
je x01_29_xtn_n
cmp r3 177
je x01_29_xtn_n
jmp x01_29_xtn_done
label x01_29_xtn_a
set r3 97
jmp x01_29_xtn_append
label x01_29_xtn_e
set r3 101
jmp x01_29_xtn_append
label x01_29_xtn_i
set r3 105
jmp x01_29_xtn_append
label x01_29_xtn_o
set r3 111
jmp x01_29_xtn_append
label x01_29_xtn_u
set r3 117
jmp x01_29_xtn_append
label x01_29_xtn_n
set r3 110
jmp x01_29_xtn_append
label x01_29_xtn_space
cmp r1 0
je x01_29_xtn_next
set r2 1
jmp x01_29_xtn_next
label x01_29_xtn_append
cmp r2 0
je x01_29_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_29_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_29_xtn_next
add r0 1
jmp x01_29_xtn_each
label x01_29_xtn_valid
cmp r1 0
je x01_29_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_29_xtn_done
jmp x01_29_xt_normalized

label x01_lesson_30
store8 9050000000000000016 1
store8 9050000000000000017 8
store8 9050000000000000018 1
store8 9050000000000000019 39
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 110
store8 9050000000000000273 111
store8 9050000000000000274 32
store8 9050000000000000275 115
store8 9050000000000000276 101
store8 9050000000000000277 97
store8 9050000000000000278 115
store8 9050000000000000279 32
store8 9050000000000000280 101
store8 9050000000000000281 115
store8 9050000000000000282 116
store8 9050000000000000283 195
store8 9050000000000000284 186
store8 9050000000000000285 112
store8 9050000000000000286 105
store8 9050000000000000287 100
store8 9050000000000000288 111
store8 9050000000000000289 32
store8 9050000000000000290 98
store8 9050000000000000291 98
store8 9050000000000000292 121
store8 9050000000000000293 32
store8 9050000000000000294 113
store8 9050000000000000295 32
store8 9050000000000000296 101
store8 9050000000000000297 115
store8 9050000000000000298 32
store8 9050000000000000299 101
store8 9050000000000000300 108
store8 9050000000000000301 32
store8 9050000000000000302 112
store8 9050000000000000303 114
store8 9050000000000000304 105
store8 9050000000000000305 110
store8 9050000000000000306 99
store8 9050000000000000307 105
store8 9050000000000000308 112
store8 9050000000000000309 97
store8 9050000000000000310 108
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_30_xt_blank
cmp r0 88
jne x01_30_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_30_xt_invalid
jmp x01_30_xt_validate
label x01_30_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_30_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_30_xt_invalid
add r0 1
cmp r0 16
jlt x01_30_xt_blank_header
set r0 32
label x01_30_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_30_xt_invalid
add r0 1
cmp r0 144
jlt x01_30_xt_blank_context
set r0 4096
label x01_30_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_30_xt_invalid
add r0 1
cmp r0 16384
jlt x01_30_xt_blank_bank
label x01_30_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_30_xt_invalid
cmp r0 0
je x01_30_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_30_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_30_xt_invalid
cmp r0 17
jgt x01_30_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_30_xt_invalid
label x01_30_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_30_xt_invalid
cmp r0 4
jgt x01_30_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_30_xt_invalid
cmp r0 1
jne x01_30_xt_modifier
cmp r1 1
jlt x01_30_xt_invalid
cmp r1 17
jgt x01_30_xt_invalid
jmp x01_30_xt_prepare
label x01_30_xt_modifier
cmp r1 0
jne x01_30_xt_invalid
cmp r2 0
jne x01_30_xt_invalid
label x01_30_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_30_xtn_begin
label x01_30_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_30_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_30_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_30_xt_invalid
set r10 0
label x01_30_xt_lookup
cmp r10 r6
jge x01_30_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_30_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_30_xt_next
set r0 0
label x01_30_xt_compare
cmp r0 r12
jge x01_30_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_30_xt_next
add r0 1
jmp x01_30_xt_compare
label x01_30_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_30_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_30_xt_correct
jmp x01_30_xt_clean
label x01_30_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_30_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_30_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_30_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_30_xt_clean
label x01_30_xt_next
add r10 1
jmp x01_30_xt_lookup
label x01_30_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_30_xt_invalid
cmp r6 128
jge x01_30_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_30_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_30_xt_invalid
add r0 1
cmp r0 96
jlt x01_30_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_30_xt_copy
cmp r0 r12
jge x01_30_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_30_xt_copy
label x01_30_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_30_xt_clean
set r0 16
label x01_30_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_30_xt_clean_mailbox
set r0 256
label x01_30_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_30_xt_clean_scratch
jmp x01_lesson_31
label x01_30_xt_invalid
div r0 0

label x01_30_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_30_xtn_done
cmp r9 255
jgt x01_30_xtn_done
label x01_30_xtn_each
cmp r0 r9
jge x01_30_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_30_xtn_inverted
cmp r3 195
je x01_30_xtn_accent
cmp r3 226
je x01_30_xtn_unicode_space
cmp r3 32
je x01_30_xtn_space
cmp r3 44
je x01_30_xtn_space
cmp r3 46
je x01_30_xtn_space
cmp r3 33
je x01_30_xtn_space
cmp r3 63
je x01_30_xtn_space
cmp r3 65
jlt x01_30_xtn_ascii
cmp r3 90
jgt x01_30_xtn_ascii
add r3 32
label x01_30_xtn_ascii
cmp r3 97
jlt x01_30_xtn_digit
cmp r3 122
jle x01_30_xtn_append
label x01_30_xtn_digit
cmp r3 48
jlt x01_30_xtn_done
cmp r3 57
jgt x01_30_xtn_done
jmp x01_30_xtn_append
label x01_30_xtn_inverted
add r0 1
cmp r0 r9
jge x01_30_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_30_xtn_space
cmp r3 191
je x01_30_xtn_space
cmp r3 161
je x01_30_xtn_space
jmp x01_30_xtn_done
label x01_30_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_30_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_30_xtn_done
add r0 1
cmp r0 r9
jge x01_30_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_30_xtn_space
cmp r3 175
je x01_30_xtn_space
jmp x01_30_xtn_done
label x01_30_xtn_accent
add r0 1
cmp r0 r9
jge x01_30_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_30_xtn_a
cmp r3 161
je x01_30_xtn_a
cmp r3 137
je x01_30_xtn_e
cmp r3 169
je x01_30_xtn_e
cmp r3 141
je x01_30_xtn_i
cmp r3 173
je x01_30_xtn_i
cmp r3 147
je x01_30_xtn_o
cmp r3 179
je x01_30_xtn_o
cmp r3 154
je x01_30_xtn_u
cmp r3 186
je x01_30_xtn_u
cmp r3 145
je x01_30_xtn_n
cmp r3 177
je x01_30_xtn_n
jmp x01_30_xtn_done
label x01_30_xtn_a
set r3 97
jmp x01_30_xtn_append
label x01_30_xtn_e
set r3 101
jmp x01_30_xtn_append
label x01_30_xtn_i
set r3 105
jmp x01_30_xtn_append
label x01_30_xtn_o
set r3 111
jmp x01_30_xtn_append
label x01_30_xtn_u
set r3 117
jmp x01_30_xtn_append
label x01_30_xtn_n
set r3 110
jmp x01_30_xtn_append
label x01_30_xtn_space
cmp r1 0
je x01_30_xtn_next
set r2 1
jmp x01_30_xtn_next
label x01_30_xtn_append
cmp r2 0
je x01_30_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_30_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_30_xtn_next
add r0 1
jmp x01_30_xtn_each
label x01_30_xtn_valid
cmp r1 0
je x01_30_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_30_xtn_done
jmp x01_30_xt_normalized

label x01_lesson_31
store8 9050000000000000016 1
store8 9050000000000000017 9
store8 9050000000000000018 1
store8 9050000000000000019 18
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 105
store8 9050000000000000273 110
store8 9050000000000000274 118
store8 9050000000000000275 101
store8 9050000000000000276 115
store8 9050000000000000277 116
store8 9050000000000000278 105
store8 9050000000000000279 103
store8 9050000000000000280 97
store8 9050000000000000281 32
store8 9050000000000000282 101
store8 9050000000000000283 108
store8 9050000000000000284 32
store8 9050000000000000285 101
store8 9050000000000000286 114
store8 9050000000000000287 114
store8 9050000000000000288 111
store8 9050000000000000289 114
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_31_xt_blank
cmp r0 88
jne x01_31_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_31_xt_invalid
jmp x01_31_xt_validate
label x01_31_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_31_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_31_xt_invalid
add r0 1
cmp r0 16
jlt x01_31_xt_blank_header
set r0 32
label x01_31_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_31_xt_invalid
add r0 1
cmp r0 144
jlt x01_31_xt_blank_context
set r0 4096
label x01_31_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_31_xt_invalid
add r0 1
cmp r0 16384
jlt x01_31_xt_blank_bank
label x01_31_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_31_xt_invalid
cmp r0 0
je x01_31_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_31_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_31_xt_invalid
cmp r0 17
jgt x01_31_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_31_xt_invalid
label x01_31_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_31_xt_invalid
cmp r0 4
jgt x01_31_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_31_xt_invalid
cmp r0 1
jne x01_31_xt_modifier
cmp r1 1
jlt x01_31_xt_invalid
cmp r1 17
jgt x01_31_xt_invalid
jmp x01_31_xt_prepare
label x01_31_xt_modifier
cmp r1 0
jne x01_31_xt_invalid
cmp r2 0
jne x01_31_xt_invalid
label x01_31_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_31_xtn_begin
label x01_31_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_31_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_31_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_31_xt_invalid
set r10 0
label x01_31_xt_lookup
cmp r10 r6
jge x01_31_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_31_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_31_xt_next
set r0 0
label x01_31_xt_compare
cmp r0 r12
jge x01_31_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_31_xt_next
add r0 1
jmp x01_31_xt_compare
label x01_31_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_31_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_31_xt_correct
jmp x01_31_xt_clean
label x01_31_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_31_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_31_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_31_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_31_xt_clean
label x01_31_xt_next
add r10 1
jmp x01_31_xt_lookup
label x01_31_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_31_xt_invalid
cmp r6 128
jge x01_31_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_31_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_31_xt_invalid
add r0 1
cmp r0 96
jlt x01_31_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_31_xt_copy
cmp r0 r12
jge x01_31_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_31_xt_copy
label x01_31_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_31_xt_clean
set r0 16
label x01_31_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_31_xt_clean_mailbox
set r0 256
label x01_31_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_31_xt_clean_scratch
jmp x01_lesson_32
label x01_31_xt_invalid
div r0 0

label x01_31_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_31_xtn_done
cmp r9 255
jgt x01_31_xtn_done
label x01_31_xtn_each
cmp r0 r9
jge x01_31_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_31_xtn_inverted
cmp r3 195
je x01_31_xtn_accent
cmp r3 226
je x01_31_xtn_unicode_space
cmp r3 32
je x01_31_xtn_space
cmp r3 44
je x01_31_xtn_space
cmp r3 46
je x01_31_xtn_space
cmp r3 33
je x01_31_xtn_space
cmp r3 63
je x01_31_xtn_space
cmp r3 65
jlt x01_31_xtn_ascii
cmp r3 90
jgt x01_31_xtn_ascii
add r3 32
label x01_31_xtn_ascii
cmp r3 97
jlt x01_31_xtn_digit
cmp r3 122
jle x01_31_xtn_append
label x01_31_xtn_digit
cmp r3 48
jlt x01_31_xtn_done
cmp r3 57
jgt x01_31_xtn_done
jmp x01_31_xtn_append
label x01_31_xtn_inverted
add r0 1
cmp r0 r9
jge x01_31_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_31_xtn_space
cmp r3 191
je x01_31_xtn_space
cmp r3 161
je x01_31_xtn_space
jmp x01_31_xtn_done
label x01_31_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_31_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_31_xtn_done
add r0 1
cmp r0 r9
jge x01_31_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_31_xtn_space
cmp r3 175
je x01_31_xtn_space
jmp x01_31_xtn_done
label x01_31_xtn_accent
add r0 1
cmp r0 r9
jge x01_31_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_31_xtn_a
cmp r3 161
je x01_31_xtn_a
cmp r3 137
je x01_31_xtn_e
cmp r3 169
je x01_31_xtn_e
cmp r3 141
je x01_31_xtn_i
cmp r3 173
je x01_31_xtn_i
cmp r3 147
je x01_31_xtn_o
cmp r3 179
je x01_31_xtn_o
cmp r3 154
je x01_31_xtn_u
cmp r3 186
je x01_31_xtn_u
cmp r3 145
je x01_31_xtn_n
cmp r3 177
je x01_31_xtn_n
jmp x01_31_xtn_done
label x01_31_xtn_a
set r3 97
jmp x01_31_xtn_append
label x01_31_xtn_e
set r3 101
jmp x01_31_xtn_append
label x01_31_xtn_i
set r3 105
jmp x01_31_xtn_append
label x01_31_xtn_o
set r3 111
jmp x01_31_xtn_append
label x01_31_xtn_u
set r3 117
jmp x01_31_xtn_append
label x01_31_xtn_n
set r3 110
jmp x01_31_xtn_append
label x01_31_xtn_space
cmp r1 0
je x01_31_xtn_next
set r2 1
jmp x01_31_xtn_next
label x01_31_xtn_append
cmp r2 0
je x01_31_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_31_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_31_xtn_next
add r0 1
jmp x01_31_xtn_each
label x01_31_xtn_valid
cmp r1 0
je x01_31_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_31_xtn_done
jmp x01_31_xt_normalized

label x01_lesson_32
store8 9050000000000000016 1
store8 9050000000000000017 9
store8 9050000000000000018 1
store8 9050000000000000019 17
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 118
store8 9050000000000000273 101
store8 9050000000000000274 114
store8 9050000000000000275 105
store8 9050000000000000276 102
store8 9050000000000000277 105
store8 9050000000000000278 99
store8 9050000000000000279 97
store8 9050000000000000280 32
store8 9050000000000000281 121
store8 9050000000000000282 32
store8 9050000000000000283 114
store8 9050000000000000284 101
store8 9050000000000000285 112
store8 9050000000000000286 97
store8 9050000000000000287 114
store8 9050000000000000288 97
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_32_xt_blank
cmp r0 88
jne x01_32_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_32_xt_invalid
jmp x01_32_xt_validate
label x01_32_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_32_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_32_xt_invalid
add r0 1
cmp r0 16
jlt x01_32_xt_blank_header
set r0 32
label x01_32_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_32_xt_invalid
add r0 1
cmp r0 144
jlt x01_32_xt_blank_context
set r0 4096
label x01_32_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_32_xt_invalid
add r0 1
cmp r0 16384
jlt x01_32_xt_blank_bank
label x01_32_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_32_xt_invalid
cmp r0 0
je x01_32_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_32_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_32_xt_invalid
cmp r0 17
jgt x01_32_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_32_xt_invalid
label x01_32_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_32_xt_invalid
cmp r0 4
jgt x01_32_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_32_xt_invalid
cmp r0 1
jne x01_32_xt_modifier
cmp r1 1
jlt x01_32_xt_invalid
cmp r1 17
jgt x01_32_xt_invalid
jmp x01_32_xt_prepare
label x01_32_xt_modifier
cmp r1 0
jne x01_32_xt_invalid
cmp r2 0
jne x01_32_xt_invalid
label x01_32_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_32_xtn_begin
label x01_32_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_32_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_32_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_32_xt_invalid
set r10 0
label x01_32_xt_lookup
cmp r10 r6
jge x01_32_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_32_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_32_xt_next
set r0 0
label x01_32_xt_compare
cmp r0 r12
jge x01_32_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_32_xt_next
add r0 1
jmp x01_32_xt_compare
label x01_32_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_32_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_32_xt_correct
jmp x01_32_xt_clean
label x01_32_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_32_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_32_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_32_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_32_xt_clean
label x01_32_xt_next
add r10 1
jmp x01_32_xt_lookup
label x01_32_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_32_xt_invalid
cmp r6 128
jge x01_32_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_32_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_32_xt_invalid
add r0 1
cmp r0 96
jlt x01_32_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_32_xt_copy
cmp r0 r12
jge x01_32_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_32_xt_copy
label x01_32_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_32_xt_clean
set r0 16
label x01_32_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_32_xt_clean_mailbox
set r0 256
label x01_32_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_32_xt_clean_scratch
jmp x01_lesson_33
label x01_32_xt_invalid
div r0 0

label x01_32_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_32_xtn_done
cmp r9 255
jgt x01_32_xtn_done
label x01_32_xtn_each
cmp r0 r9
jge x01_32_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_32_xtn_inverted
cmp r3 195
je x01_32_xtn_accent
cmp r3 226
je x01_32_xtn_unicode_space
cmp r3 32
je x01_32_xtn_space
cmp r3 44
je x01_32_xtn_space
cmp r3 46
je x01_32_xtn_space
cmp r3 33
je x01_32_xtn_space
cmp r3 63
je x01_32_xtn_space
cmp r3 65
jlt x01_32_xtn_ascii
cmp r3 90
jgt x01_32_xtn_ascii
add r3 32
label x01_32_xtn_ascii
cmp r3 97
jlt x01_32_xtn_digit
cmp r3 122
jle x01_32_xtn_append
label x01_32_xtn_digit
cmp r3 48
jlt x01_32_xtn_done
cmp r3 57
jgt x01_32_xtn_done
jmp x01_32_xtn_append
label x01_32_xtn_inverted
add r0 1
cmp r0 r9
jge x01_32_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_32_xtn_space
cmp r3 191
je x01_32_xtn_space
cmp r3 161
je x01_32_xtn_space
jmp x01_32_xtn_done
label x01_32_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_32_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_32_xtn_done
add r0 1
cmp r0 r9
jge x01_32_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_32_xtn_space
cmp r3 175
je x01_32_xtn_space
jmp x01_32_xtn_done
label x01_32_xtn_accent
add r0 1
cmp r0 r9
jge x01_32_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_32_xtn_a
cmp r3 161
je x01_32_xtn_a
cmp r3 137
je x01_32_xtn_e
cmp r3 169
je x01_32_xtn_e
cmp r3 141
je x01_32_xtn_i
cmp r3 173
je x01_32_xtn_i
cmp r3 147
je x01_32_xtn_o
cmp r3 179
je x01_32_xtn_o
cmp r3 154
je x01_32_xtn_u
cmp r3 186
je x01_32_xtn_u
cmp r3 145
je x01_32_xtn_n
cmp r3 177
je x01_32_xtn_n
jmp x01_32_xtn_done
label x01_32_xtn_a
set r3 97
jmp x01_32_xtn_append
label x01_32_xtn_e
set r3 101
jmp x01_32_xtn_append
label x01_32_xtn_i
set r3 105
jmp x01_32_xtn_append
label x01_32_xtn_o
set r3 111
jmp x01_32_xtn_append
label x01_32_xtn_u
set r3 117
jmp x01_32_xtn_append
label x01_32_xtn_n
set r3 110
jmp x01_32_xtn_append
label x01_32_xtn_space
cmp r1 0
je x01_32_xtn_next
set r2 1
jmp x01_32_xtn_next
label x01_32_xtn_append
cmp r2 0
je x01_32_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_32_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_32_xtn_next
add r0 1
jmp x01_32_xtn_each
label x01_32_xtn_valid
cmp r1 0
je x01_32_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_32_xtn_done
jmp x01_32_xt_normalized

label x01_lesson_33
store8 9050000000000000016 1
store8 9050000000000000017 9
store8 9050000000000000018 1
store8 9050000000000000019 59
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 100
store8 9050000000000000273 105
store8 9050000000000000274 97
store8 9050000000000000275 103
store8 9050000000000000276 110
store8 9050000000000000277 195
store8 9050000000000000278 179
store8 9050000000000000279 115
store8 9050000000000000280 116
store8 9050000000000000281 105
store8 9050000000000000282 99
store8 9050000000000000283 97
store8 9050000000000000284 32
store8 9050000000000000285 121
store8 9050000000000000286 32
store8 9050000000000000287 116
store8 9050000000000000288 111
store8 9050000000000000289 109
store8 9050000000000000290 97
store8 9050000000000000291 32
store8 9050000000000000292 101
store8 9050000000000000293 110
store8 9050000000000000294 32
store8 9050000000000000295 99
store8 9050000000000000296 117
store8 9050000000000000297 101
store8 9050000000000000298 110
store8 9050000000000000299 116
store8 9050000000000000300 97
store8 9050000000000000301 32
store8 9050000000000000302 116
store8 9050000000000000303 111
store8 9050000000000000304 100
store8 9050000000000000305 111
store8 9050000000000000306 32
store8 9050000000000000307 108
store8 9050000000000000308 111
store8 9050000000000000309 115
store8 9050000000000000310 32
store8 9050000000000000311 114
store8 9050000000000000312 101
store8 9050000000000000313 115
store8 9050000000000000314 117
store8 9050000000000000315 108
store8 9050000000000000316 116
store8 9050000000000000317 97
store8 9050000000000000318 100
store8 9050000000000000319 111
store8 9050000000000000320 115
store8 9050000000000000321 32
store8 9050000000000000322 121
store8 9050000000000000323 32
store8 9050000000000000324 112
store8 9050000000000000325 114
store8 9050000000000000326 117
store8 9050000000000000327 101
store8 9050000000000000328 98
store8 9050000000000000329 97
store8 9050000000000000330 115
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_33_xt_blank
cmp r0 88
jne x01_33_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_33_xt_invalid
jmp x01_33_xt_validate
label x01_33_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_33_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_33_xt_invalid
add r0 1
cmp r0 16
jlt x01_33_xt_blank_header
set r0 32
label x01_33_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_33_xt_invalid
add r0 1
cmp r0 144
jlt x01_33_xt_blank_context
set r0 4096
label x01_33_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_33_xt_invalid
add r0 1
cmp r0 16384
jlt x01_33_xt_blank_bank
label x01_33_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_33_xt_invalid
cmp r0 0
je x01_33_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_33_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_33_xt_invalid
cmp r0 17
jgt x01_33_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_33_xt_invalid
label x01_33_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_33_xt_invalid
cmp r0 4
jgt x01_33_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_33_xt_invalid
cmp r0 1
jne x01_33_xt_modifier
cmp r1 1
jlt x01_33_xt_invalid
cmp r1 17
jgt x01_33_xt_invalid
jmp x01_33_xt_prepare
label x01_33_xt_modifier
cmp r1 0
jne x01_33_xt_invalid
cmp r2 0
jne x01_33_xt_invalid
label x01_33_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_33_xtn_begin
label x01_33_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_33_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_33_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_33_xt_invalid
set r10 0
label x01_33_xt_lookup
cmp r10 r6
jge x01_33_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_33_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_33_xt_next
set r0 0
label x01_33_xt_compare
cmp r0 r12
jge x01_33_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_33_xt_next
add r0 1
jmp x01_33_xt_compare
label x01_33_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_33_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_33_xt_correct
jmp x01_33_xt_clean
label x01_33_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_33_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_33_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_33_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_33_xt_clean
label x01_33_xt_next
add r10 1
jmp x01_33_xt_lookup
label x01_33_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_33_xt_invalid
cmp r6 128
jge x01_33_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_33_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_33_xt_invalid
add r0 1
cmp r0 96
jlt x01_33_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_33_xt_copy
cmp r0 r12
jge x01_33_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_33_xt_copy
label x01_33_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_33_xt_clean
set r0 16
label x01_33_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_33_xt_clean_mailbox
set r0 256
label x01_33_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_33_xt_clean_scratch
jmp x01_lesson_34
label x01_33_xt_invalid
div r0 0

label x01_33_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_33_xtn_done
cmp r9 255
jgt x01_33_xtn_done
label x01_33_xtn_each
cmp r0 r9
jge x01_33_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_33_xtn_inverted
cmp r3 195
je x01_33_xtn_accent
cmp r3 226
je x01_33_xtn_unicode_space
cmp r3 32
je x01_33_xtn_space
cmp r3 44
je x01_33_xtn_space
cmp r3 46
je x01_33_xtn_space
cmp r3 33
je x01_33_xtn_space
cmp r3 63
je x01_33_xtn_space
cmp r3 65
jlt x01_33_xtn_ascii
cmp r3 90
jgt x01_33_xtn_ascii
add r3 32
label x01_33_xtn_ascii
cmp r3 97
jlt x01_33_xtn_digit
cmp r3 122
jle x01_33_xtn_append
label x01_33_xtn_digit
cmp r3 48
jlt x01_33_xtn_done
cmp r3 57
jgt x01_33_xtn_done
jmp x01_33_xtn_append
label x01_33_xtn_inverted
add r0 1
cmp r0 r9
jge x01_33_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_33_xtn_space
cmp r3 191
je x01_33_xtn_space
cmp r3 161
je x01_33_xtn_space
jmp x01_33_xtn_done
label x01_33_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_33_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_33_xtn_done
add r0 1
cmp r0 r9
jge x01_33_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_33_xtn_space
cmp r3 175
je x01_33_xtn_space
jmp x01_33_xtn_done
label x01_33_xtn_accent
add r0 1
cmp r0 r9
jge x01_33_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_33_xtn_a
cmp r3 161
je x01_33_xtn_a
cmp r3 137
je x01_33_xtn_e
cmp r3 169
je x01_33_xtn_e
cmp r3 141
je x01_33_xtn_i
cmp r3 173
je x01_33_xtn_i
cmp r3 147
je x01_33_xtn_o
cmp r3 179
je x01_33_xtn_o
cmp r3 154
je x01_33_xtn_u
cmp r3 186
je x01_33_xtn_u
cmp r3 145
je x01_33_xtn_n
cmp r3 177
je x01_33_xtn_n
jmp x01_33_xtn_done
label x01_33_xtn_a
set r3 97
jmp x01_33_xtn_append
label x01_33_xtn_e
set r3 101
jmp x01_33_xtn_append
label x01_33_xtn_i
set r3 105
jmp x01_33_xtn_append
label x01_33_xtn_o
set r3 111
jmp x01_33_xtn_append
label x01_33_xtn_u
set r3 117
jmp x01_33_xtn_append
label x01_33_xtn_n
set r3 110
jmp x01_33_xtn_append
label x01_33_xtn_space
cmp r1 0
je x01_33_xtn_next
set r2 1
jmp x01_33_xtn_next
label x01_33_xtn_append
cmp r2 0
je x01_33_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_33_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_33_xtn_next
add r0 1
jmp x01_33_xtn_each
label x01_33_xtn_valid
cmp r1 0
je x01_33_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_33_xtn_done
jmp x01_33_xt_normalized

label x01_lesson_34
store8 9050000000000000016 1
store8 9050000000000000017 10
store8 9050000000000000018 0
store8 9050000000000000019 20
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 101
store8 9050000000000000273 110
store8 9050000000000000274 115
store8 9050000000000000275 101
store8 9050000000000000276 195
store8 9050000000000000277 177
store8 9050000000000000278 97
store8 9050000000000000279 108
store8 9050000000000000280 101
store8 9050000000000000281 32
store8 9050000000000000282 99
store8 9050000000000000283 111
store8 9050000000000000284 109
store8 9050000000000000285 111
store8 9050000000000000286 32
store8 9050000000000000287 104
store8 9050000000000000288 97
store8 9050000000000000289 98
store8 9050000000000000290 108
store8 9050000000000000291 111
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_34_xt_blank
cmp r0 88
jne x01_34_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_34_xt_invalid
jmp x01_34_xt_validate
label x01_34_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_34_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_34_xt_invalid
add r0 1
cmp r0 16
jlt x01_34_xt_blank_header
set r0 32
label x01_34_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_34_xt_invalid
add r0 1
cmp r0 144
jlt x01_34_xt_blank_context
set r0 4096
label x01_34_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_34_xt_invalid
add r0 1
cmp r0 16384
jlt x01_34_xt_blank_bank
label x01_34_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_34_xt_invalid
cmp r0 0
je x01_34_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_34_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_34_xt_invalid
cmp r0 17
jgt x01_34_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_34_xt_invalid
label x01_34_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_34_xt_invalid
cmp r0 4
jgt x01_34_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_34_xt_invalid
cmp r0 1
jne x01_34_xt_modifier
cmp r1 1
jlt x01_34_xt_invalid
cmp r1 17
jgt x01_34_xt_invalid
jmp x01_34_xt_prepare
label x01_34_xt_modifier
cmp r1 0
jne x01_34_xt_invalid
cmp r2 0
jne x01_34_xt_invalid
label x01_34_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_34_xtn_begin
label x01_34_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_34_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_34_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_34_xt_invalid
set r10 0
label x01_34_xt_lookup
cmp r10 r6
jge x01_34_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_34_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_34_xt_next
set r0 0
label x01_34_xt_compare
cmp r0 r12
jge x01_34_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_34_xt_next
add r0 1
jmp x01_34_xt_compare
label x01_34_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_34_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_34_xt_correct
jmp x01_34_xt_clean
label x01_34_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_34_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_34_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_34_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_34_xt_clean
label x01_34_xt_next
add r10 1
jmp x01_34_xt_lookup
label x01_34_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_34_xt_invalid
cmp r6 128
jge x01_34_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_34_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_34_xt_invalid
add r0 1
cmp r0 96
jlt x01_34_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_34_xt_copy
cmp r0 r12
jge x01_34_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_34_xt_copy
label x01_34_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_34_xt_clean
set r0 16
label x01_34_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_34_xt_clean_mailbox
set r0 256
label x01_34_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_34_xt_clean_scratch
jmp x01_lesson_35
label x01_34_xt_invalid
div r0 0

label x01_34_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_34_xtn_done
cmp r9 255
jgt x01_34_xtn_done
label x01_34_xtn_each
cmp r0 r9
jge x01_34_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_34_xtn_inverted
cmp r3 195
je x01_34_xtn_accent
cmp r3 226
je x01_34_xtn_unicode_space
cmp r3 32
je x01_34_xtn_space
cmp r3 44
je x01_34_xtn_space
cmp r3 46
je x01_34_xtn_space
cmp r3 33
je x01_34_xtn_space
cmp r3 63
je x01_34_xtn_space
cmp r3 65
jlt x01_34_xtn_ascii
cmp r3 90
jgt x01_34_xtn_ascii
add r3 32
label x01_34_xtn_ascii
cmp r3 97
jlt x01_34_xtn_digit
cmp r3 122
jle x01_34_xtn_append
label x01_34_xtn_digit
cmp r3 48
jlt x01_34_xtn_done
cmp r3 57
jgt x01_34_xtn_done
jmp x01_34_xtn_append
label x01_34_xtn_inverted
add r0 1
cmp r0 r9
jge x01_34_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_34_xtn_space
cmp r3 191
je x01_34_xtn_space
cmp r3 161
je x01_34_xtn_space
jmp x01_34_xtn_done
label x01_34_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_34_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_34_xtn_done
add r0 1
cmp r0 r9
jge x01_34_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_34_xtn_space
cmp r3 175
je x01_34_xtn_space
jmp x01_34_xtn_done
label x01_34_xtn_accent
add r0 1
cmp r0 r9
jge x01_34_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_34_xtn_a
cmp r3 161
je x01_34_xtn_a
cmp r3 137
je x01_34_xtn_e
cmp r3 169
je x01_34_xtn_e
cmp r3 141
je x01_34_xtn_i
cmp r3 173
je x01_34_xtn_i
cmp r3 147
je x01_34_xtn_o
cmp r3 179
je x01_34_xtn_o
cmp r3 154
je x01_34_xtn_u
cmp r3 186
je x01_34_xtn_u
cmp r3 145
je x01_34_xtn_n
cmp r3 177
je x01_34_xtn_n
jmp x01_34_xtn_done
label x01_34_xtn_a
set r3 97
jmp x01_34_xtn_append
label x01_34_xtn_e
set r3 101
jmp x01_34_xtn_append
label x01_34_xtn_i
set r3 105
jmp x01_34_xtn_append
label x01_34_xtn_o
set r3 111
jmp x01_34_xtn_append
label x01_34_xtn_u
set r3 117
jmp x01_34_xtn_append
label x01_34_xtn_n
set r3 110
jmp x01_34_xtn_append
label x01_34_xtn_space
cmp r1 0
je x01_34_xtn_next
set r2 1
jmp x01_34_xtn_next
label x01_34_xtn_append
cmp r2 0
je x01_34_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_34_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_34_xtn_next
add r0 1
jmp x01_34_xtn_each
label x01_34_xtn_valid
cmp r1 0
je x01_34_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_34_xtn_done
jmp x01_34_xt_normalized

label x01_lesson_35
store8 9050000000000000016 1
store8 9050000000000000017 10
store8 9050000000000000018 0
store8 9050000000000000019 29
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 101
store8 9050000000000000273 110
store8 9050000000000000274 115
store8 9050000000000000275 101
store8 9050000000000000276 195
store8 9050000000000000277 177
store8 9050000000000000278 97
store8 9050000000000000279 108
store8 9050000000000000280 101
store8 9050000000000000281 32
store8 9050000000000000282 99
store8 9050000000000000283 111
store8 9050000000000000284 109
store8 9050000000000000285 111
store8 9050000000000000286 32
store8 9050000000000000287 109
store8 9050000000000000288 101
store8 9050000000000000289 32
store8 9050000000000000290 105
store8 9050000000000000291 110
store8 9050000000000000292 116
store8 9050000000000000293 101
store8 9050000000000000294 114
store8 9050000000000000295 112
store8 9050000000000000296 114
store8 9050000000000000297 101
store8 9050000000000000298 116
store8 9050000000000000299 97
store8 9050000000000000300 115
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_35_xt_blank
cmp r0 88
jne x01_35_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_35_xt_invalid
jmp x01_35_xt_validate
label x01_35_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_35_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_35_xt_invalid
add r0 1
cmp r0 16
jlt x01_35_xt_blank_header
set r0 32
label x01_35_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_35_xt_invalid
add r0 1
cmp r0 144
jlt x01_35_xt_blank_context
set r0 4096
label x01_35_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_35_xt_invalid
add r0 1
cmp r0 16384
jlt x01_35_xt_blank_bank
label x01_35_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_35_xt_invalid
cmp r0 0
je x01_35_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_35_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_35_xt_invalid
cmp r0 17
jgt x01_35_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_35_xt_invalid
label x01_35_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_35_xt_invalid
cmp r0 4
jgt x01_35_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_35_xt_invalid
cmp r0 1
jne x01_35_xt_modifier
cmp r1 1
jlt x01_35_xt_invalid
cmp r1 17
jgt x01_35_xt_invalid
jmp x01_35_xt_prepare
label x01_35_xt_modifier
cmp r1 0
jne x01_35_xt_invalid
cmp r2 0
jne x01_35_xt_invalid
label x01_35_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_35_xtn_begin
label x01_35_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_35_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_35_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_35_xt_invalid
set r10 0
label x01_35_xt_lookup
cmp r10 r6
jge x01_35_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_35_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_35_xt_next
set r0 0
label x01_35_xt_compare
cmp r0 r12
jge x01_35_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_35_xt_next
add r0 1
jmp x01_35_xt_compare
label x01_35_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_35_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_35_xt_correct
jmp x01_35_xt_clean
label x01_35_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_35_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_35_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_35_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_35_xt_clean
label x01_35_xt_next
add r10 1
jmp x01_35_xt_lookup
label x01_35_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_35_xt_invalid
cmp r6 128
jge x01_35_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_35_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_35_xt_invalid
add r0 1
cmp r0 96
jlt x01_35_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_35_xt_copy
cmp r0 r12
jge x01_35_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_35_xt_copy
label x01_35_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_35_xt_clean
set r0 16
label x01_35_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_35_xt_clean_mailbox
set r0 256
label x01_35_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_35_xt_clean_scratch
jmp x01_lesson_36
label x01_35_xt_invalid
div r0 0

label x01_35_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_35_xtn_done
cmp r9 255
jgt x01_35_xtn_done
label x01_35_xtn_each
cmp r0 r9
jge x01_35_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_35_xtn_inverted
cmp r3 195
je x01_35_xtn_accent
cmp r3 226
je x01_35_xtn_unicode_space
cmp r3 32
je x01_35_xtn_space
cmp r3 44
je x01_35_xtn_space
cmp r3 46
je x01_35_xtn_space
cmp r3 33
je x01_35_xtn_space
cmp r3 63
je x01_35_xtn_space
cmp r3 65
jlt x01_35_xtn_ascii
cmp r3 90
jgt x01_35_xtn_ascii
add r3 32
label x01_35_xtn_ascii
cmp r3 97
jlt x01_35_xtn_digit
cmp r3 122
jle x01_35_xtn_append
label x01_35_xtn_digit
cmp r3 48
jlt x01_35_xtn_done
cmp r3 57
jgt x01_35_xtn_done
jmp x01_35_xtn_append
label x01_35_xtn_inverted
add r0 1
cmp r0 r9
jge x01_35_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_35_xtn_space
cmp r3 191
je x01_35_xtn_space
cmp r3 161
je x01_35_xtn_space
jmp x01_35_xtn_done
label x01_35_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_35_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_35_xtn_done
add r0 1
cmp r0 r9
jge x01_35_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_35_xtn_space
cmp r3 175
je x01_35_xtn_space
jmp x01_35_xtn_done
label x01_35_xtn_accent
add r0 1
cmp r0 r9
jge x01_35_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_35_xtn_a
cmp r3 161
je x01_35_xtn_a
cmp r3 137
je x01_35_xtn_e
cmp r3 169
je x01_35_xtn_e
cmp r3 141
je x01_35_xtn_i
cmp r3 173
je x01_35_xtn_i
cmp r3 147
je x01_35_xtn_o
cmp r3 179
je x01_35_xtn_o
cmp r3 154
je x01_35_xtn_u
cmp r3 186
je x01_35_xtn_u
cmp r3 145
je x01_35_xtn_n
cmp r3 177
je x01_35_xtn_n
jmp x01_35_xtn_done
label x01_35_xtn_a
set r3 97
jmp x01_35_xtn_append
label x01_35_xtn_e
set r3 101
jmp x01_35_xtn_append
label x01_35_xtn_i
set r3 105
jmp x01_35_xtn_append
label x01_35_xtn_o
set r3 111
jmp x01_35_xtn_append
label x01_35_xtn_u
set r3 117
jmp x01_35_xtn_append
label x01_35_xtn_n
set r3 110
jmp x01_35_xtn_append
label x01_35_xtn_space
cmp r1 0
je x01_35_xtn_next
set r2 1
jmp x01_35_xtn_next
label x01_35_xtn_append
cmp r2 0
je x01_35_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_35_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_35_xtn_next
add r0 1
jmp x01_35_xtn_each
label x01_35_xtn_valid
cmp r1 0
je x01_35_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_35_xtn_done
jmp x01_35_xt_normalized

label x01_lesson_36
store8 9050000000000000016 1
store8 9050000000000000017 11
store8 9050000000000000018 1
store8 9050000000000000019 11
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 115
store8 9050000000000000273 105
store8 9050000000000000274 110
store8 9050000000000000275 32
store8 9050000000000000276 108
store8 9050000000000000277 105
store8 9050000000000000278 109
store8 9050000000000000279 105
store8 9050000000000000280 116
store8 9050000000000000281 101
store8 9050000000000000282 115
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_36_xt_blank
cmp r0 88
jne x01_36_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_36_xt_invalid
jmp x01_36_xt_validate
label x01_36_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_36_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_36_xt_invalid
add r0 1
cmp r0 16
jlt x01_36_xt_blank_header
set r0 32
label x01_36_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_36_xt_invalid
add r0 1
cmp r0 144
jlt x01_36_xt_blank_context
set r0 4096
label x01_36_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_36_xt_invalid
add r0 1
cmp r0 16384
jlt x01_36_xt_blank_bank
label x01_36_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_36_xt_invalid
cmp r0 0
je x01_36_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_36_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_36_xt_invalid
cmp r0 17
jgt x01_36_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_36_xt_invalid
label x01_36_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_36_xt_invalid
cmp r0 4
jgt x01_36_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_36_xt_invalid
cmp r0 1
jne x01_36_xt_modifier
cmp r1 1
jlt x01_36_xt_invalid
cmp r1 17
jgt x01_36_xt_invalid
jmp x01_36_xt_prepare
label x01_36_xt_modifier
cmp r1 0
jne x01_36_xt_invalid
cmp r2 0
jne x01_36_xt_invalid
label x01_36_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_36_xtn_begin
label x01_36_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_36_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_36_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_36_xt_invalid
set r10 0
label x01_36_xt_lookup
cmp r10 r6
jge x01_36_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_36_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_36_xt_next
set r0 0
label x01_36_xt_compare
cmp r0 r12
jge x01_36_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_36_xt_next
add r0 1
jmp x01_36_xt_compare
label x01_36_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_36_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_36_xt_correct
jmp x01_36_xt_clean
label x01_36_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_36_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_36_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_36_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_36_xt_clean
label x01_36_xt_next
add r10 1
jmp x01_36_xt_lookup
label x01_36_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_36_xt_invalid
cmp r6 128
jge x01_36_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_36_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_36_xt_invalid
add r0 1
cmp r0 96
jlt x01_36_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_36_xt_copy
cmp r0 r12
jge x01_36_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_36_xt_copy
label x01_36_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_36_xt_clean
set r0 16
label x01_36_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_36_xt_clean_mailbox
set r0 256
label x01_36_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_36_xt_clean_scratch
jmp x01_lesson_37
label x01_36_xt_invalid
div r0 0

label x01_36_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_36_xtn_done
cmp r9 255
jgt x01_36_xtn_done
label x01_36_xtn_each
cmp r0 r9
jge x01_36_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_36_xtn_inverted
cmp r3 195
je x01_36_xtn_accent
cmp r3 226
je x01_36_xtn_unicode_space
cmp r3 32
je x01_36_xtn_space
cmp r3 44
je x01_36_xtn_space
cmp r3 46
je x01_36_xtn_space
cmp r3 33
je x01_36_xtn_space
cmp r3 63
je x01_36_xtn_space
cmp r3 65
jlt x01_36_xtn_ascii
cmp r3 90
jgt x01_36_xtn_ascii
add r3 32
label x01_36_xtn_ascii
cmp r3 97
jlt x01_36_xtn_digit
cmp r3 122
jle x01_36_xtn_append
label x01_36_xtn_digit
cmp r3 48
jlt x01_36_xtn_done
cmp r3 57
jgt x01_36_xtn_done
jmp x01_36_xtn_append
label x01_36_xtn_inverted
add r0 1
cmp r0 r9
jge x01_36_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_36_xtn_space
cmp r3 191
je x01_36_xtn_space
cmp r3 161
je x01_36_xtn_space
jmp x01_36_xtn_done
label x01_36_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_36_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_36_xtn_done
add r0 1
cmp r0 r9
jge x01_36_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_36_xtn_space
cmp r3 175
je x01_36_xtn_space
jmp x01_36_xtn_done
label x01_36_xtn_accent
add r0 1
cmp r0 r9
jge x01_36_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_36_xtn_a
cmp r3 161
je x01_36_xtn_a
cmp r3 137
je x01_36_xtn_e
cmp r3 169
je x01_36_xtn_e
cmp r3 141
je x01_36_xtn_i
cmp r3 173
je x01_36_xtn_i
cmp r3 147
je x01_36_xtn_o
cmp r3 179
je x01_36_xtn_o
cmp r3 154
je x01_36_xtn_u
cmp r3 186
je x01_36_xtn_u
cmp r3 145
je x01_36_xtn_n
cmp r3 177
je x01_36_xtn_n
jmp x01_36_xtn_done
label x01_36_xtn_a
set r3 97
jmp x01_36_xtn_append
label x01_36_xtn_e
set r3 101
jmp x01_36_xtn_append
label x01_36_xtn_i
set r3 105
jmp x01_36_xtn_append
label x01_36_xtn_o
set r3 111
jmp x01_36_xtn_append
label x01_36_xtn_u
set r3 117
jmp x01_36_xtn_append
label x01_36_xtn_n
set r3 110
jmp x01_36_xtn_append
label x01_36_xtn_space
cmp r1 0
je x01_36_xtn_next
set r2 1
jmp x01_36_xtn_next
label x01_36_xtn_append
cmp r2 0
je x01_36_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_36_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_36_xtn_next
add r0 1
jmp x01_36_xtn_each
label x01_36_xtn_valid
cmp r1 0
je x01_36_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_36_xtn_done
jmp x01_36_xt_normalized

label x01_lesson_37
store8 9050000000000000016 1
store8 9050000000000000017 11
store8 9050000000000000018 1
store8 9050000000000000019 36
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 97
store8 9050000000000000273 109
store8 9050000000000000274 112
store8 9050000000000000275 108
store8 9050000000000000276 105
store8 9050000000000000277 97
store8 9050000000000000278 32
store8 9050000000000000279 97
store8 9050000000000000280 109
store8 9050000000000000281 112
store8 9050000000000000282 108
store8 9050000000000000283 105
store8 9050000000000000284 97
store8 9050000000000000285 32
store8 9050000000000000286 116
store8 9050000000000000287 111
store8 9050000000000000288 100
store8 9050000000000000289 111
store8 9050000000000000290 32
store8 9050000000000000291 115
store8 9050000000000000292 105
store8 9050000000000000293 110
store8 9050000000000000294 32
store8 9050000000000000295 108
store8 9050000000000000296 105
store8 9050000000000000297 109
store8 9050000000000000298 105
store8 9050000000000000299 116
store8 9050000000000000300 101
store8 9050000000000000301 32
store8 9050000000000000302 97
store8 9050000000000000303 108
store8 9050000000000000304 103
store8 9050000000000000305 117
store8 9050000000000000306 110
store8 9050000000000000307 111
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_37_xt_blank
cmp r0 88
jne x01_37_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_37_xt_invalid
jmp x01_37_xt_validate
label x01_37_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_37_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_37_xt_invalid
add r0 1
cmp r0 16
jlt x01_37_xt_blank_header
set r0 32
label x01_37_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_37_xt_invalid
add r0 1
cmp r0 144
jlt x01_37_xt_blank_context
set r0 4096
label x01_37_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_37_xt_invalid
add r0 1
cmp r0 16384
jlt x01_37_xt_blank_bank
label x01_37_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_37_xt_invalid
cmp r0 0
je x01_37_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_37_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_37_xt_invalid
cmp r0 17
jgt x01_37_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_37_xt_invalid
label x01_37_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_37_xt_invalid
cmp r0 4
jgt x01_37_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_37_xt_invalid
cmp r0 1
jne x01_37_xt_modifier
cmp r1 1
jlt x01_37_xt_invalid
cmp r1 17
jgt x01_37_xt_invalid
jmp x01_37_xt_prepare
label x01_37_xt_modifier
cmp r1 0
jne x01_37_xt_invalid
cmp r2 0
jne x01_37_xt_invalid
label x01_37_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_37_xtn_begin
label x01_37_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_37_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_37_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_37_xt_invalid
set r10 0
label x01_37_xt_lookup
cmp r10 r6
jge x01_37_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_37_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_37_xt_next
set r0 0
label x01_37_xt_compare
cmp r0 r12
jge x01_37_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_37_xt_next
add r0 1
jmp x01_37_xt_compare
label x01_37_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_37_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_37_xt_correct
jmp x01_37_xt_clean
label x01_37_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_37_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_37_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_37_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_37_xt_clean
label x01_37_xt_next
add r10 1
jmp x01_37_xt_lookup
label x01_37_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_37_xt_invalid
cmp r6 128
jge x01_37_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_37_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_37_xt_invalid
add r0 1
cmp r0 96
jlt x01_37_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_37_xt_copy
cmp r0 r12
jge x01_37_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_37_xt_copy
label x01_37_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_37_xt_clean
set r0 16
label x01_37_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_37_xt_clean_mailbox
set r0 256
label x01_37_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_37_xt_clean_scratch
jmp x01_lesson_38
label x01_37_xt_invalid
div r0 0

label x01_37_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_37_xtn_done
cmp r9 255
jgt x01_37_xtn_done
label x01_37_xtn_each
cmp r0 r9
jge x01_37_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_37_xtn_inverted
cmp r3 195
je x01_37_xtn_accent
cmp r3 226
je x01_37_xtn_unicode_space
cmp r3 32
je x01_37_xtn_space
cmp r3 44
je x01_37_xtn_space
cmp r3 46
je x01_37_xtn_space
cmp r3 33
je x01_37_xtn_space
cmp r3 63
je x01_37_xtn_space
cmp r3 65
jlt x01_37_xtn_ascii
cmp r3 90
jgt x01_37_xtn_ascii
add r3 32
label x01_37_xtn_ascii
cmp r3 97
jlt x01_37_xtn_digit
cmp r3 122
jle x01_37_xtn_append
label x01_37_xtn_digit
cmp r3 48
jlt x01_37_xtn_done
cmp r3 57
jgt x01_37_xtn_done
jmp x01_37_xtn_append
label x01_37_xtn_inverted
add r0 1
cmp r0 r9
jge x01_37_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_37_xtn_space
cmp r3 191
je x01_37_xtn_space
cmp r3 161
je x01_37_xtn_space
jmp x01_37_xtn_done
label x01_37_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_37_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_37_xtn_done
add r0 1
cmp r0 r9
jge x01_37_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_37_xtn_space
cmp r3 175
je x01_37_xtn_space
jmp x01_37_xtn_done
label x01_37_xtn_accent
add r0 1
cmp r0 r9
jge x01_37_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_37_xtn_a
cmp r3 161
je x01_37_xtn_a
cmp r3 137
je x01_37_xtn_e
cmp r3 169
je x01_37_xtn_e
cmp r3 141
je x01_37_xtn_i
cmp r3 173
je x01_37_xtn_i
cmp r3 147
je x01_37_xtn_o
cmp r3 179
je x01_37_xtn_o
cmp r3 154
je x01_37_xtn_u
cmp r3 186
je x01_37_xtn_u
cmp r3 145
je x01_37_xtn_n
cmp r3 177
je x01_37_xtn_n
jmp x01_37_xtn_done
label x01_37_xtn_a
set r3 97
jmp x01_37_xtn_append
label x01_37_xtn_e
set r3 101
jmp x01_37_xtn_append
label x01_37_xtn_i
set r3 105
jmp x01_37_xtn_append
label x01_37_xtn_o
set r3 111
jmp x01_37_xtn_append
label x01_37_xtn_u
set r3 117
jmp x01_37_xtn_append
label x01_37_xtn_n
set r3 110
jmp x01_37_xtn_append
label x01_37_xtn_space
cmp r1 0
je x01_37_xtn_next
set r2 1
jmp x01_37_xtn_next
label x01_37_xtn_append
cmp r2 0
je x01_37_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_37_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_37_xtn_next
add r0 1
jmp x01_37_xtn_each
label x01_37_xtn_valid
cmp r1 0
je x01_37_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_37_xtn_done
jmp x01_37_xt_normalized

label x01_lesson_38
store8 9050000000000000016 1
store8 9050000000000000017 12
store8 9050000000000000018 0
store8 9050000000000000019 9
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 110
store8 9050000000000000273 111
store8 9050000000000000274 32
store8 9050000000000000275 101
store8 9050000000000000276 115
store8 9050000000000000277 111
store8 9050000000000000278 32
store8 9050000000000000279 110
store8 9050000000000000280 111
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_38_xt_blank
cmp r0 88
jne x01_38_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_38_xt_invalid
jmp x01_38_xt_validate
label x01_38_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_38_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_38_xt_invalid
add r0 1
cmp r0 16
jlt x01_38_xt_blank_header
set r0 32
label x01_38_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_38_xt_invalid
add r0 1
cmp r0 144
jlt x01_38_xt_blank_context
set r0 4096
label x01_38_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_38_xt_invalid
add r0 1
cmp r0 16384
jlt x01_38_xt_blank_bank
label x01_38_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_38_xt_invalid
cmp r0 0
je x01_38_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_38_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_38_xt_invalid
cmp r0 17
jgt x01_38_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_38_xt_invalid
label x01_38_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_38_xt_invalid
cmp r0 4
jgt x01_38_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_38_xt_invalid
cmp r0 1
jne x01_38_xt_modifier
cmp r1 1
jlt x01_38_xt_invalid
cmp r1 17
jgt x01_38_xt_invalid
jmp x01_38_xt_prepare
label x01_38_xt_modifier
cmp r1 0
jne x01_38_xt_invalid
cmp r2 0
jne x01_38_xt_invalid
label x01_38_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_38_xtn_begin
label x01_38_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_38_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_38_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_38_xt_invalid
set r10 0
label x01_38_xt_lookup
cmp r10 r6
jge x01_38_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_38_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_38_xt_next
set r0 0
label x01_38_xt_compare
cmp r0 r12
jge x01_38_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_38_xt_next
add r0 1
jmp x01_38_xt_compare
label x01_38_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_38_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_38_xt_correct
jmp x01_38_xt_clean
label x01_38_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_38_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_38_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_38_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_38_xt_clean
label x01_38_xt_next
add r10 1
jmp x01_38_xt_lookup
label x01_38_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_38_xt_invalid
cmp r6 128
jge x01_38_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_38_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_38_xt_invalid
add r0 1
cmp r0 96
jlt x01_38_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_38_xt_copy
cmp r0 r12
jge x01_38_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_38_xt_copy
label x01_38_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_38_xt_clean
set r0 16
label x01_38_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_38_xt_clean_mailbox
set r0 256
label x01_38_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_38_xt_clean_scratch
jmp x01_lesson_39
label x01_38_xt_invalid
div r0 0

label x01_38_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_38_xtn_done
cmp r9 255
jgt x01_38_xtn_done
label x01_38_xtn_each
cmp r0 r9
jge x01_38_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_38_xtn_inverted
cmp r3 195
je x01_38_xtn_accent
cmp r3 226
je x01_38_xtn_unicode_space
cmp r3 32
je x01_38_xtn_space
cmp r3 44
je x01_38_xtn_space
cmp r3 46
je x01_38_xtn_space
cmp r3 33
je x01_38_xtn_space
cmp r3 63
je x01_38_xtn_space
cmp r3 65
jlt x01_38_xtn_ascii
cmp r3 90
jgt x01_38_xtn_ascii
add r3 32
label x01_38_xtn_ascii
cmp r3 97
jlt x01_38_xtn_digit
cmp r3 122
jle x01_38_xtn_append
label x01_38_xtn_digit
cmp r3 48
jlt x01_38_xtn_done
cmp r3 57
jgt x01_38_xtn_done
jmp x01_38_xtn_append
label x01_38_xtn_inverted
add r0 1
cmp r0 r9
jge x01_38_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_38_xtn_space
cmp r3 191
je x01_38_xtn_space
cmp r3 161
je x01_38_xtn_space
jmp x01_38_xtn_done
label x01_38_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_38_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_38_xtn_done
add r0 1
cmp r0 r9
jge x01_38_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_38_xtn_space
cmp r3 175
je x01_38_xtn_space
jmp x01_38_xtn_done
label x01_38_xtn_accent
add r0 1
cmp r0 r9
jge x01_38_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_38_xtn_a
cmp r3 161
je x01_38_xtn_a
cmp r3 137
je x01_38_xtn_e
cmp r3 169
je x01_38_xtn_e
cmp r3 141
je x01_38_xtn_i
cmp r3 173
je x01_38_xtn_i
cmp r3 147
je x01_38_xtn_o
cmp r3 179
je x01_38_xtn_o
cmp r3 154
je x01_38_xtn_u
cmp r3 186
je x01_38_xtn_u
cmp r3 145
je x01_38_xtn_n
cmp r3 177
je x01_38_xtn_n
jmp x01_38_xtn_done
label x01_38_xtn_a
set r3 97
jmp x01_38_xtn_append
label x01_38_xtn_e
set r3 101
jmp x01_38_xtn_append
label x01_38_xtn_i
set r3 105
jmp x01_38_xtn_append
label x01_38_xtn_o
set r3 111
jmp x01_38_xtn_append
label x01_38_xtn_u
set r3 117
jmp x01_38_xtn_append
label x01_38_xtn_n
set r3 110
jmp x01_38_xtn_append
label x01_38_xtn_space
cmp r1 0
je x01_38_xtn_next
set r2 1
jmp x01_38_xtn_next
label x01_38_xtn_append
cmp r2 0
je x01_38_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_38_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_38_xtn_next
add r0 1
jmp x01_38_xtn_each
label x01_38_xtn_valid
cmp r1 0
je x01_38_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_38_xtn_done
jmp x01_38_xt_normalized

label x01_lesson_39
store8 9050000000000000016 1
store8 9050000000000000017 12
store8 9050000000000000018 0
store8 9050000000000000019 13
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 110
store8 9050000000000000273 111
store8 9050000000000000274 32
store8 9050000000000000275 113
store8 9050000000000000276 117
store8 9050000000000000277 105
store8 9050000000000000278 101
store8 9050000000000000279 114
store8 9050000000000000280 111
store8 9050000000000000281 32
store8 9050000000000000282 101
store8 9050000000000000283 115
store8 9050000000000000284 111
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_39_xt_blank
cmp r0 88
jne x01_39_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_39_xt_invalid
jmp x01_39_xt_validate
label x01_39_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_39_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_39_xt_invalid
add r0 1
cmp r0 16
jlt x01_39_xt_blank_header
set r0 32
label x01_39_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_39_xt_invalid
add r0 1
cmp r0 144
jlt x01_39_xt_blank_context
set r0 4096
label x01_39_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_39_xt_invalid
add r0 1
cmp r0 16384
jlt x01_39_xt_blank_bank
label x01_39_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_39_xt_invalid
cmp r0 0
je x01_39_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_39_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_39_xt_invalid
cmp r0 17
jgt x01_39_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_39_xt_invalid
label x01_39_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_39_xt_invalid
cmp r0 4
jgt x01_39_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_39_xt_invalid
cmp r0 1
jne x01_39_xt_modifier
cmp r1 1
jlt x01_39_xt_invalid
cmp r1 17
jgt x01_39_xt_invalid
jmp x01_39_xt_prepare
label x01_39_xt_modifier
cmp r1 0
jne x01_39_xt_invalid
cmp r2 0
jne x01_39_xt_invalid
label x01_39_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_39_xtn_begin
label x01_39_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_39_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_39_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_39_xt_invalid
set r10 0
label x01_39_xt_lookup
cmp r10 r6
jge x01_39_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_39_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_39_xt_next
set r0 0
label x01_39_xt_compare
cmp r0 r12
jge x01_39_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_39_xt_next
add r0 1
jmp x01_39_xt_compare
label x01_39_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_39_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_39_xt_correct
jmp x01_39_xt_clean
label x01_39_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_39_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_39_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_39_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_39_xt_clean
label x01_39_xt_next
add r10 1
jmp x01_39_xt_lookup
label x01_39_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_39_xt_invalid
cmp r6 128
jge x01_39_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_39_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_39_xt_invalid
add r0 1
cmp r0 96
jlt x01_39_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_39_xt_copy
cmp r0 r12
jge x01_39_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_39_xt_copy
label x01_39_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_39_xt_clean
set r0 16
label x01_39_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_39_xt_clean_mailbox
set r0 256
label x01_39_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_39_xt_clean_scratch
jmp x01_lesson_40
label x01_39_xt_invalid
div r0 0

label x01_39_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_39_xtn_done
cmp r9 255
jgt x01_39_xtn_done
label x01_39_xtn_each
cmp r0 r9
jge x01_39_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_39_xtn_inverted
cmp r3 195
je x01_39_xtn_accent
cmp r3 226
je x01_39_xtn_unicode_space
cmp r3 32
je x01_39_xtn_space
cmp r3 44
je x01_39_xtn_space
cmp r3 46
je x01_39_xtn_space
cmp r3 33
je x01_39_xtn_space
cmp r3 63
je x01_39_xtn_space
cmp r3 65
jlt x01_39_xtn_ascii
cmp r3 90
jgt x01_39_xtn_ascii
add r3 32
label x01_39_xtn_ascii
cmp r3 97
jlt x01_39_xtn_digit
cmp r3 122
jle x01_39_xtn_append
label x01_39_xtn_digit
cmp r3 48
jlt x01_39_xtn_done
cmp r3 57
jgt x01_39_xtn_done
jmp x01_39_xtn_append
label x01_39_xtn_inverted
add r0 1
cmp r0 r9
jge x01_39_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_39_xtn_space
cmp r3 191
je x01_39_xtn_space
cmp r3 161
je x01_39_xtn_space
jmp x01_39_xtn_done
label x01_39_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_39_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_39_xtn_done
add r0 1
cmp r0 r9
jge x01_39_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_39_xtn_space
cmp r3 175
je x01_39_xtn_space
jmp x01_39_xtn_done
label x01_39_xtn_accent
add r0 1
cmp r0 r9
jge x01_39_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_39_xtn_a
cmp r3 161
je x01_39_xtn_a
cmp r3 137
je x01_39_xtn_e
cmp r3 169
je x01_39_xtn_e
cmp r3 141
je x01_39_xtn_i
cmp r3 173
je x01_39_xtn_i
cmp r3 147
je x01_39_xtn_o
cmp r3 179
je x01_39_xtn_o
cmp r3 154
je x01_39_xtn_u
cmp r3 186
je x01_39_xtn_u
cmp r3 145
je x01_39_xtn_n
cmp r3 177
je x01_39_xtn_n
jmp x01_39_xtn_done
label x01_39_xtn_a
set r3 97
jmp x01_39_xtn_append
label x01_39_xtn_e
set r3 101
jmp x01_39_xtn_append
label x01_39_xtn_i
set r3 105
jmp x01_39_xtn_append
label x01_39_xtn_o
set r3 111
jmp x01_39_xtn_append
label x01_39_xtn_u
set r3 117
jmp x01_39_xtn_append
label x01_39_xtn_n
set r3 110
jmp x01_39_xtn_append
label x01_39_xtn_space
cmp r1 0
je x01_39_xtn_next
set r2 1
jmp x01_39_xtn_next
label x01_39_xtn_append
cmp r2 0
je x01_39_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_39_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_39_xtn_next
add r0 1
jmp x01_39_xtn_each
label x01_39_xtn_valid
cmp r1 0
je x01_39_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_39_xtn_done
jmp x01_39_xt_normalized

label x01_lesson_40
store8 9050000000000000016 1
store8 9050000000000000017 12
store8 9050000000000000018 0
store8 9050000000000000019 16
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 110
store8 9050000000000000273 111
store8 9050000000000000274 32
store8 9050000000000000275 109
store8 9050000000000000276 101
store8 9050000000000000277 32
store8 9050000000000000278 101
store8 9050000000000000279 110
store8 9050000000000000280 116
store8 9050000000000000281 101
store8 9050000000000000282 110
store8 9050000000000000283 100
store8 9050000000000000284 105
store8 9050000000000000285 115
store8 9050000000000000286 116
store8 9050000000000000287 101
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_40_xt_blank
cmp r0 88
jne x01_40_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_40_xt_invalid
jmp x01_40_xt_validate
label x01_40_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_40_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_40_xt_invalid
add r0 1
cmp r0 16
jlt x01_40_xt_blank_header
set r0 32
label x01_40_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_40_xt_invalid
add r0 1
cmp r0 144
jlt x01_40_xt_blank_context
set r0 4096
label x01_40_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_40_xt_invalid
add r0 1
cmp r0 16384
jlt x01_40_xt_blank_bank
label x01_40_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_40_xt_invalid
cmp r0 0
je x01_40_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_40_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_40_xt_invalid
cmp r0 17
jgt x01_40_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_40_xt_invalid
label x01_40_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_40_xt_invalid
cmp r0 4
jgt x01_40_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_40_xt_invalid
cmp r0 1
jne x01_40_xt_modifier
cmp r1 1
jlt x01_40_xt_invalid
cmp r1 17
jgt x01_40_xt_invalid
jmp x01_40_xt_prepare
label x01_40_xt_modifier
cmp r1 0
jne x01_40_xt_invalid
cmp r2 0
jne x01_40_xt_invalid
label x01_40_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_40_xtn_begin
label x01_40_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_40_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_40_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_40_xt_invalid
set r10 0
label x01_40_xt_lookup
cmp r10 r6
jge x01_40_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_40_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_40_xt_next
set r0 0
label x01_40_xt_compare
cmp r0 r12
jge x01_40_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_40_xt_next
add r0 1
jmp x01_40_xt_compare
label x01_40_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_40_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_40_xt_correct
jmp x01_40_xt_clean
label x01_40_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_40_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_40_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_40_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_40_xt_clean
label x01_40_xt_next
add r10 1
jmp x01_40_xt_lookup
label x01_40_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_40_xt_invalid
cmp r6 128
jge x01_40_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_40_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_40_xt_invalid
add r0 1
cmp r0 96
jlt x01_40_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_40_xt_copy
cmp r0 r12
jge x01_40_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_40_xt_copy
label x01_40_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_40_xt_clean
set r0 16
label x01_40_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_40_xt_clean_mailbox
set r0 256
label x01_40_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_40_xt_clean_scratch
jmp x01_lesson_41
label x01_40_xt_invalid
div r0 0

label x01_40_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_40_xtn_done
cmp r9 255
jgt x01_40_xtn_done
label x01_40_xtn_each
cmp r0 r9
jge x01_40_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_40_xtn_inverted
cmp r3 195
je x01_40_xtn_accent
cmp r3 226
je x01_40_xtn_unicode_space
cmp r3 32
je x01_40_xtn_space
cmp r3 44
je x01_40_xtn_space
cmp r3 46
je x01_40_xtn_space
cmp r3 33
je x01_40_xtn_space
cmp r3 63
je x01_40_xtn_space
cmp r3 65
jlt x01_40_xtn_ascii
cmp r3 90
jgt x01_40_xtn_ascii
add r3 32
label x01_40_xtn_ascii
cmp r3 97
jlt x01_40_xtn_digit
cmp r3 122
jle x01_40_xtn_append
label x01_40_xtn_digit
cmp r3 48
jlt x01_40_xtn_done
cmp r3 57
jgt x01_40_xtn_done
jmp x01_40_xtn_append
label x01_40_xtn_inverted
add r0 1
cmp r0 r9
jge x01_40_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_40_xtn_space
cmp r3 191
je x01_40_xtn_space
cmp r3 161
je x01_40_xtn_space
jmp x01_40_xtn_done
label x01_40_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_40_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_40_xtn_done
add r0 1
cmp r0 r9
jge x01_40_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_40_xtn_space
cmp r3 175
je x01_40_xtn_space
jmp x01_40_xtn_done
label x01_40_xtn_accent
add r0 1
cmp r0 r9
jge x01_40_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_40_xtn_a
cmp r3 161
je x01_40_xtn_a
cmp r3 137
je x01_40_xtn_e
cmp r3 169
je x01_40_xtn_e
cmp r3 141
je x01_40_xtn_i
cmp r3 173
je x01_40_xtn_i
cmp r3 147
je x01_40_xtn_o
cmp r3 179
je x01_40_xtn_o
cmp r3 154
je x01_40_xtn_u
cmp r3 186
je x01_40_xtn_u
cmp r3 145
je x01_40_xtn_n
cmp r3 177
je x01_40_xtn_n
jmp x01_40_xtn_done
label x01_40_xtn_a
set r3 97
jmp x01_40_xtn_append
label x01_40_xtn_e
set r3 101
jmp x01_40_xtn_append
label x01_40_xtn_i
set r3 105
jmp x01_40_xtn_append
label x01_40_xtn_o
set r3 111
jmp x01_40_xtn_append
label x01_40_xtn_u
set r3 117
jmp x01_40_xtn_append
label x01_40_xtn_n
set r3 110
jmp x01_40_xtn_append
label x01_40_xtn_space
cmp r1 0
je x01_40_xtn_next
set r2 1
jmp x01_40_xtn_next
label x01_40_xtn_append
cmp r2 0
je x01_40_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_40_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_40_xtn_next
add r0 1
jmp x01_40_xtn_each
label x01_40_xtn_valid
cmp r1 0
je x01_40_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_40_xtn_done
jmp x01_40_xt_normalized

label x01_lesson_41
store8 9050000000000000016 1
store8 9050000000000000017 13
store8 9050000000000000018 1
store8 9050000000000000019 17
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 110
store8 9050000000000000273 111
store8 9050000000000000274 32
store8 9050000000000000275 109
store8 9050000000000000276 101
store8 9050000000000000277 32
store8 9050000000000000278 115
store8 9050000000000000279 97
store8 9050000000000000280 108
store8 9050000000000000281 101
store8 9050000000000000282 32
store8 9050000000000000283 101
store8 9050000000000000284 108
store8 9050000000000000285 32
store8 9050000000000000286 97
store8 9050000000000000287 112
store8 9050000000000000288 107
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_41_xt_blank
cmp r0 88
jne x01_41_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_41_xt_invalid
jmp x01_41_xt_validate
label x01_41_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_41_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_41_xt_invalid
add r0 1
cmp r0 16
jlt x01_41_xt_blank_header
set r0 32
label x01_41_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_41_xt_invalid
add r0 1
cmp r0 144
jlt x01_41_xt_blank_context
set r0 4096
label x01_41_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_41_xt_invalid
add r0 1
cmp r0 16384
jlt x01_41_xt_blank_bank
label x01_41_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_41_xt_invalid
cmp r0 0
je x01_41_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_41_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_41_xt_invalid
cmp r0 17
jgt x01_41_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_41_xt_invalid
label x01_41_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_41_xt_invalid
cmp r0 4
jgt x01_41_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_41_xt_invalid
cmp r0 1
jne x01_41_xt_modifier
cmp r1 1
jlt x01_41_xt_invalid
cmp r1 17
jgt x01_41_xt_invalid
jmp x01_41_xt_prepare
label x01_41_xt_modifier
cmp r1 0
jne x01_41_xt_invalid
cmp r2 0
jne x01_41_xt_invalid
label x01_41_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_41_xtn_begin
label x01_41_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_41_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_41_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_41_xt_invalid
set r10 0
label x01_41_xt_lookup
cmp r10 r6
jge x01_41_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_41_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_41_xt_next
set r0 0
label x01_41_xt_compare
cmp r0 r12
jge x01_41_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_41_xt_next
add r0 1
jmp x01_41_xt_compare
label x01_41_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_41_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_41_xt_correct
jmp x01_41_xt_clean
label x01_41_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_41_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_41_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_41_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_41_xt_clean
label x01_41_xt_next
add r10 1
jmp x01_41_xt_lookup
label x01_41_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_41_xt_invalid
cmp r6 128
jge x01_41_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_41_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_41_xt_invalid
add r0 1
cmp r0 96
jlt x01_41_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_41_xt_copy
cmp r0 r12
jge x01_41_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_41_xt_copy
label x01_41_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_41_xt_clean
set r0 16
label x01_41_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_41_xt_clean_mailbox
set r0 256
label x01_41_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_41_xt_clean_scratch
jmp x01_lesson_42
label x01_41_xt_invalid
div r0 0

label x01_41_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_41_xtn_done
cmp r9 255
jgt x01_41_xtn_done
label x01_41_xtn_each
cmp r0 r9
jge x01_41_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_41_xtn_inverted
cmp r3 195
je x01_41_xtn_accent
cmp r3 226
je x01_41_xtn_unicode_space
cmp r3 32
je x01_41_xtn_space
cmp r3 44
je x01_41_xtn_space
cmp r3 46
je x01_41_xtn_space
cmp r3 33
je x01_41_xtn_space
cmp r3 63
je x01_41_xtn_space
cmp r3 65
jlt x01_41_xtn_ascii
cmp r3 90
jgt x01_41_xtn_ascii
add r3 32
label x01_41_xtn_ascii
cmp r3 97
jlt x01_41_xtn_digit
cmp r3 122
jle x01_41_xtn_append
label x01_41_xtn_digit
cmp r3 48
jlt x01_41_xtn_done
cmp r3 57
jgt x01_41_xtn_done
jmp x01_41_xtn_append
label x01_41_xtn_inverted
add r0 1
cmp r0 r9
jge x01_41_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_41_xtn_space
cmp r3 191
je x01_41_xtn_space
cmp r3 161
je x01_41_xtn_space
jmp x01_41_xtn_done
label x01_41_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_41_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_41_xtn_done
add r0 1
cmp r0 r9
jge x01_41_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_41_xtn_space
cmp r3 175
je x01_41_xtn_space
jmp x01_41_xtn_done
label x01_41_xtn_accent
add r0 1
cmp r0 r9
jge x01_41_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_41_xtn_a
cmp r3 161
je x01_41_xtn_a
cmp r3 137
je x01_41_xtn_e
cmp r3 169
je x01_41_xtn_e
cmp r3 141
je x01_41_xtn_i
cmp r3 173
je x01_41_xtn_i
cmp r3 147
je x01_41_xtn_o
cmp r3 179
je x01_41_xtn_o
cmp r3 154
je x01_41_xtn_u
cmp r3 186
je x01_41_xtn_u
cmp r3 145
je x01_41_xtn_n
cmp r3 177
je x01_41_xtn_n
jmp x01_41_xtn_done
label x01_41_xtn_a
set r3 97
jmp x01_41_xtn_append
label x01_41_xtn_e
set r3 101
jmp x01_41_xtn_append
label x01_41_xtn_i
set r3 105
jmp x01_41_xtn_append
label x01_41_xtn_o
set r3 111
jmp x01_41_xtn_append
label x01_41_xtn_u
set r3 117
jmp x01_41_xtn_append
label x01_41_xtn_n
set r3 110
jmp x01_41_xtn_append
label x01_41_xtn_space
cmp r1 0
je x01_41_xtn_next
set r2 1
jmp x01_41_xtn_next
label x01_41_xtn_append
cmp r2 0
je x01_41_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_41_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_41_xtn_next
add r0 1
jmp x01_41_xtn_each
label x01_41_xtn_valid
cmp r1 0
je x01_41_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_41_xtn_done
jmp x01_41_xt_normalized

label x01_lesson_42
store8 9050000000000000016 1
store8 9050000000000000017 13
store8 9050000000000000018 1
store8 9050000000000000019 20
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 109
store8 9050000000000000273 101
store8 9050000000000000274 32
store8 9050000000000000275 100
store8 9050000000000000276 105
store8 9050000000000000277 99
store8 9050000000000000278 101
store8 9050000000000000279 32
store8 9050000000000000280 97
store8 9050000000000000281 112
store8 9050000000000000282 107
store8 9050000000000000283 32
store8 9050000000000000284 110
store8 9050000000000000285 111
store8 9050000000000000286 32
store8 9050000000000000287 102
store8 9050000000000000288 111
store8 9050000000000000289 117
store8 9050000000000000290 110
store8 9050000000000000291 100
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_42_xt_blank
cmp r0 88
jne x01_42_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_42_xt_invalid
jmp x01_42_xt_validate
label x01_42_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_42_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_42_xt_invalid
add r0 1
cmp r0 16
jlt x01_42_xt_blank_header
set r0 32
label x01_42_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_42_xt_invalid
add r0 1
cmp r0 144
jlt x01_42_xt_blank_context
set r0 4096
label x01_42_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_42_xt_invalid
add r0 1
cmp r0 16384
jlt x01_42_xt_blank_bank
label x01_42_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_42_xt_invalid
cmp r0 0
je x01_42_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_42_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_42_xt_invalid
cmp r0 17
jgt x01_42_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_42_xt_invalid
label x01_42_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_42_xt_invalid
cmp r0 4
jgt x01_42_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_42_xt_invalid
cmp r0 1
jne x01_42_xt_modifier
cmp r1 1
jlt x01_42_xt_invalid
cmp r1 17
jgt x01_42_xt_invalid
jmp x01_42_xt_prepare
label x01_42_xt_modifier
cmp r1 0
jne x01_42_xt_invalid
cmp r2 0
jne x01_42_xt_invalid
label x01_42_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_42_xtn_begin
label x01_42_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_42_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_42_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_42_xt_invalid
set r10 0
label x01_42_xt_lookup
cmp r10 r6
jge x01_42_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_42_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_42_xt_next
set r0 0
label x01_42_xt_compare
cmp r0 r12
jge x01_42_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_42_xt_next
add r0 1
jmp x01_42_xt_compare
label x01_42_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_42_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_42_xt_correct
jmp x01_42_xt_clean
label x01_42_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_42_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_42_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_42_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_42_xt_clean
label x01_42_xt_next
add r10 1
jmp x01_42_xt_lookup
label x01_42_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_42_xt_invalid
cmp r6 128
jge x01_42_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_42_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_42_xt_invalid
add r0 1
cmp r0 96
jlt x01_42_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_42_xt_copy
cmp r0 r12
jge x01_42_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_42_xt_copy
label x01_42_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_42_xt_clean
set r0 16
label x01_42_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_42_xt_clean_mailbox
set r0 256
label x01_42_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_42_xt_clean_scratch
jmp x01_lesson_43
label x01_42_xt_invalid
div r0 0

label x01_42_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_42_xtn_done
cmp r9 255
jgt x01_42_xtn_done
label x01_42_xtn_each
cmp r0 r9
jge x01_42_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_42_xtn_inverted
cmp r3 195
je x01_42_xtn_accent
cmp r3 226
je x01_42_xtn_unicode_space
cmp r3 32
je x01_42_xtn_space
cmp r3 44
je x01_42_xtn_space
cmp r3 46
je x01_42_xtn_space
cmp r3 33
je x01_42_xtn_space
cmp r3 63
je x01_42_xtn_space
cmp r3 65
jlt x01_42_xtn_ascii
cmp r3 90
jgt x01_42_xtn_ascii
add r3 32
label x01_42_xtn_ascii
cmp r3 97
jlt x01_42_xtn_digit
cmp r3 122
jle x01_42_xtn_append
label x01_42_xtn_digit
cmp r3 48
jlt x01_42_xtn_done
cmp r3 57
jgt x01_42_xtn_done
jmp x01_42_xtn_append
label x01_42_xtn_inverted
add r0 1
cmp r0 r9
jge x01_42_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_42_xtn_space
cmp r3 191
je x01_42_xtn_space
cmp r3 161
je x01_42_xtn_space
jmp x01_42_xtn_done
label x01_42_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_42_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_42_xtn_done
add r0 1
cmp r0 r9
jge x01_42_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_42_xtn_space
cmp r3 175
je x01_42_xtn_space
jmp x01_42_xtn_done
label x01_42_xtn_accent
add r0 1
cmp r0 r9
jge x01_42_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_42_xtn_a
cmp r3 161
je x01_42_xtn_a
cmp r3 137
je x01_42_xtn_e
cmp r3 169
je x01_42_xtn_e
cmp r3 141
je x01_42_xtn_i
cmp r3 173
je x01_42_xtn_i
cmp r3 147
je x01_42_xtn_o
cmp r3 179
je x01_42_xtn_o
cmp r3 154
je x01_42_xtn_u
cmp r3 186
je x01_42_xtn_u
cmp r3 145
je x01_42_xtn_n
cmp r3 177
je x01_42_xtn_n
jmp x01_42_xtn_done
label x01_42_xtn_a
set r3 97
jmp x01_42_xtn_append
label x01_42_xtn_e
set r3 101
jmp x01_42_xtn_append
label x01_42_xtn_i
set r3 105
jmp x01_42_xtn_append
label x01_42_xtn_o
set r3 111
jmp x01_42_xtn_append
label x01_42_xtn_u
set r3 117
jmp x01_42_xtn_append
label x01_42_xtn_n
set r3 110
jmp x01_42_xtn_append
label x01_42_xtn_space
cmp r1 0
je x01_42_xtn_next
set r2 1
jmp x01_42_xtn_next
label x01_42_xtn_append
cmp r2 0
je x01_42_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_42_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_42_xtn_next
add r0 1
jmp x01_42_xtn_each
label x01_42_xtn_valid
cmp r1 0
je x01_42_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_42_xtn_done
jmp x01_42_xt_normalized

label x01_lesson_43
store8 9050000000000000016 1
store8 9050000000000000017 13
store8 9050000000000000018 1
store8 9050000000000000019 8
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 121
store8 9050000000000000273 32
store8 9050000000000000274 101
store8 9050000000000000275 108
store8 9050000000000000276 32
store8 9050000000000000277 97
store8 9050000000000000278 112
store8 9050000000000000279 107
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_43_xt_blank
cmp r0 88
jne x01_43_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_43_xt_invalid
jmp x01_43_xt_validate
label x01_43_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_43_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_43_xt_invalid
add r0 1
cmp r0 16
jlt x01_43_xt_blank_header
set r0 32
label x01_43_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_43_xt_invalid
add r0 1
cmp r0 144
jlt x01_43_xt_blank_context
set r0 4096
label x01_43_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_43_xt_invalid
add r0 1
cmp r0 16384
jlt x01_43_xt_blank_bank
label x01_43_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_43_xt_invalid
cmp r0 0
je x01_43_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_43_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_43_xt_invalid
cmp r0 17
jgt x01_43_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_43_xt_invalid
label x01_43_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_43_xt_invalid
cmp r0 4
jgt x01_43_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_43_xt_invalid
cmp r0 1
jne x01_43_xt_modifier
cmp r1 1
jlt x01_43_xt_invalid
cmp r1 17
jgt x01_43_xt_invalid
jmp x01_43_xt_prepare
label x01_43_xt_modifier
cmp r1 0
jne x01_43_xt_invalid
cmp r2 0
jne x01_43_xt_invalid
label x01_43_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_43_xtn_begin
label x01_43_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_43_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_43_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_43_xt_invalid
set r10 0
label x01_43_xt_lookup
cmp r10 r6
jge x01_43_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_43_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_43_xt_next
set r0 0
label x01_43_xt_compare
cmp r0 r12
jge x01_43_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_43_xt_next
add r0 1
jmp x01_43_xt_compare
label x01_43_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_43_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_43_xt_correct
jmp x01_43_xt_clean
label x01_43_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_43_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_43_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_43_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_43_xt_clean
label x01_43_xt_next
add r10 1
jmp x01_43_xt_lookup
label x01_43_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_43_xt_invalid
cmp r6 128
jge x01_43_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_43_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_43_xt_invalid
add r0 1
cmp r0 96
jlt x01_43_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_43_xt_copy
cmp r0 r12
jge x01_43_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_43_xt_copy
label x01_43_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_43_xt_clean
set r0 16
label x01_43_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_43_xt_clean_mailbox
set r0 256
label x01_43_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_43_xt_clean_scratch
jmp x01_lesson_44
label x01_43_xt_invalid
div r0 0

label x01_43_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_43_xtn_done
cmp r9 255
jgt x01_43_xtn_done
label x01_43_xtn_each
cmp r0 r9
jge x01_43_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_43_xtn_inverted
cmp r3 195
je x01_43_xtn_accent
cmp r3 226
je x01_43_xtn_unicode_space
cmp r3 32
je x01_43_xtn_space
cmp r3 44
je x01_43_xtn_space
cmp r3 46
je x01_43_xtn_space
cmp r3 33
je x01_43_xtn_space
cmp r3 63
je x01_43_xtn_space
cmp r3 65
jlt x01_43_xtn_ascii
cmp r3 90
jgt x01_43_xtn_ascii
add r3 32
label x01_43_xtn_ascii
cmp r3 97
jlt x01_43_xtn_digit
cmp r3 122
jle x01_43_xtn_append
label x01_43_xtn_digit
cmp r3 48
jlt x01_43_xtn_done
cmp r3 57
jgt x01_43_xtn_done
jmp x01_43_xtn_append
label x01_43_xtn_inverted
add r0 1
cmp r0 r9
jge x01_43_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_43_xtn_space
cmp r3 191
je x01_43_xtn_space
cmp r3 161
je x01_43_xtn_space
jmp x01_43_xtn_done
label x01_43_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_43_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_43_xtn_done
add r0 1
cmp r0 r9
jge x01_43_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_43_xtn_space
cmp r3 175
je x01_43_xtn_space
jmp x01_43_xtn_done
label x01_43_xtn_accent
add r0 1
cmp r0 r9
jge x01_43_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_43_xtn_a
cmp r3 161
je x01_43_xtn_a
cmp r3 137
je x01_43_xtn_e
cmp r3 169
je x01_43_xtn_e
cmp r3 141
je x01_43_xtn_i
cmp r3 173
je x01_43_xtn_i
cmp r3 147
je x01_43_xtn_o
cmp r3 179
je x01_43_xtn_o
cmp r3 154
je x01_43_xtn_u
cmp r3 186
je x01_43_xtn_u
cmp r3 145
je x01_43_xtn_n
cmp r3 177
je x01_43_xtn_n
jmp x01_43_xtn_done
label x01_43_xtn_a
set r3 97
jmp x01_43_xtn_append
label x01_43_xtn_e
set r3 101
jmp x01_43_xtn_append
label x01_43_xtn_i
set r3 105
jmp x01_43_xtn_append
label x01_43_xtn_o
set r3 111
jmp x01_43_xtn_append
label x01_43_xtn_u
set r3 117
jmp x01_43_xtn_append
label x01_43_xtn_n
set r3 110
jmp x01_43_xtn_append
label x01_43_xtn_space
cmp r1 0
je x01_43_xtn_next
set r2 1
jmp x01_43_xtn_next
label x01_43_xtn_append
cmp r2 0
je x01_43_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_43_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_43_xtn_next
add r0 1
jmp x01_43_xtn_each
label x01_43_xtn_valid
cmp r1 0
je x01_43_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_43_xtn_done
jmp x01_43_xt_normalized

label x01_lesson_44
store8 9050000000000000016 1
store8 9050000000000000017 14
store8 9050000000000000018 1
store8 9050000000000000019 29
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 121
store8 9050000000000000273 97
store8 9050000000000000274 32
store8 9050000000000000275 108
store8 9050000000000000276 111
store8 9050000000000000277 32
store8 9050000000000000278 105
store8 9050000000000000279 110
store8 9050000000000000280 116
store8 9050000000000000281 101
store8 9050000000000000282 103
store8 9050000000000000283 114
store8 9050000000000000284 97
store8 9050000000000000285 115
store8 9050000000000000286 116
store8 9050000000000000287 101
store8 9050000000000000288 32
store8 9050000000000000289 97
store8 9050000000000000290 108
store8 9050000000000000291 97
store8 9050000000000000292 32
store8 9050000000000000293 105
store8 9050000000000000294 110
store8 9050000000000000295 116
store8 9050000000000000296 101
store8 9050000000000000297 114
store8 9050000000000000298 102
store8 9050000000000000299 97
store8 9050000000000000300 122
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_44_xt_blank
cmp r0 88
jne x01_44_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_44_xt_invalid
jmp x01_44_xt_validate
label x01_44_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_44_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_44_xt_invalid
add r0 1
cmp r0 16
jlt x01_44_xt_blank_header
set r0 32
label x01_44_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_44_xt_invalid
add r0 1
cmp r0 144
jlt x01_44_xt_blank_context
set r0 4096
label x01_44_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_44_xt_invalid
add r0 1
cmp r0 16384
jlt x01_44_xt_blank_bank
label x01_44_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_44_xt_invalid
cmp r0 0
je x01_44_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_44_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_44_xt_invalid
cmp r0 17
jgt x01_44_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_44_xt_invalid
label x01_44_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_44_xt_invalid
cmp r0 4
jgt x01_44_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_44_xt_invalid
cmp r0 1
jne x01_44_xt_modifier
cmp r1 1
jlt x01_44_xt_invalid
cmp r1 17
jgt x01_44_xt_invalid
jmp x01_44_xt_prepare
label x01_44_xt_modifier
cmp r1 0
jne x01_44_xt_invalid
cmp r2 0
jne x01_44_xt_invalid
label x01_44_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_44_xtn_begin
label x01_44_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_44_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_44_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_44_xt_invalid
set r10 0
label x01_44_xt_lookup
cmp r10 r6
jge x01_44_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_44_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_44_xt_next
set r0 0
label x01_44_xt_compare
cmp r0 r12
jge x01_44_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_44_xt_next
add r0 1
jmp x01_44_xt_compare
label x01_44_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_44_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_44_xt_correct
jmp x01_44_xt_clean
label x01_44_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_44_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_44_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_44_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_44_xt_clean
label x01_44_xt_next
add r10 1
jmp x01_44_xt_lookup
label x01_44_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_44_xt_invalid
cmp r6 128
jge x01_44_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_44_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_44_xt_invalid
add r0 1
cmp r0 96
jlt x01_44_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_44_xt_copy
cmp r0 r12
jge x01_44_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_44_xt_copy
label x01_44_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_44_xt_clean
set r0 16
label x01_44_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_44_xt_clean_mailbox
set r0 256
label x01_44_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_44_xt_clean_scratch
jmp x01_lesson_45
label x01_44_xt_invalid
div r0 0

label x01_44_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_44_xtn_done
cmp r9 255
jgt x01_44_xtn_done
label x01_44_xtn_each
cmp r0 r9
jge x01_44_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_44_xtn_inverted
cmp r3 195
je x01_44_xtn_accent
cmp r3 226
je x01_44_xtn_unicode_space
cmp r3 32
je x01_44_xtn_space
cmp r3 44
je x01_44_xtn_space
cmp r3 46
je x01_44_xtn_space
cmp r3 33
je x01_44_xtn_space
cmp r3 63
je x01_44_xtn_space
cmp r3 65
jlt x01_44_xtn_ascii
cmp r3 90
jgt x01_44_xtn_ascii
add r3 32
label x01_44_xtn_ascii
cmp r3 97
jlt x01_44_xtn_digit
cmp r3 122
jle x01_44_xtn_append
label x01_44_xtn_digit
cmp r3 48
jlt x01_44_xtn_done
cmp r3 57
jgt x01_44_xtn_done
jmp x01_44_xtn_append
label x01_44_xtn_inverted
add r0 1
cmp r0 r9
jge x01_44_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_44_xtn_space
cmp r3 191
je x01_44_xtn_space
cmp r3 161
je x01_44_xtn_space
jmp x01_44_xtn_done
label x01_44_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_44_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_44_xtn_done
add r0 1
cmp r0 r9
jge x01_44_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_44_xtn_space
cmp r3 175
je x01_44_xtn_space
jmp x01_44_xtn_done
label x01_44_xtn_accent
add r0 1
cmp r0 r9
jge x01_44_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_44_xtn_a
cmp r3 161
je x01_44_xtn_a
cmp r3 137
je x01_44_xtn_e
cmp r3 169
je x01_44_xtn_e
cmp r3 141
je x01_44_xtn_i
cmp r3 173
je x01_44_xtn_i
cmp r3 147
je x01_44_xtn_o
cmp r3 179
je x01_44_xtn_o
cmp r3 154
je x01_44_xtn_u
cmp r3 186
je x01_44_xtn_u
cmp r3 145
je x01_44_xtn_n
cmp r3 177
je x01_44_xtn_n
jmp x01_44_xtn_done
label x01_44_xtn_a
set r3 97
jmp x01_44_xtn_append
label x01_44_xtn_e
set r3 101
jmp x01_44_xtn_append
label x01_44_xtn_i
set r3 105
jmp x01_44_xtn_append
label x01_44_xtn_o
set r3 111
jmp x01_44_xtn_append
label x01_44_xtn_u
set r3 117
jmp x01_44_xtn_append
label x01_44_xtn_n
set r3 110
jmp x01_44_xtn_append
label x01_44_xtn_space
cmp r1 0
je x01_44_xtn_next
set r2 1
jmp x01_44_xtn_next
label x01_44_xtn_append
cmp r2 0
je x01_44_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_44_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_44_xtn_next
add r0 1
jmp x01_44_xtn_each
label x01_44_xtn_valid
cmp r1 0
je x01_44_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_44_xtn_done
jmp x01_44_xt_normalized

label x01_lesson_45
store8 9050000000000000016 1
store8 9050000000000000017 14
store8 9050000000000000018 1
store8 9050000000000000019 18
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 105
store8 9050000000000000273 110
store8 9050000000000000274 116
store8 9050000000000000275 101
store8 9050000000000000276 103
store8 9050000000000000277 114
store8 9050000000000000278 97
store8 9050000000000000279 115
store8 9050000000000000280 116
store8 9050000000000000281 101
store8 9050000000000000282 32
store8 9050000000000000283 108
store8 9050000000000000284 97
store8 9050000000000000285 32
store8 9050000000000000286 114
store8 9050000000000000287 97
store8 9050000000000000288 109
store8 9050000000000000289 97
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_45_xt_blank
cmp r0 88
jne x01_45_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_45_xt_invalid
jmp x01_45_xt_validate
label x01_45_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_45_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_45_xt_invalid
add r0 1
cmp r0 16
jlt x01_45_xt_blank_header
set r0 32
label x01_45_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_45_xt_invalid
add r0 1
cmp r0 144
jlt x01_45_xt_blank_context
set r0 4096
label x01_45_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_45_xt_invalid
add r0 1
cmp r0 16384
jlt x01_45_xt_blank_bank
label x01_45_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_45_xt_invalid
cmp r0 0
je x01_45_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_45_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_45_xt_invalid
cmp r0 17
jgt x01_45_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_45_xt_invalid
label x01_45_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_45_xt_invalid
cmp r0 4
jgt x01_45_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_45_xt_invalid
cmp r0 1
jne x01_45_xt_modifier
cmp r1 1
jlt x01_45_xt_invalid
cmp r1 17
jgt x01_45_xt_invalid
jmp x01_45_xt_prepare
label x01_45_xt_modifier
cmp r1 0
jne x01_45_xt_invalid
cmp r2 0
jne x01_45_xt_invalid
label x01_45_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_45_xtn_begin
label x01_45_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_45_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_45_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_45_xt_invalid
set r10 0
label x01_45_xt_lookup
cmp r10 r6
jge x01_45_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_45_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_45_xt_next
set r0 0
label x01_45_xt_compare
cmp r0 r12
jge x01_45_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_45_xt_next
add r0 1
jmp x01_45_xt_compare
label x01_45_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_45_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_45_xt_correct
jmp x01_45_xt_clean
label x01_45_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_45_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_45_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_45_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_45_xt_clean
label x01_45_xt_next
add r10 1
jmp x01_45_xt_lookup
label x01_45_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_45_xt_invalid
cmp r6 128
jge x01_45_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_45_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_45_xt_invalid
add r0 1
cmp r0 96
jlt x01_45_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_45_xt_copy
cmp r0 r12
jge x01_45_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_45_xt_copy
label x01_45_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_45_xt_clean
set r0 16
label x01_45_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_45_xt_clean_mailbox
set r0 256
label x01_45_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_45_xt_clean_scratch
jmp x01_lesson_46
label x01_45_xt_invalid
div r0 0

label x01_45_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_45_xtn_done
cmp r9 255
jgt x01_45_xtn_done
label x01_45_xtn_each
cmp r0 r9
jge x01_45_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_45_xtn_inverted
cmp r3 195
je x01_45_xtn_accent
cmp r3 226
je x01_45_xtn_unicode_space
cmp r3 32
je x01_45_xtn_space
cmp r3 44
je x01_45_xtn_space
cmp r3 46
je x01_45_xtn_space
cmp r3 33
je x01_45_xtn_space
cmp r3 63
je x01_45_xtn_space
cmp r3 65
jlt x01_45_xtn_ascii
cmp r3 90
jgt x01_45_xtn_ascii
add r3 32
label x01_45_xtn_ascii
cmp r3 97
jlt x01_45_xtn_digit
cmp r3 122
jle x01_45_xtn_append
label x01_45_xtn_digit
cmp r3 48
jlt x01_45_xtn_done
cmp r3 57
jgt x01_45_xtn_done
jmp x01_45_xtn_append
label x01_45_xtn_inverted
add r0 1
cmp r0 r9
jge x01_45_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_45_xtn_space
cmp r3 191
je x01_45_xtn_space
cmp r3 161
je x01_45_xtn_space
jmp x01_45_xtn_done
label x01_45_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_45_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_45_xtn_done
add r0 1
cmp r0 r9
jge x01_45_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_45_xtn_space
cmp r3 175
je x01_45_xtn_space
jmp x01_45_xtn_done
label x01_45_xtn_accent
add r0 1
cmp r0 r9
jge x01_45_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_45_xtn_a
cmp r3 161
je x01_45_xtn_a
cmp r3 137
je x01_45_xtn_e
cmp r3 169
je x01_45_xtn_e
cmp r3 141
je x01_45_xtn_i
cmp r3 173
je x01_45_xtn_i
cmp r3 147
je x01_45_xtn_o
cmp r3 179
je x01_45_xtn_o
cmp r3 154
je x01_45_xtn_u
cmp r3 186
je x01_45_xtn_u
cmp r3 145
je x01_45_xtn_n
cmp r3 177
je x01_45_xtn_n
jmp x01_45_xtn_done
label x01_45_xtn_a
set r3 97
jmp x01_45_xtn_append
label x01_45_xtn_e
set r3 101
jmp x01_45_xtn_append
label x01_45_xtn_i
set r3 105
jmp x01_45_xtn_append
label x01_45_xtn_o
set r3 111
jmp x01_45_xtn_append
label x01_45_xtn_u
set r3 117
jmp x01_45_xtn_append
label x01_45_xtn_n
set r3 110
jmp x01_45_xtn_append
label x01_45_xtn_space
cmp r1 0
je x01_45_xtn_next
set r2 1
jmp x01_45_xtn_next
label x01_45_xtn_append
cmp r2 0
je x01_45_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_45_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_45_xtn_next
add r0 1
jmp x01_45_xtn_each
label x01_45_xtn_valid
cmp r1 0
je x01_45_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_45_xtn_done
jmp x01_45_xt_normalized

label x01_lesson_46
store8 9050000000000000016 1
store8 9050000000000000017 15
store8 9050000000000000018 0
store8 9050000000000000019 2
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 120
store8 9050000000000000273 100
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_46_xt_blank
cmp r0 88
jne x01_46_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_46_xt_invalid
jmp x01_46_xt_validate
label x01_46_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_46_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_46_xt_invalid
add r0 1
cmp r0 16
jlt x01_46_xt_blank_header
set r0 32
label x01_46_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_46_xt_invalid
add r0 1
cmp r0 144
jlt x01_46_xt_blank_context
set r0 4096
label x01_46_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_46_xt_invalid
add r0 1
cmp r0 16384
jlt x01_46_xt_blank_bank
label x01_46_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_46_xt_invalid
cmp r0 0
je x01_46_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_46_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_46_xt_invalid
cmp r0 17
jgt x01_46_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_46_xt_invalid
label x01_46_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_46_xt_invalid
cmp r0 4
jgt x01_46_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_46_xt_invalid
cmp r0 1
jne x01_46_xt_modifier
cmp r1 1
jlt x01_46_xt_invalid
cmp r1 17
jgt x01_46_xt_invalid
jmp x01_46_xt_prepare
label x01_46_xt_modifier
cmp r1 0
jne x01_46_xt_invalid
cmp r2 0
jne x01_46_xt_invalid
label x01_46_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_46_xtn_begin
label x01_46_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_46_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_46_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_46_xt_invalid
set r10 0
label x01_46_xt_lookup
cmp r10 r6
jge x01_46_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_46_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_46_xt_next
set r0 0
label x01_46_xt_compare
cmp r0 r12
jge x01_46_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_46_xt_next
add r0 1
jmp x01_46_xt_compare
label x01_46_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_46_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_46_xt_correct
jmp x01_46_xt_clean
label x01_46_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_46_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_46_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_46_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_46_xt_clean
label x01_46_xt_next
add r10 1
jmp x01_46_xt_lookup
label x01_46_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_46_xt_invalid
cmp r6 128
jge x01_46_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_46_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_46_xt_invalid
add r0 1
cmp r0 96
jlt x01_46_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_46_xt_copy
cmp r0 r12
jge x01_46_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_46_xt_copy
label x01_46_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_46_xt_clean
set r0 16
label x01_46_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_46_xt_clean_mailbox
set r0 256
label x01_46_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_46_xt_clean_scratch
jmp x01_lesson_47
label x01_46_xt_invalid
div r0 0

label x01_46_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_46_xtn_done
cmp r9 255
jgt x01_46_xtn_done
label x01_46_xtn_each
cmp r0 r9
jge x01_46_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_46_xtn_inverted
cmp r3 195
je x01_46_xtn_accent
cmp r3 226
je x01_46_xtn_unicode_space
cmp r3 32
je x01_46_xtn_space
cmp r3 44
je x01_46_xtn_space
cmp r3 46
je x01_46_xtn_space
cmp r3 33
je x01_46_xtn_space
cmp r3 63
je x01_46_xtn_space
cmp r3 65
jlt x01_46_xtn_ascii
cmp r3 90
jgt x01_46_xtn_ascii
add r3 32
label x01_46_xtn_ascii
cmp r3 97
jlt x01_46_xtn_digit
cmp r3 122
jle x01_46_xtn_append
label x01_46_xtn_digit
cmp r3 48
jlt x01_46_xtn_done
cmp r3 57
jgt x01_46_xtn_done
jmp x01_46_xtn_append
label x01_46_xtn_inverted
add r0 1
cmp r0 r9
jge x01_46_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_46_xtn_space
cmp r3 191
je x01_46_xtn_space
cmp r3 161
je x01_46_xtn_space
jmp x01_46_xtn_done
label x01_46_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_46_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_46_xtn_done
add r0 1
cmp r0 r9
jge x01_46_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_46_xtn_space
cmp r3 175
je x01_46_xtn_space
jmp x01_46_xtn_done
label x01_46_xtn_accent
add r0 1
cmp r0 r9
jge x01_46_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_46_xtn_a
cmp r3 161
je x01_46_xtn_a
cmp r3 137
je x01_46_xtn_e
cmp r3 169
je x01_46_xtn_e
cmp r3 141
je x01_46_xtn_i
cmp r3 173
je x01_46_xtn_i
cmp r3 147
je x01_46_xtn_o
cmp r3 179
je x01_46_xtn_o
cmp r3 154
je x01_46_xtn_u
cmp r3 186
je x01_46_xtn_u
cmp r3 145
je x01_46_xtn_n
cmp r3 177
je x01_46_xtn_n
jmp x01_46_xtn_done
label x01_46_xtn_a
set r3 97
jmp x01_46_xtn_append
label x01_46_xtn_e
set r3 101
jmp x01_46_xtn_append
label x01_46_xtn_i
set r3 105
jmp x01_46_xtn_append
label x01_46_xtn_o
set r3 111
jmp x01_46_xtn_append
label x01_46_xtn_u
set r3 117
jmp x01_46_xtn_append
label x01_46_xtn_n
set r3 110
jmp x01_46_xtn_append
label x01_46_xtn_space
cmp r1 0
je x01_46_xtn_next
set r2 1
jmp x01_46_xtn_next
label x01_46_xtn_append
cmp r2 0
je x01_46_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_46_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_46_xtn_next
add r0 1
jmp x01_46_xtn_each
label x01_46_xtn_valid
cmp r1 0
je x01_46_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_46_xtn_done
jmp x01_46_xt_normalized

label x01_lesson_47
store8 9050000000000000016 1
store8 9050000000000000017 15
store8 9050000000000000018 0
store8 9050000000000000019 6
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 106
store8 9050000000000000273 97
store8 9050000000000000274 106
store8 9050000000000000275 97
store8 9050000000000000276 106
store8 9050000000000000277 97
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_47_xt_blank
cmp r0 88
jne x01_47_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_47_xt_invalid
jmp x01_47_xt_validate
label x01_47_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_47_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_47_xt_invalid
add r0 1
cmp r0 16
jlt x01_47_xt_blank_header
set r0 32
label x01_47_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_47_xt_invalid
add r0 1
cmp r0 144
jlt x01_47_xt_blank_context
set r0 4096
label x01_47_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_47_xt_invalid
add r0 1
cmp r0 16384
jlt x01_47_xt_blank_bank
label x01_47_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_47_xt_invalid
cmp r0 0
je x01_47_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_47_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_47_xt_invalid
cmp r0 17
jgt x01_47_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_47_xt_invalid
label x01_47_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_47_xt_invalid
cmp r0 4
jgt x01_47_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_47_xt_invalid
cmp r0 1
jne x01_47_xt_modifier
cmp r1 1
jlt x01_47_xt_invalid
cmp r1 17
jgt x01_47_xt_invalid
jmp x01_47_xt_prepare
label x01_47_xt_modifier
cmp r1 0
jne x01_47_xt_invalid
cmp r2 0
jne x01_47_xt_invalid
label x01_47_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_47_xtn_begin
label x01_47_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_47_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_47_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_47_xt_invalid
set r10 0
label x01_47_xt_lookup
cmp r10 r6
jge x01_47_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_47_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_47_xt_next
set r0 0
label x01_47_xt_compare
cmp r0 r12
jge x01_47_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_47_xt_next
add r0 1
jmp x01_47_xt_compare
label x01_47_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_47_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_47_xt_correct
jmp x01_47_xt_clean
label x01_47_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_47_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_47_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_47_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_47_xt_clean
label x01_47_xt_next
add r10 1
jmp x01_47_xt_lookup
label x01_47_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_47_xt_invalid
cmp r6 128
jge x01_47_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_47_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_47_xt_invalid
add r0 1
cmp r0 96
jlt x01_47_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_47_xt_copy
cmp r0 r12
jge x01_47_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_47_xt_copy
label x01_47_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_47_xt_clean
set r0 16
label x01_47_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_47_xt_clean_mailbox
set r0 256
label x01_47_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_47_xt_clean_scratch
jmp x01_lesson_48
label x01_47_xt_invalid
div r0 0

label x01_47_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_47_xtn_done
cmp r9 255
jgt x01_47_xtn_done
label x01_47_xtn_each
cmp r0 r9
jge x01_47_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_47_xtn_inverted
cmp r3 195
je x01_47_xtn_accent
cmp r3 226
je x01_47_xtn_unicode_space
cmp r3 32
je x01_47_xtn_space
cmp r3 44
je x01_47_xtn_space
cmp r3 46
je x01_47_xtn_space
cmp r3 33
je x01_47_xtn_space
cmp r3 63
je x01_47_xtn_space
cmp r3 65
jlt x01_47_xtn_ascii
cmp r3 90
jgt x01_47_xtn_ascii
add r3 32
label x01_47_xtn_ascii
cmp r3 97
jlt x01_47_xtn_digit
cmp r3 122
jle x01_47_xtn_append
label x01_47_xtn_digit
cmp r3 48
jlt x01_47_xtn_done
cmp r3 57
jgt x01_47_xtn_done
jmp x01_47_xtn_append
label x01_47_xtn_inverted
add r0 1
cmp r0 r9
jge x01_47_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_47_xtn_space
cmp r3 191
je x01_47_xtn_space
cmp r3 161
je x01_47_xtn_space
jmp x01_47_xtn_done
label x01_47_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_47_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_47_xtn_done
add r0 1
cmp r0 r9
jge x01_47_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_47_xtn_space
cmp r3 175
je x01_47_xtn_space
jmp x01_47_xtn_done
label x01_47_xtn_accent
add r0 1
cmp r0 r9
jge x01_47_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_47_xtn_a
cmp r3 161
je x01_47_xtn_a
cmp r3 137
je x01_47_xtn_e
cmp r3 169
je x01_47_xtn_e
cmp r3 141
je x01_47_xtn_i
cmp r3 173
je x01_47_xtn_i
cmp r3 147
je x01_47_xtn_o
cmp r3 179
je x01_47_xtn_o
cmp r3 154
je x01_47_xtn_u
cmp r3 186
je x01_47_xtn_u
cmp r3 145
je x01_47_xtn_n
cmp r3 177
je x01_47_xtn_n
jmp x01_47_xtn_done
label x01_47_xtn_a
set r3 97
jmp x01_47_xtn_append
label x01_47_xtn_e
set r3 101
jmp x01_47_xtn_append
label x01_47_xtn_i
set r3 105
jmp x01_47_xtn_append
label x01_47_xtn_o
set r3 111
jmp x01_47_xtn_append
label x01_47_xtn_u
set r3 117
jmp x01_47_xtn_append
label x01_47_xtn_n
set r3 110
jmp x01_47_xtn_append
label x01_47_xtn_space
cmp r1 0
je x01_47_xtn_next
set r2 1
jmp x01_47_xtn_next
label x01_47_xtn_append
cmp r2 0
je x01_47_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_47_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_47_xtn_next
add r0 1
jmp x01_47_xtn_each
label x01_47_xtn_valid
cmp r1 0
je x01_47_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_47_xtn_done
jmp x01_47_xt_normalized

label x01_lesson_48
store8 9050000000000000016 1
store8 9050000000000000017 17
store8 9050000000000000018 0
store8 9050000000000000019 35
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 100
store8 9050000000000000273 105
store8 9050000000000000274 109
store8 9050000000000000275 101
store8 9050000000000000276 32
store8 9050000000000000277 108
store8 9050000000000000278 97
store8 9050000000000000279 115
store8 9050000000000000280 32
store8 9050000000000000281 99
store8 9050000000000000282 97
store8 9050000000000000283 112
store8 9050000000000000284 97
store8 9050000000000000285 99
store8 9050000000000000286 105
store8 9050000000000000287 100
store8 9050000000000000288 97
store8 9050000000000000289 100
store8 9050000000000000290 101
store8 9050000000000000291 115
store8 9050000000000000292 32
store8 9050000000000000293 100
store8 9050000000000000294 101
store8 9050000000000000295 32
store8 9050000000000000296 98
store8 9050000000000000297 98
store8 9050000000000000298 121
store8 9050000000000000299 32
store8 9050000000000000300 113
store8 9050000000000000301 32
store8 9050000000000000302 116
store8 9050000000000000303 111
store8 9050000000000000304 100
store8 9050000000000000305 97
store8 9050000000000000306 115
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_48_xt_blank
cmp r0 88
jne x01_48_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_48_xt_invalid
jmp x01_48_xt_validate
label x01_48_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_48_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_48_xt_invalid
add r0 1
cmp r0 16
jlt x01_48_xt_blank_header
set r0 32
label x01_48_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_48_xt_invalid
add r0 1
cmp r0 144
jlt x01_48_xt_blank_context
set r0 4096
label x01_48_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_48_xt_invalid
add r0 1
cmp r0 16384
jlt x01_48_xt_blank_bank
label x01_48_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_48_xt_invalid
cmp r0 0
je x01_48_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_48_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_48_xt_invalid
cmp r0 17
jgt x01_48_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_48_xt_invalid
label x01_48_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_48_xt_invalid
cmp r0 4
jgt x01_48_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_48_xt_invalid
cmp r0 1
jne x01_48_xt_modifier
cmp r1 1
jlt x01_48_xt_invalid
cmp r1 17
jgt x01_48_xt_invalid
jmp x01_48_xt_prepare
label x01_48_xt_modifier
cmp r1 0
jne x01_48_xt_invalid
cmp r2 0
jne x01_48_xt_invalid
label x01_48_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_48_xtn_begin
label x01_48_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_48_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_48_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_48_xt_invalid
set r10 0
label x01_48_xt_lookup
cmp r10 r6
jge x01_48_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_48_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_48_xt_next
set r0 0
label x01_48_xt_compare
cmp r0 r12
jge x01_48_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_48_xt_next
add r0 1
jmp x01_48_xt_compare
label x01_48_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_48_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_48_xt_correct
jmp x01_48_xt_clean
label x01_48_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_48_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_48_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_48_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_48_xt_clean
label x01_48_xt_next
add r10 1
jmp x01_48_xt_lookup
label x01_48_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_48_xt_invalid
cmp r6 128
jge x01_48_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_48_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_48_xt_invalid
add r0 1
cmp r0 96
jlt x01_48_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_48_xt_copy
cmp r0 r12
jge x01_48_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_48_xt_copy
label x01_48_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_48_xt_clean
set r0 16
label x01_48_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_48_xt_clean_mailbox
set r0 256
label x01_48_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_48_xt_clean_scratch
jmp x01_lesson_49
label x01_48_xt_invalid
div r0 0

label x01_48_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_48_xtn_done
cmp r9 255
jgt x01_48_xtn_done
label x01_48_xtn_each
cmp r0 r9
jge x01_48_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_48_xtn_inverted
cmp r3 195
je x01_48_xtn_accent
cmp r3 226
je x01_48_xtn_unicode_space
cmp r3 32
je x01_48_xtn_space
cmp r3 44
je x01_48_xtn_space
cmp r3 46
je x01_48_xtn_space
cmp r3 33
je x01_48_xtn_space
cmp r3 63
je x01_48_xtn_space
cmp r3 65
jlt x01_48_xtn_ascii
cmp r3 90
jgt x01_48_xtn_ascii
add r3 32
label x01_48_xtn_ascii
cmp r3 97
jlt x01_48_xtn_digit
cmp r3 122
jle x01_48_xtn_append
label x01_48_xtn_digit
cmp r3 48
jlt x01_48_xtn_done
cmp r3 57
jgt x01_48_xtn_done
jmp x01_48_xtn_append
label x01_48_xtn_inverted
add r0 1
cmp r0 r9
jge x01_48_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_48_xtn_space
cmp r3 191
je x01_48_xtn_space
cmp r3 161
je x01_48_xtn_space
jmp x01_48_xtn_done
label x01_48_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_48_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_48_xtn_done
add r0 1
cmp r0 r9
jge x01_48_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_48_xtn_space
cmp r3 175
je x01_48_xtn_space
jmp x01_48_xtn_done
label x01_48_xtn_accent
add r0 1
cmp r0 r9
jge x01_48_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_48_xtn_a
cmp r3 161
je x01_48_xtn_a
cmp r3 137
je x01_48_xtn_e
cmp r3 169
je x01_48_xtn_e
cmp r3 141
je x01_48_xtn_i
cmp r3 173
je x01_48_xtn_i
cmp r3 147
je x01_48_xtn_o
cmp r3 179
je x01_48_xtn_o
cmp r3 154
je x01_48_xtn_u
cmp r3 186
je x01_48_xtn_u
cmp r3 145
je x01_48_xtn_n
cmp r3 177
je x01_48_xtn_n
jmp x01_48_xtn_done
label x01_48_xtn_a
set r3 97
jmp x01_48_xtn_append
label x01_48_xtn_e
set r3 101
jmp x01_48_xtn_append
label x01_48_xtn_i
set r3 105
jmp x01_48_xtn_append
label x01_48_xtn_o
set r3 111
jmp x01_48_xtn_append
label x01_48_xtn_u
set r3 117
jmp x01_48_xtn_append
label x01_48_xtn_n
set r3 110
jmp x01_48_xtn_append
label x01_48_xtn_space
cmp r1 0
je x01_48_xtn_next
set r2 1
jmp x01_48_xtn_next
label x01_48_xtn_append
cmp r2 0
je x01_48_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_48_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_48_xtn_next
add r0 1
jmp x01_48_xtn_each
label x01_48_xtn_valid
cmp r1 0
je x01_48_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_48_xtn_done
jmp x01_48_xt_normalized

label x01_lesson_49
store8 9050000000000000016 2
store8 9050000000000000017 0
store8 9050000000000000018 0
store8 9050000000000000019 3
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 111
store8 9050000000000000273 121
store8 9050000000000000274 101
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_49_xt_blank
cmp r0 88
jne x01_49_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_49_xt_invalid
jmp x01_49_xt_validate
label x01_49_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_49_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_49_xt_invalid
add r0 1
cmp r0 16
jlt x01_49_xt_blank_header
set r0 32
label x01_49_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_49_xt_invalid
add r0 1
cmp r0 144
jlt x01_49_xt_blank_context
set r0 4096
label x01_49_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_49_xt_invalid
add r0 1
cmp r0 16384
jlt x01_49_xt_blank_bank
label x01_49_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_49_xt_invalid
cmp r0 0
je x01_49_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_49_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_49_xt_invalid
cmp r0 17
jgt x01_49_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_49_xt_invalid
label x01_49_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_49_xt_invalid
cmp r0 4
jgt x01_49_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_49_xt_invalid
cmp r0 1
jne x01_49_xt_modifier
cmp r1 1
jlt x01_49_xt_invalid
cmp r1 17
jgt x01_49_xt_invalid
jmp x01_49_xt_prepare
label x01_49_xt_modifier
cmp r1 0
jne x01_49_xt_invalid
cmp r2 0
jne x01_49_xt_invalid
label x01_49_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_49_xtn_begin
label x01_49_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_49_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_49_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_49_xt_invalid
set r10 0
label x01_49_xt_lookup
cmp r10 r6
jge x01_49_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_49_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_49_xt_next
set r0 0
label x01_49_xt_compare
cmp r0 r12
jge x01_49_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_49_xt_next
add r0 1
jmp x01_49_xt_compare
label x01_49_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_49_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_49_xt_correct
jmp x01_49_xt_clean
label x01_49_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_49_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_49_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_49_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_49_xt_clean
label x01_49_xt_next
add r10 1
jmp x01_49_xt_lookup
label x01_49_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_49_xt_invalid
cmp r6 128
jge x01_49_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_49_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_49_xt_invalid
add r0 1
cmp r0 96
jlt x01_49_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_49_xt_copy
cmp r0 r12
jge x01_49_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_49_xt_copy
label x01_49_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_49_xt_clean
set r0 16
label x01_49_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_49_xt_clean_mailbox
set r0 256
label x01_49_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_49_xt_clean_scratch
jmp x01_lesson_50
label x01_49_xt_invalid
div r0 0

label x01_49_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_49_xtn_done
cmp r9 255
jgt x01_49_xtn_done
label x01_49_xtn_each
cmp r0 r9
jge x01_49_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_49_xtn_inverted
cmp r3 195
je x01_49_xtn_accent
cmp r3 226
je x01_49_xtn_unicode_space
cmp r3 32
je x01_49_xtn_space
cmp r3 44
je x01_49_xtn_space
cmp r3 46
je x01_49_xtn_space
cmp r3 33
je x01_49_xtn_space
cmp r3 63
je x01_49_xtn_space
cmp r3 65
jlt x01_49_xtn_ascii
cmp r3 90
jgt x01_49_xtn_ascii
add r3 32
label x01_49_xtn_ascii
cmp r3 97
jlt x01_49_xtn_digit
cmp r3 122
jle x01_49_xtn_append
label x01_49_xtn_digit
cmp r3 48
jlt x01_49_xtn_done
cmp r3 57
jgt x01_49_xtn_done
jmp x01_49_xtn_append
label x01_49_xtn_inverted
add r0 1
cmp r0 r9
jge x01_49_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_49_xtn_space
cmp r3 191
je x01_49_xtn_space
cmp r3 161
je x01_49_xtn_space
jmp x01_49_xtn_done
label x01_49_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_49_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_49_xtn_done
add r0 1
cmp r0 r9
jge x01_49_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_49_xtn_space
cmp r3 175
je x01_49_xtn_space
jmp x01_49_xtn_done
label x01_49_xtn_accent
add r0 1
cmp r0 r9
jge x01_49_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_49_xtn_a
cmp r3 161
je x01_49_xtn_a
cmp r3 137
je x01_49_xtn_e
cmp r3 169
je x01_49_xtn_e
cmp r3 141
je x01_49_xtn_i
cmp r3 173
je x01_49_xtn_i
cmp r3 147
je x01_49_xtn_o
cmp r3 179
je x01_49_xtn_o
cmp r3 154
je x01_49_xtn_u
cmp r3 186
je x01_49_xtn_u
cmp r3 145
je x01_49_xtn_n
cmp r3 177
je x01_49_xtn_n
jmp x01_49_xtn_done
label x01_49_xtn_a
set r3 97
jmp x01_49_xtn_append
label x01_49_xtn_e
set r3 101
jmp x01_49_xtn_append
label x01_49_xtn_i
set r3 105
jmp x01_49_xtn_append
label x01_49_xtn_o
set r3 111
jmp x01_49_xtn_append
label x01_49_xtn_u
set r3 117
jmp x01_49_xtn_append
label x01_49_xtn_n
set r3 110
jmp x01_49_xtn_append
label x01_49_xtn_space
cmp r1 0
je x01_49_xtn_next
set r2 1
jmp x01_49_xtn_next
label x01_49_xtn_append
cmp r2 0
je x01_49_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_49_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_49_xtn_next
add r0 1
jmp x01_49_xtn_each
label x01_49_xtn_valid
cmp r1 0
je x01_49_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_49_xtn_done
jmp x01_49_xt_normalized

label x01_lesson_50
store8 9050000000000000016 2
store8 9050000000000000017 0
store8 9050000000000000018 0
store8 9050000000000000019 2
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 112
store8 9050000000000000273 122
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_50_xt_blank
cmp r0 88
jne x01_50_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_50_xt_invalid
jmp x01_50_xt_validate
label x01_50_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_50_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_50_xt_invalid
add r0 1
cmp r0 16
jlt x01_50_xt_blank_header
set r0 32
label x01_50_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_50_xt_invalid
add r0 1
cmp r0 144
jlt x01_50_xt_blank_context
set r0 4096
label x01_50_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_50_xt_invalid
add r0 1
cmp r0 16384
jlt x01_50_xt_blank_bank
label x01_50_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_50_xt_invalid
cmp r0 0
je x01_50_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_50_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_50_xt_invalid
cmp r0 17
jgt x01_50_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_50_xt_invalid
label x01_50_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_50_xt_invalid
cmp r0 4
jgt x01_50_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_50_xt_invalid
cmp r0 1
jne x01_50_xt_modifier
cmp r1 1
jlt x01_50_xt_invalid
cmp r1 17
jgt x01_50_xt_invalid
jmp x01_50_xt_prepare
label x01_50_xt_modifier
cmp r1 0
jne x01_50_xt_invalid
cmp r2 0
jne x01_50_xt_invalid
label x01_50_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_50_xtn_begin
label x01_50_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_50_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_50_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_50_xt_invalid
set r10 0
label x01_50_xt_lookup
cmp r10 r6
jge x01_50_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_50_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_50_xt_next
set r0 0
label x01_50_xt_compare
cmp r0 r12
jge x01_50_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_50_xt_next
add r0 1
jmp x01_50_xt_compare
label x01_50_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_50_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_50_xt_correct
jmp x01_50_xt_clean
label x01_50_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_50_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_50_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_50_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_50_xt_clean
label x01_50_xt_next
add r10 1
jmp x01_50_xt_lookup
label x01_50_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_50_xt_invalid
cmp r6 128
jge x01_50_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_50_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_50_xt_invalid
add r0 1
cmp r0 96
jlt x01_50_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_50_xt_copy
cmp r0 r12
jge x01_50_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_50_xt_copy
label x01_50_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_50_xt_clean
set r0 16
label x01_50_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_50_xt_clean_mailbox
set r0 256
label x01_50_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_50_xt_clean_scratch
jmp x01_lesson_51
label x01_50_xt_invalid
div r0 0

label x01_50_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_50_xtn_done
cmp r9 255
jgt x01_50_xtn_done
label x01_50_xtn_each
cmp r0 r9
jge x01_50_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_50_xtn_inverted
cmp r3 195
je x01_50_xtn_accent
cmp r3 226
je x01_50_xtn_unicode_space
cmp r3 32
je x01_50_xtn_space
cmp r3 44
je x01_50_xtn_space
cmp r3 46
je x01_50_xtn_space
cmp r3 33
je x01_50_xtn_space
cmp r3 63
je x01_50_xtn_space
cmp r3 65
jlt x01_50_xtn_ascii
cmp r3 90
jgt x01_50_xtn_ascii
add r3 32
label x01_50_xtn_ascii
cmp r3 97
jlt x01_50_xtn_digit
cmp r3 122
jle x01_50_xtn_append
label x01_50_xtn_digit
cmp r3 48
jlt x01_50_xtn_done
cmp r3 57
jgt x01_50_xtn_done
jmp x01_50_xtn_append
label x01_50_xtn_inverted
add r0 1
cmp r0 r9
jge x01_50_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_50_xtn_space
cmp r3 191
je x01_50_xtn_space
cmp r3 161
je x01_50_xtn_space
jmp x01_50_xtn_done
label x01_50_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_50_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_50_xtn_done
add r0 1
cmp r0 r9
jge x01_50_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_50_xtn_space
cmp r3 175
je x01_50_xtn_space
jmp x01_50_xtn_done
label x01_50_xtn_accent
add r0 1
cmp r0 r9
jge x01_50_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_50_xtn_a
cmp r3 161
je x01_50_xtn_a
cmp r3 137
je x01_50_xtn_e
cmp r3 169
je x01_50_xtn_e
cmp r3 141
je x01_50_xtn_i
cmp r3 173
je x01_50_xtn_i
cmp r3 147
je x01_50_xtn_o
cmp r3 179
je x01_50_xtn_o
cmp r3 154
je x01_50_xtn_u
cmp r3 186
je x01_50_xtn_u
cmp r3 145
je x01_50_xtn_n
cmp r3 177
je x01_50_xtn_n
jmp x01_50_xtn_done
label x01_50_xtn_a
set r3 97
jmp x01_50_xtn_append
label x01_50_xtn_e
set r3 101
jmp x01_50_xtn_append
label x01_50_xtn_i
set r3 105
jmp x01_50_xtn_append
label x01_50_xtn_o
set r3 111
jmp x01_50_xtn_append
label x01_50_xtn_u
set r3 117
jmp x01_50_xtn_append
label x01_50_xtn_n
set r3 110
jmp x01_50_xtn_append
label x01_50_xtn_space
cmp r1 0
je x01_50_xtn_next
set r2 1
jmp x01_50_xtn_next
label x01_50_xtn_append
cmp r2 0
je x01_50_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_50_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_50_xtn_next
add r0 1
jmp x01_50_xtn_each
label x01_50_xtn_valid
cmp r1 0
je x01_50_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_50_xtn_done
jmp x01_50_xt_normalized

label x01_lesson_51
store8 9050000000000000016 2
store8 9050000000000000017 0
store8 9050000000000000018 0
store8 9050000000000000019 4
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 112
store8 9050000000000000273 117
store8 9050000000000000274 101
store8 9050000000000000275 115
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_51_xt_blank
cmp r0 88
jne x01_51_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_51_xt_invalid
jmp x01_51_xt_validate
label x01_51_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_51_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_51_xt_invalid
add r0 1
cmp r0 16
jlt x01_51_xt_blank_header
set r0 32
label x01_51_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_51_xt_invalid
add r0 1
cmp r0 144
jlt x01_51_xt_blank_context
set r0 4096
label x01_51_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_51_xt_invalid
add r0 1
cmp r0 16384
jlt x01_51_xt_blank_bank
label x01_51_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_51_xt_invalid
cmp r0 0
je x01_51_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_51_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_51_xt_invalid
cmp r0 17
jgt x01_51_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_51_xt_invalid
label x01_51_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_51_xt_invalid
cmp r0 4
jgt x01_51_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_51_xt_invalid
cmp r0 1
jne x01_51_xt_modifier
cmp r1 1
jlt x01_51_xt_invalid
cmp r1 17
jgt x01_51_xt_invalid
jmp x01_51_xt_prepare
label x01_51_xt_modifier
cmp r1 0
jne x01_51_xt_invalid
cmp r2 0
jne x01_51_xt_invalid
label x01_51_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_51_xtn_begin
label x01_51_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_51_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_51_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_51_xt_invalid
set r10 0
label x01_51_xt_lookup
cmp r10 r6
jge x01_51_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_51_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_51_xt_next
set r0 0
label x01_51_xt_compare
cmp r0 r12
jge x01_51_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_51_xt_next
add r0 1
jmp x01_51_xt_compare
label x01_51_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_51_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_51_xt_correct
jmp x01_51_xt_clean
label x01_51_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_51_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_51_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_51_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_51_xt_clean
label x01_51_xt_next
add r10 1
jmp x01_51_xt_lookup
label x01_51_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_51_xt_invalid
cmp r6 128
jge x01_51_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_51_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_51_xt_invalid
add r0 1
cmp r0 96
jlt x01_51_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_51_xt_copy
cmp r0 r12
jge x01_51_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_51_xt_copy
label x01_51_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_51_xt_clean
set r0 16
label x01_51_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_51_xt_clean_mailbox
set r0 256
label x01_51_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_51_xt_clean_scratch
jmp x01_lesson_52
label x01_51_xt_invalid
div r0 0

label x01_51_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_51_xtn_done
cmp r9 255
jgt x01_51_xtn_done
label x01_51_xtn_each
cmp r0 r9
jge x01_51_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_51_xtn_inverted
cmp r3 195
je x01_51_xtn_accent
cmp r3 226
je x01_51_xtn_unicode_space
cmp r3 32
je x01_51_xtn_space
cmp r3 44
je x01_51_xtn_space
cmp r3 46
je x01_51_xtn_space
cmp r3 33
je x01_51_xtn_space
cmp r3 63
je x01_51_xtn_space
cmp r3 65
jlt x01_51_xtn_ascii
cmp r3 90
jgt x01_51_xtn_ascii
add r3 32
label x01_51_xtn_ascii
cmp r3 97
jlt x01_51_xtn_digit
cmp r3 122
jle x01_51_xtn_append
label x01_51_xtn_digit
cmp r3 48
jlt x01_51_xtn_done
cmp r3 57
jgt x01_51_xtn_done
jmp x01_51_xtn_append
label x01_51_xtn_inverted
add r0 1
cmp r0 r9
jge x01_51_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_51_xtn_space
cmp r3 191
je x01_51_xtn_space
cmp r3 161
je x01_51_xtn_space
jmp x01_51_xtn_done
label x01_51_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_51_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_51_xtn_done
add r0 1
cmp r0 r9
jge x01_51_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_51_xtn_space
cmp r3 175
je x01_51_xtn_space
jmp x01_51_xtn_done
label x01_51_xtn_accent
add r0 1
cmp r0 r9
jge x01_51_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_51_xtn_a
cmp r3 161
je x01_51_xtn_a
cmp r3 137
je x01_51_xtn_e
cmp r3 169
je x01_51_xtn_e
cmp r3 141
je x01_51_xtn_i
cmp r3 173
je x01_51_xtn_i
cmp r3 147
je x01_51_xtn_o
cmp r3 179
je x01_51_xtn_o
cmp r3 154
je x01_51_xtn_u
cmp r3 186
je x01_51_xtn_u
cmp r3 145
je x01_51_xtn_n
cmp r3 177
je x01_51_xtn_n
jmp x01_51_xtn_done
label x01_51_xtn_a
set r3 97
jmp x01_51_xtn_append
label x01_51_xtn_e
set r3 101
jmp x01_51_xtn_append
label x01_51_xtn_i
set r3 105
jmp x01_51_xtn_append
label x01_51_xtn_o
set r3 111
jmp x01_51_xtn_append
label x01_51_xtn_u
set r3 117
jmp x01_51_xtn_append
label x01_51_xtn_n
set r3 110
jmp x01_51_xtn_append
label x01_51_xtn_space
cmp r1 0
je x01_51_xtn_next
set r2 1
jmp x01_51_xtn_next
label x01_51_xtn_append
cmp r2 0
je x01_51_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_51_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_51_xtn_next
add r0 1
jmp x01_51_xtn_each
label x01_51_xtn_valid
cmp r1 0
je x01_51_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_51_xtn_done
jmp x01_51_xt_normalized

label x01_lesson_52
store8 9050000000000000016 2
store8 9050000000000000017 0
store8 9050000000000000018 0
store8 9050000000000000019 5
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 104
store8 9050000000000000273 97
store8 9050000000000000274 98
store8 9050000000000000275 101
store8 9050000000000000276 114
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_52_xt_blank
cmp r0 88
jne x01_52_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_52_xt_invalid
jmp x01_52_xt_validate
label x01_52_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_52_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_52_xt_invalid
add r0 1
cmp r0 16
jlt x01_52_xt_blank_header
set r0 32
label x01_52_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_52_xt_invalid
add r0 1
cmp r0 144
jlt x01_52_xt_blank_context
set r0 4096
label x01_52_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_52_xt_invalid
add r0 1
cmp r0 16384
jlt x01_52_xt_blank_bank
label x01_52_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_52_xt_invalid
cmp r0 0
je x01_52_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_52_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_52_xt_invalid
cmp r0 17
jgt x01_52_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_52_xt_invalid
label x01_52_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_52_xt_invalid
cmp r0 4
jgt x01_52_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_52_xt_invalid
cmp r0 1
jne x01_52_xt_modifier
cmp r1 1
jlt x01_52_xt_invalid
cmp r1 17
jgt x01_52_xt_invalid
jmp x01_52_xt_prepare
label x01_52_xt_modifier
cmp r1 0
jne x01_52_xt_invalid
cmp r2 0
jne x01_52_xt_invalid
label x01_52_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_52_xtn_begin
label x01_52_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_52_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_52_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_52_xt_invalid
set r10 0
label x01_52_xt_lookup
cmp r10 r6
jge x01_52_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_52_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_52_xt_next
set r0 0
label x01_52_xt_compare
cmp r0 r12
jge x01_52_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_52_xt_next
add r0 1
jmp x01_52_xt_compare
label x01_52_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_52_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_52_xt_correct
jmp x01_52_xt_clean
label x01_52_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_52_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_52_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_52_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_52_xt_clean
label x01_52_xt_next
add r10 1
jmp x01_52_xt_lookup
label x01_52_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_52_xt_invalid
cmp r6 128
jge x01_52_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_52_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_52_xt_invalid
add r0 1
cmp r0 96
jlt x01_52_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_52_xt_copy
cmp r0 r12
jge x01_52_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_52_xt_copy
label x01_52_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_52_xt_clean
set r0 16
label x01_52_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_52_xt_clean_mailbox
set r0 256
label x01_52_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_52_xt_clean_scratch
jmp x01_lesson_53
label x01_52_xt_invalid
div r0 0

label x01_52_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_52_xtn_done
cmp r9 255
jgt x01_52_xtn_done
label x01_52_xtn_each
cmp r0 r9
jge x01_52_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_52_xtn_inverted
cmp r3 195
je x01_52_xtn_accent
cmp r3 226
je x01_52_xtn_unicode_space
cmp r3 32
je x01_52_xtn_space
cmp r3 44
je x01_52_xtn_space
cmp r3 46
je x01_52_xtn_space
cmp r3 33
je x01_52_xtn_space
cmp r3 63
je x01_52_xtn_space
cmp r3 65
jlt x01_52_xtn_ascii
cmp r3 90
jgt x01_52_xtn_ascii
add r3 32
label x01_52_xtn_ascii
cmp r3 97
jlt x01_52_xtn_digit
cmp r3 122
jle x01_52_xtn_append
label x01_52_xtn_digit
cmp r3 48
jlt x01_52_xtn_done
cmp r3 57
jgt x01_52_xtn_done
jmp x01_52_xtn_append
label x01_52_xtn_inverted
add r0 1
cmp r0 r9
jge x01_52_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_52_xtn_space
cmp r3 191
je x01_52_xtn_space
cmp r3 161
je x01_52_xtn_space
jmp x01_52_xtn_done
label x01_52_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_52_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_52_xtn_done
add r0 1
cmp r0 r9
jge x01_52_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_52_xtn_space
cmp r3 175
je x01_52_xtn_space
jmp x01_52_xtn_done
label x01_52_xtn_accent
add r0 1
cmp r0 r9
jge x01_52_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_52_xtn_a
cmp r3 161
je x01_52_xtn_a
cmp r3 137
je x01_52_xtn_e
cmp r3 169
je x01_52_xtn_e
cmp r3 141
je x01_52_xtn_i
cmp r3 173
je x01_52_xtn_i
cmp r3 147
je x01_52_xtn_o
cmp r3 179
je x01_52_xtn_o
cmp r3 154
je x01_52_xtn_u
cmp r3 186
je x01_52_xtn_u
cmp r3 145
je x01_52_xtn_n
cmp r3 177
je x01_52_xtn_n
jmp x01_52_xtn_done
label x01_52_xtn_a
set r3 97
jmp x01_52_xtn_append
label x01_52_xtn_e
set r3 101
jmp x01_52_xtn_append
label x01_52_xtn_i
set r3 105
jmp x01_52_xtn_append
label x01_52_xtn_o
set r3 111
jmp x01_52_xtn_append
label x01_52_xtn_u
set r3 117
jmp x01_52_xtn_append
label x01_52_xtn_n
set r3 110
jmp x01_52_xtn_append
label x01_52_xtn_space
cmp r1 0
je x01_52_xtn_next
set r2 1
jmp x01_52_xtn_next
label x01_52_xtn_append
cmp r2 0
je x01_52_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_52_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_52_xtn_next
add r0 1
jmp x01_52_xtn_each
label x01_52_xtn_valid
cmp r1 0
je x01_52_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_52_xtn_done
jmp x01_52_xt_normalized

label x01_lesson_53
store8 9050000000000000016 2
store8 9050000000000000017 0
store8 9050000000000000018 0
store8 9050000000000000019 5
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 97
store8 9050000000000000273 32
store8 9050000000000000274 118
store8 9050000000000000275 101
store8 9050000000000000276 114
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_53_xt_blank
cmp r0 88
jne x01_53_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_53_xt_invalid
jmp x01_53_xt_validate
label x01_53_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_53_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_53_xt_invalid
add r0 1
cmp r0 16
jlt x01_53_xt_blank_header
set r0 32
label x01_53_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_53_xt_invalid
add r0 1
cmp r0 144
jlt x01_53_xt_blank_context
set r0 4096
label x01_53_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_53_xt_invalid
add r0 1
cmp r0 16384
jlt x01_53_xt_blank_bank
label x01_53_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_53_xt_invalid
cmp r0 0
je x01_53_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_53_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_53_xt_invalid
cmp r0 17
jgt x01_53_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_53_xt_invalid
label x01_53_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_53_xt_invalid
cmp r0 4
jgt x01_53_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_53_xt_invalid
cmp r0 1
jne x01_53_xt_modifier
cmp r1 1
jlt x01_53_xt_invalid
cmp r1 17
jgt x01_53_xt_invalid
jmp x01_53_xt_prepare
label x01_53_xt_modifier
cmp r1 0
jne x01_53_xt_invalid
cmp r2 0
jne x01_53_xt_invalid
label x01_53_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_53_xtn_begin
label x01_53_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_53_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_53_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_53_xt_invalid
set r10 0
label x01_53_xt_lookup
cmp r10 r6
jge x01_53_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_53_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_53_xt_next
set r0 0
label x01_53_xt_compare
cmp r0 r12
jge x01_53_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_53_xt_next
add r0 1
jmp x01_53_xt_compare
label x01_53_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_53_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_53_xt_correct
jmp x01_53_xt_clean
label x01_53_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_53_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_53_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_53_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_53_xt_clean
label x01_53_xt_next
add r10 1
jmp x01_53_xt_lookup
label x01_53_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_53_xt_invalid
cmp r6 128
jge x01_53_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_53_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_53_xt_invalid
add r0 1
cmp r0 96
jlt x01_53_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_53_xt_copy
cmp r0 r12
jge x01_53_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_53_xt_copy
label x01_53_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_53_xt_clean
set r0 16
label x01_53_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_53_xt_clean_mailbox
set r0 256
label x01_53_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_53_xt_clean_scratch
jmp x01_lesson_54
label x01_53_xt_invalid
div r0 0

label x01_53_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_53_xtn_done
cmp r9 255
jgt x01_53_xtn_done
label x01_53_xtn_each
cmp r0 r9
jge x01_53_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_53_xtn_inverted
cmp r3 195
je x01_53_xtn_accent
cmp r3 226
je x01_53_xtn_unicode_space
cmp r3 32
je x01_53_xtn_space
cmp r3 44
je x01_53_xtn_space
cmp r3 46
je x01_53_xtn_space
cmp r3 33
je x01_53_xtn_space
cmp r3 63
je x01_53_xtn_space
cmp r3 65
jlt x01_53_xtn_ascii
cmp r3 90
jgt x01_53_xtn_ascii
add r3 32
label x01_53_xtn_ascii
cmp r3 97
jlt x01_53_xtn_digit
cmp r3 122
jle x01_53_xtn_append
label x01_53_xtn_digit
cmp r3 48
jlt x01_53_xtn_done
cmp r3 57
jgt x01_53_xtn_done
jmp x01_53_xtn_append
label x01_53_xtn_inverted
add r0 1
cmp r0 r9
jge x01_53_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_53_xtn_space
cmp r3 191
je x01_53_xtn_space
cmp r3 161
je x01_53_xtn_space
jmp x01_53_xtn_done
label x01_53_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_53_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_53_xtn_done
add r0 1
cmp r0 r9
jge x01_53_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_53_xtn_space
cmp r3 175
je x01_53_xtn_space
jmp x01_53_xtn_done
label x01_53_xtn_accent
add r0 1
cmp r0 r9
jge x01_53_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_53_xtn_a
cmp r3 161
je x01_53_xtn_a
cmp r3 137
je x01_53_xtn_e
cmp r3 169
je x01_53_xtn_e
cmp r3 141
je x01_53_xtn_i
cmp r3 173
je x01_53_xtn_i
cmp r3 147
je x01_53_xtn_o
cmp r3 179
je x01_53_xtn_o
cmp r3 154
je x01_53_xtn_u
cmp r3 186
je x01_53_xtn_u
cmp r3 145
je x01_53_xtn_n
cmp r3 177
je x01_53_xtn_n
jmp x01_53_xtn_done
label x01_53_xtn_a
set r3 97
jmp x01_53_xtn_append
label x01_53_xtn_e
set r3 101
jmp x01_53_xtn_append
label x01_53_xtn_i
set r3 105
jmp x01_53_xtn_append
label x01_53_xtn_o
set r3 111
jmp x01_53_xtn_append
label x01_53_xtn_u
set r3 117
jmp x01_53_xtn_append
label x01_53_xtn_n
set r3 110
jmp x01_53_xtn_append
label x01_53_xtn_space
cmp r1 0
je x01_53_xtn_next
set r2 1
jmp x01_53_xtn_next
label x01_53_xtn_append
cmp r2 0
je x01_53_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_53_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_53_xtn_next
add r0 1
jmp x01_53_xtn_each
label x01_53_xtn_valid
cmp r1 0
je x01_53_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_53_xtn_done
jmp x01_53_xt_normalized

label x01_lesson_54
store8 9050000000000000016 4
store8 9050000000000000017 0
store8 9050000000000000018 0
store8 9050000000000000019 8
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 112
store8 9050000000000000273 111
store8 9050000000000000274 114
store8 9050000000000000275 102
store8 9050000000000000276 97
store8 9050000000000000277 118
store8 9050000000000000278 111
store8 9050000000000000279 114
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_54_xt_blank
cmp r0 88
jne x01_54_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_54_xt_invalid
jmp x01_54_xt_validate
label x01_54_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_54_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_54_xt_invalid
add r0 1
cmp r0 16
jlt x01_54_xt_blank_header
set r0 32
label x01_54_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_54_xt_invalid
add r0 1
cmp r0 144
jlt x01_54_xt_blank_context
set r0 4096
label x01_54_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_54_xt_invalid
add r0 1
cmp r0 16384
jlt x01_54_xt_blank_bank
label x01_54_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_54_xt_invalid
cmp r0 0
je x01_54_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_54_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_54_xt_invalid
cmp r0 17
jgt x01_54_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_54_xt_invalid
label x01_54_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_54_xt_invalid
cmp r0 4
jgt x01_54_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_54_xt_invalid
cmp r0 1
jne x01_54_xt_modifier
cmp r1 1
jlt x01_54_xt_invalid
cmp r1 17
jgt x01_54_xt_invalid
jmp x01_54_xt_prepare
label x01_54_xt_modifier
cmp r1 0
jne x01_54_xt_invalid
cmp r2 0
jne x01_54_xt_invalid
label x01_54_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_54_xtn_begin
label x01_54_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_54_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_54_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_54_xt_invalid
set r10 0
label x01_54_xt_lookup
cmp r10 r6
jge x01_54_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_54_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_54_xt_next
set r0 0
label x01_54_xt_compare
cmp r0 r12
jge x01_54_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_54_xt_next
add r0 1
jmp x01_54_xt_compare
label x01_54_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_54_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_54_xt_correct
jmp x01_54_xt_clean
label x01_54_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_54_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_54_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_54_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_54_xt_clean
label x01_54_xt_next
add r10 1
jmp x01_54_xt_lookup
label x01_54_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_54_xt_invalid
cmp r6 128
jge x01_54_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_54_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_54_xt_invalid
add r0 1
cmp r0 96
jlt x01_54_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_54_xt_copy
cmp r0 r12
jge x01_54_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_54_xt_copy
label x01_54_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_54_xt_clean
set r0 16
label x01_54_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_54_xt_clean_mailbox
set r0 256
label x01_54_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_54_xt_clean_scratch
jmp x01_lesson_55
label x01_54_xt_invalid
div r0 0

label x01_54_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_54_xtn_done
cmp r9 255
jgt x01_54_xtn_done
label x01_54_xtn_each
cmp r0 r9
jge x01_54_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_54_xtn_inverted
cmp r3 195
je x01_54_xtn_accent
cmp r3 226
je x01_54_xtn_unicode_space
cmp r3 32
je x01_54_xtn_space
cmp r3 44
je x01_54_xtn_space
cmp r3 46
je x01_54_xtn_space
cmp r3 33
je x01_54_xtn_space
cmp r3 63
je x01_54_xtn_space
cmp r3 65
jlt x01_54_xtn_ascii
cmp r3 90
jgt x01_54_xtn_ascii
add r3 32
label x01_54_xtn_ascii
cmp r3 97
jlt x01_54_xtn_digit
cmp r3 122
jle x01_54_xtn_append
label x01_54_xtn_digit
cmp r3 48
jlt x01_54_xtn_done
cmp r3 57
jgt x01_54_xtn_done
jmp x01_54_xtn_append
label x01_54_xtn_inverted
add r0 1
cmp r0 r9
jge x01_54_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_54_xtn_space
cmp r3 191
je x01_54_xtn_space
cmp r3 161
je x01_54_xtn_space
jmp x01_54_xtn_done
label x01_54_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_54_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_54_xtn_done
add r0 1
cmp r0 r9
jge x01_54_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_54_xtn_space
cmp r3 175
je x01_54_xtn_space
jmp x01_54_xtn_done
label x01_54_xtn_accent
add r0 1
cmp r0 r9
jge x01_54_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_54_xtn_a
cmp r3 161
je x01_54_xtn_a
cmp r3 137
je x01_54_xtn_e
cmp r3 169
je x01_54_xtn_e
cmp r3 141
je x01_54_xtn_i
cmp r3 173
je x01_54_xtn_i
cmp r3 147
je x01_54_xtn_o
cmp r3 179
je x01_54_xtn_o
cmp r3 154
je x01_54_xtn_u
cmp r3 186
je x01_54_xtn_u
cmp r3 145
je x01_54_xtn_n
cmp r3 177
je x01_54_xtn_n
jmp x01_54_xtn_done
label x01_54_xtn_a
set r3 97
jmp x01_54_xtn_append
label x01_54_xtn_e
set r3 101
jmp x01_54_xtn_append
label x01_54_xtn_i
set r3 105
jmp x01_54_xtn_append
label x01_54_xtn_o
set r3 111
jmp x01_54_xtn_append
label x01_54_xtn_u
set r3 117
jmp x01_54_xtn_append
label x01_54_xtn_n
set r3 110
jmp x01_54_xtn_append
label x01_54_xtn_space
cmp r1 0
je x01_54_xtn_next
set r2 1
jmp x01_54_xtn_next
label x01_54_xtn_append
cmp r2 0
je x01_54_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_54_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_54_xtn_next
add r0 1
jmp x01_54_xtn_each
label x01_54_xtn_valid
cmp r1 0
je x01_54_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_54_xtn_done
jmp x01_54_xt_normalized

label x01_lesson_55
store8 9050000000000000016 4
store8 9050000000000000017 0
store8 9050000000000000018 0
store8 9050000000000000019 9
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 112
store8 9050000000000000273 111
store8 9050000000000000274 114
store8 9050000000000000275 32
store8 9050000000000000276 102
store8 9050000000000000277 97
store8 9050000000000000278 118
store8 9050000000000000279 111
store8 9050000000000000280 114
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_55_xt_blank
cmp r0 88
jne x01_55_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_55_xt_invalid
jmp x01_55_xt_validate
label x01_55_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_55_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_55_xt_invalid
add r0 1
cmp r0 16
jlt x01_55_xt_blank_header
set r0 32
label x01_55_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_55_xt_invalid
add r0 1
cmp r0 144
jlt x01_55_xt_blank_context
set r0 4096
label x01_55_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_55_xt_invalid
add r0 1
cmp r0 16384
jlt x01_55_xt_blank_bank
label x01_55_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_55_xt_invalid
cmp r0 0
je x01_55_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_55_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_55_xt_invalid
cmp r0 17
jgt x01_55_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_55_xt_invalid
label x01_55_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_55_xt_invalid
cmp r0 4
jgt x01_55_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_55_xt_invalid
cmp r0 1
jne x01_55_xt_modifier
cmp r1 1
jlt x01_55_xt_invalid
cmp r1 17
jgt x01_55_xt_invalid
jmp x01_55_xt_prepare
label x01_55_xt_modifier
cmp r1 0
jne x01_55_xt_invalid
cmp r2 0
jne x01_55_xt_invalid
label x01_55_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_55_xtn_begin
label x01_55_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_55_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_55_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_55_xt_invalid
set r10 0
label x01_55_xt_lookup
cmp r10 r6
jge x01_55_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_55_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_55_xt_next
set r0 0
label x01_55_xt_compare
cmp r0 r12
jge x01_55_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_55_xt_next
add r0 1
jmp x01_55_xt_compare
label x01_55_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_55_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_55_xt_correct
jmp x01_55_xt_clean
label x01_55_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_55_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_55_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_55_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_55_xt_clean
label x01_55_xt_next
add r10 1
jmp x01_55_xt_lookup
label x01_55_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_55_xt_invalid
cmp r6 128
jge x01_55_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_55_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_55_xt_invalid
add r0 1
cmp r0 96
jlt x01_55_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_55_xt_copy
cmp r0 r12
jge x01_55_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_55_xt_copy
label x01_55_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_55_xt_clean
set r0 16
label x01_55_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_55_xt_clean_mailbox
set r0 256
label x01_55_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_55_xt_clean_scratch
jmp x01_lesson_56
label x01_55_xt_invalid
div r0 0

label x01_55_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_55_xtn_done
cmp r9 255
jgt x01_55_xtn_done
label x01_55_xtn_each
cmp r0 r9
jge x01_55_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_55_xtn_inverted
cmp r3 195
je x01_55_xtn_accent
cmp r3 226
je x01_55_xtn_unicode_space
cmp r3 32
je x01_55_xtn_space
cmp r3 44
je x01_55_xtn_space
cmp r3 46
je x01_55_xtn_space
cmp r3 33
je x01_55_xtn_space
cmp r3 63
je x01_55_xtn_space
cmp r3 65
jlt x01_55_xtn_ascii
cmp r3 90
jgt x01_55_xtn_ascii
add r3 32
label x01_55_xtn_ascii
cmp r3 97
jlt x01_55_xtn_digit
cmp r3 122
jle x01_55_xtn_append
label x01_55_xtn_digit
cmp r3 48
jlt x01_55_xtn_done
cmp r3 57
jgt x01_55_xtn_done
jmp x01_55_xtn_append
label x01_55_xtn_inverted
add r0 1
cmp r0 r9
jge x01_55_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_55_xtn_space
cmp r3 191
je x01_55_xtn_space
cmp r3 161
je x01_55_xtn_space
jmp x01_55_xtn_done
label x01_55_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_55_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_55_xtn_done
add r0 1
cmp r0 r9
jge x01_55_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_55_xtn_space
cmp r3 175
je x01_55_xtn_space
jmp x01_55_xtn_done
label x01_55_xtn_accent
add r0 1
cmp r0 r9
jge x01_55_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_55_xtn_a
cmp r3 161
je x01_55_xtn_a
cmp r3 137
je x01_55_xtn_e
cmp r3 169
je x01_55_xtn_e
cmp r3 141
je x01_55_xtn_i
cmp r3 173
je x01_55_xtn_i
cmp r3 147
je x01_55_xtn_o
cmp r3 179
je x01_55_xtn_o
cmp r3 154
je x01_55_xtn_u
cmp r3 186
je x01_55_xtn_u
cmp r3 145
je x01_55_xtn_n
cmp r3 177
je x01_55_xtn_n
jmp x01_55_xtn_done
label x01_55_xtn_a
set r3 97
jmp x01_55_xtn_append
label x01_55_xtn_e
set r3 101
jmp x01_55_xtn_append
label x01_55_xtn_i
set r3 105
jmp x01_55_xtn_append
label x01_55_xtn_o
set r3 111
jmp x01_55_xtn_append
label x01_55_xtn_u
set r3 117
jmp x01_55_xtn_append
label x01_55_xtn_n
set r3 110
jmp x01_55_xtn_append
label x01_55_xtn_space
cmp r1 0
je x01_55_xtn_next
set r2 1
jmp x01_55_xtn_next
label x01_55_xtn_append
cmp r2 0
je x01_55_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_55_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_55_xtn_next
add r0 1
jmp x01_55_xtn_each
label x01_55_xtn_valid
cmp r1 0
je x01_55_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_55_xtn_done
jmp x01_55_xt_normalized

label x01_lesson_56
store8 9050000000000000016 3
store8 9050000000000000017 0
store8 9050000000000000018 0
store8 9050000000000000019 2
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 120
store8 9050000000000000273 100
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_56_xt_blank
cmp r0 88
jne x01_56_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_56_xt_invalid
jmp x01_56_xt_validate
label x01_56_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_56_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_56_xt_invalid
add r0 1
cmp r0 16
jlt x01_56_xt_blank_header
set r0 32
label x01_56_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_56_xt_invalid
add r0 1
cmp r0 144
jlt x01_56_xt_blank_context
set r0 4096
label x01_56_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_56_xt_invalid
add r0 1
cmp r0 16384
jlt x01_56_xt_blank_bank
label x01_56_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_56_xt_invalid
cmp r0 0
je x01_56_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_56_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_56_xt_invalid
cmp r0 17
jgt x01_56_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_56_xt_invalid
label x01_56_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_56_xt_invalid
cmp r0 4
jgt x01_56_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_56_xt_invalid
cmp r0 1
jne x01_56_xt_modifier
cmp r1 1
jlt x01_56_xt_invalid
cmp r1 17
jgt x01_56_xt_invalid
jmp x01_56_xt_prepare
label x01_56_xt_modifier
cmp r1 0
jne x01_56_xt_invalid
cmp r2 0
jne x01_56_xt_invalid
label x01_56_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_56_xtn_begin
label x01_56_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_56_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_56_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_56_xt_invalid
set r10 0
label x01_56_xt_lookup
cmp r10 r6
jge x01_56_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_56_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_56_xt_next
set r0 0
label x01_56_xt_compare
cmp r0 r12
jge x01_56_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_56_xt_next
add r0 1
jmp x01_56_xt_compare
label x01_56_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_56_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_56_xt_correct
jmp x01_56_xt_clean
label x01_56_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_56_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_56_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_56_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_56_xt_clean
label x01_56_xt_next
add r10 1
jmp x01_56_xt_lookup
label x01_56_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_56_xt_invalid
cmp r6 128
jge x01_56_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_56_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_56_xt_invalid
add r0 1
cmp r0 96
jlt x01_56_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_56_xt_copy
cmp r0 r12
jge x01_56_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_56_xt_copy
label x01_56_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_56_xt_clean
set r0 16
label x01_56_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_56_xt_clean_mailbox
set r0 256
label x01_56_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_56_xt_clean_scratch
jmp x01_lesson_57
label x01_56_xt_invalid
div r0 0

label x01_56_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_56_xtn_done
cmp r9 255
jgt x01_56_xtn_done
label x01_56_xtn_each
cmp r0 r9
jge x01_56_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_56_xtn_inverted
cmp r3 195
je x01_56_xtn_accent
cmp r3 226
je x01_56_xtn_unicode_space
cmp r3 32
je x01_56_xtn_space
cmp r3 44
je x01_56_xtn_space
cmp r3 46
je x01_56_xtn_space
cmp r3 33
je x01_56_xtn_space
cmp r3 63
je x01_56_xtn_space
cmp r3 65
jlt x01_56_xtn_ascii
cmp r3 90
jgt x01_56_xtn_ascii
add r3 32
label x01_56_xtn_ascii
cmp r3 97
jlt x01_56_xtn_digit
cmp r3 122
jle x01_56_xtn_append
label x01_56_xtn_digit
cmp r3 48
jlt x01_56_xtn_done
cmp r3 57
jgt x01_56_xtn_done
jmp x01_56_xtn_append
label x01_56_xtn_inverted
add r0 1
cmp r0 r9
jge x01_56_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_56_xtn_space
cmp r3 191
je x01_56_xtn_space
cmp r3 161
je x01_56_xtn_space
jmp x01_56_xtn_done
label x01_56_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_56_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_56_xtn_done
add r0 1
cmp r0 r9
jge x01_56_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_56_xtn_space
cmp r3 175
je x01_56_xtn_space
jmp x01_56_xtn_done
label x01_56_xtn_accent
add r0 1
cmp r0 r9
jge x01_56_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_56_xtn_a
cmp r3 161
je x01_56_xtn_a
cmp r3 137
je x01_56_xtn_e
cmp r3 169
je x01_56_xtn_e
cmp r3 141
je x01_56_xtn_i
cmp r3 173
je x01_56_xtn_i
cmp r3 147
je x01_56_xtn_o
cmp r3 179
je x01_56_xtn_o
cmp r3 154
je x01_56_xtn_u
cmp r3 186
je x01_56_xtn_u
cmp r3 145
je x01_56_xtn_n
cmp r3 177
je x01_56_xtn_n
jmp x01_56_xtn_done
label x01_56_xtn_a
set r3 97
jmp x01_56_xtn_append
label x01_56_xtn_e
set r3 101
jmp x01_56_xtn_append
label x01_56_xtn_i
set r3 105
jmp x01_56_xtn_append
label x01_56_xtn_o
set r3 111
jmp x01_56_xtn_append
label x01_56_xtn_u
set r3 117
jmp x01_56_xtn_append
label x01_56_xtn_n
set r3 110
jmp x01_56_xtn_append
label x01_56_xtn_space
cmp r1 0
je x01_56_xtn_next
set r2 1
jmp x01_56_xtn_next
label x01_56_xtn_append
cmp r2 0
je x01_56_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_56_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_56_xtn_next
add r0 1
jmp x01_56_xtn_each
label x01_56_xtn_valid
cmp r1 0
je x01_56_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_56_xtn_done
jmp x01_56_xt_normalized

label x01_lesson_57
store8 9050000000000000016 3
store8 9050000000000000017 0
store8 9050000000000000018 0
store8 9050000000000000019 6
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 106
store8 9050000000000000273 97
store8 9050000000000000274 106
store8 9050000000000000275 97
store8 9050000000000000276 106
store8 9050000000000000277 97
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_57_xt_blank
cmp r0 88
jne x01_57_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_57_xt_invalid
jmp x01_57_xt_validate
label x01_57_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_57_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_57_xt_invalid
add r0 1
cmp r0 16
jlt x01_57_xt_blank_header
set r0 32
label x01_57_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_57_xt_invalid
add r0 1
cmp r0 144
jlt x01_57_xt_blank_context
set r0 4096
label x01_57_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_57_xt_invalid
add r0 1
cmp r0 16384
jlt x01_57_xt_blank_bank
label x01_57_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_57_xt_invalid
cmp r0 0
je x01_57_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_57_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_57_xt_invalid
cmp r0 17
jgt x01_57_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_57_xt_invalid
label x01_57_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_57_xt_invalid
cmp r0 4
jgt x01_57_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_57_xt_invalid
cmp r0 1
jne x01_57_xt_modifier
cmp r1 1
jlt x01_57_xt_invalid
cmp r1 17
jgt x01_57_xt_invalid
jmp x01_57_xt_prepare
label x01_57_xt_modifier
cmp r1 0
jne x01_57_xt_invalid
cmp r2 0
jne x01_57_xt_invalid
label x01_57_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_57_xtn_begin
label x01_57_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_57_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_57_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_57_xt_invalid
set r10 0
label x01_57_xt_lookup
cmp r10 r6
jge x01_57_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_57_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_57_xt_next
set r0 0
label x01_57_xt_compare
cmp r0 r12
jge x01_57_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_57_xt_next
add r0 1
jmp x01_57_xt_compare
label x01_57_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_57_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_57_xt_correct
jmp x01_57_xt_clean
label x01_57_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_57_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_57_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_57_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_57_xt_clean
label x01_57_xt_next
add r10 1
jmp x01_57_xt_lookup
label x01_57_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_57_xt_invalid
cmp r6 128
jge x01_57_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_57_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_57_xt_invalid
add r0 1
cmp r0 96
jlt x01_57_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_57_xt_copy
cmp r0 r12
jge x01_57_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_57_xt_copy
label x01_57_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_57_xt_clean
set r0 16
label x01_57_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_57_xt_clean_mailbox
set r0 256
label x01_57_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_57_xt_clean_scratch
jmp x01_lesson_58
label x01_57_xt_invalid
div r0 0

label x01_57_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_57_xtn_done
cmp r9 255
jgt x01_57_xtn_done
label x01_57_xtn_each
cmp r0 r9
jge x01_57_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_57_xtn_inverted
cmp r3 195
je x01_57_xtn_accent
cmp r3 226
je x01_57_xtn_unicode_space
cmp r3 32
je x01_57_xtn_space
cmp r3 44
je x01_57_xtn_space
cmp r3 46
je x01_57_xtn_space
cmp r3 33
je x01_57_xtn_space
cmp r3 63
je x01_57_xtn_space
cmp r3 65
jlt x01_57_xtn_ascii
cmp r3 90
jgt x01_57_xtn_ascii
add r3 32
label x01_57_xtn_ascii
cmp r3 97
jlt x01_57_xtn_digit
cmp r3 122
jle x01_57_xtn_append
label x01_57_xtn_digit
cmp r3 48
jlt x01_57_xtn_done
cmp r3 57
jgt x01_57_xtn_done
jmp x01_57_xtn_append
label x01_57_xtn_inverted
add r0 1
cmp r0 r9
jge x01_57_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_57_xtn_space
cmp r3 191
je x01_57_xtn_space
cmp r3 161
je x01_57_xtn_space
jmp x01_57_xtn_done
label x01_57_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_57_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_57_xtn_done
add r0 1
cmp r0 r9
jge x01_57_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_57_xtn_space
cmp r3 175
je x01_57_xtn_space
jmp x01_57_xtn_done
label x01_57_xtn_accent
add r0 1
cmp r0 r9
jge x01_57_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_57_xtn_a
cmp r3 161
je x01_57_xtn_a
cmp r3 137
je x01_57_xtn_e
cmp r3 169
je x01_57_xtn_e
cmp r3 141
je x01_57_xtn_i
cmp r3 173
je x01_57_xtn_i
cmp r3 147
je x01_57_xtn_o
cmp r3 179
je x01_57_xtn_o
cmp r3 154
je x01_57_xtn_u
cmp r3 186
je x01_57_xtn_u
cmp r3 145
je x01_57_xtn_n
cmp r3 177
je x01_57_xtn_n
jmp x01_57_xtn_done
label x01_57_xtn_a
set r3 97
jmp x01_57_xtn_append
label x01_57_xtn_e
set r3 101
jmp x01_57_xtn_append
label x01_57_xtn_i
set r3 105
jmp x01_57_xtn_append
label x01_57_xtn_o
set r3 111
jmp x01_57_xtn_append
label x01_57_xtn_u
set r3 117
jmp x01_57_xtn_append
label x01_57_xtn_n
set r3 110
jmp x01_57_xtn_append
label x01_57_xtn_space
cmp r1 0
je x01_57_xtn_next
set r2 1
jmp x01_57_xtn_next
label x01_57_xtn_append
cmp r2 0
je x01_57_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_57_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_57_xtn_next
add r0 1
jmp x01_57_xtn_each
label x01_57_xtn_valid
cmp r1 0
je x01_57_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_57_xtn_done
jmp x01_57_xt_normalized

label x01_lesson_58
store8 9050000000000000016 3
store8 9050000000000000017 0
store8 9050000000000000018 0
store8 9050000000000000019 7
store8 9050000000000000020 0
store8 9050000000000000021 0
store8 9050000000000000022 0
store8 9050000000000000272 115
store8 9050000000000000273 111
store8 9050000000000000274 108
store8 9050000000000000275 100
store8 9050000000000000276 97
store8 9050000000000000277 100
store8 9050000000000000278 111
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je x01_58_xt_blank
cmp r0 88
jne x01_58_xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne x01_58_xt_invalid
jmp x01_58_xt_validate
label x01_58_xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label x01_58_xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_58_xt_invalid
add r0 1
cmp r0 16
jlt x01_58_xt_blank_header
set r0 32
label x01_58_xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_58_xt_invalid
add r0 1
cmp r0 144
jlt x01_58_xt_blank_context
set r0 4096
label x01_58_xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_58_xt_invalid
add r0 1
cmp r0 16384
jlt x01_58_xt_blank_bank
label x01_58_xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt x01_58_xt_invalid
cmp r0 0
je x01_58_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne x01_58_xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt x01_58_xt_invalid
cmp r0 17
jgt x01_58_xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt x01_58_xt_invalid
label x01_58_xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt x01_58_xt_invalid
cmp r0 4
jgt x01_58_xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt x01_58_xt_invalid
cmp r0 1
jne x01_58_xt_modifier
cmp r1 1
jlt x01_58_xt_invalid
cmp r1 17
jgt x01_58_xt_invalid
jmp x01_58_xt_prepare
label x01_58_xt_modifier
cmp r1 0
jne x01_58_xt_invalid
cmp r2 0
jne x01_58_xt_invalid
label x01_58_xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp x01_58_xtn_begin
label x01_58_xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne x01_58_xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt x01_58_xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt x01_58_xt_invalid
set r10 0
label x01_58_xt_lookup
cmp r10 r6
jge x01_58_xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne x01_58_xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne x01_58_xt_next
set r0 0
label x01_58_xt_compare
cmp r0 r12
jge x01_58_xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne x01_58_xt_next
add r0 1
jmp x01_58_xt_compare
label x01_58_xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne x01_58_xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne x01_58_xt_correct
jmp x01_58_xt_clean
label x01_58_xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne x01_58_xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne x01_58_xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne x01_58_xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp x01_58_xt_clean
label x01_58_xt_next
add r10 1
jmp x01_58_xt_lookup
label x01_58_xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne x01_58_xt_invalid
cmp r6 128
jge x01_58_xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label x01_58_xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne x01_58_xt_invalid
add r0 1
cmp r0 96
jlt x01_58_xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label x01_58_xt_copy
cmp r0 r12
jge x01_58_xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp x01_58_xt_copy
label x01_58_xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label x01_58_xt_clean
set r0 16
label x01_58_xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt x01_58_xt_clean_mailbox
set r0 256
label x01_58_xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt x01_58_xt_clean_scratch
jmp x01_upgrade_done
label x01_58_xt_invalid
div r0 0

label x01_58_xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt x01_58_xtn_done
cmp r9 255
jgt x01_58_xtn_done
label x01_58_xtn_each
cmp r0 r9
jge x01_58_xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je x01_58_xtn_inverted
cmp r3 195
je x01_58_xtn_accent
cmp r3 226
je x01_58_xtn_unicode_space
cmp r3 32
je x01_58_xtn_space
cmp r3 44
je x01_58_xtn_space
cmp r3 46
je x01_58_xtn_space
cmp r3 33
je x01_58_xtn_space
cmp r3 63
je x01_58_xtn_space
cmp r3 65
jlt x01_58_xtn_ascii
cmp r3 90
jgt x01_58_xtn_ascii
add r3 32
label x01_58_xtn_ascii
cmp r3 97
jlt x01_58_xtn_digit
cmp r3 122
jle x01_58_xtn_append
label x01_58_xtn_digit
cmp r3 48
jlt x01_58_xtn_done
cmp r3 57
jgt x01_58_xtn_done
jmp x01_58_xtn_append
label x01_58_xtn_inverted
add r0 1
cmp r0 r9
jge x01_58_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je x01_58_xtn_space
cmp r3 191
je x01_58_xtn_space
cmp r3 161
je x01_58_xtn_space
jmp x01_58_xtn_done
label x01_58_xtn_unicode_space
add r0 1
cmp r0 r9
jge x01_58_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne x01_58_xtn_done
add r0 1
cmp r0 r9
jge x01_58_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je x01_58_xtn_space
cmp r3 175
je x01_58_xtn_space
jmp x01_58_xtn_done
label x01_58_xtn_accent
add r0 1
cmp r0 r9
jge x01_58_xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je x01_58_xtn_a
cmp r3 161
je x01_58_xtn_a
cmp r3 137
je x01_58_xtn_e
cmp r3 169
je x01_58_xtn_e
cmp r3 141
je x01_58_xtn_i
cmp r3 173
je x01_58_xtn_i
cmp r3 147
je x01_58_xtn_o
cmp r3 179
je x01_58_xtn_o
cmp r3 154
je x01_58_xtn_u
cmp r3 186
je x01_58_xtn_u
cmp r3 145
je x01_58_xtn_n
cmp r3 177
je x01_58_xtn_n
jmp x01_58_xtn_done
label x01_58_xtn_a
set r3 97
jmp x01_58_xtn_append
label x01_58_xtn_e
set r3 101
jmp x01_58_xtn_append
label x01_58_xtn_i
set r3 105
jmp x01_58_xtn_append
label x01_58_xtn_o
set r3 111
jmp x01_58_xtn_append
label x01_58_xtn_u
set r3 117
jmp x01_58_xtn_append
label x01_58_xtn_n
set r3 110
jmp x01_58_xtn_append
label x01_58_xtn_space
cmp r1 0
je x01_58_xtn_next
set r2 1
jmp x01_58_xtn_next
label x01_58_xtn_append
cmp r2 0
je x01_58_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label x01_58_xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label x01_58_xtn_next
add r0 1
jmp x01_58_xtn_each
label x01_58_xtn_valid
cmp r1 0
je x01_58_xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label x01_58_xtn_done
jmp x01_58_xt_normalized

label x01_upgrade_done
jmp x2up_finish

label x2up_finish
load8 r0 9060000000000000000
cmp r0 82
je x2up_halt
store8 9060000000000000000 82
store8 9060000000000000001 1
store8 9060000000000000002 2
store8 9060000000000000003 2
store8 9060000000000000064 1
store8 9060000000000000065 7
store8 9060000000000000066 1
store8 9060000000000000067 0
store8 9060000000000000069 2
store8 9060000000000004240 3
store8 9060000000000004241 1
store8 9060000000000004242 45
store8 9060000000000000072 99
store8 9060000000000000073 111
store8 9060000000000000074 108
store8 9060000000000000075 111
store8 9060000000000000076 114
store8 9060000000000000077 101
store8 9060000000000000078 115
store8 9060000000000004248 114
store8 9060000000000004249 111
store8 9060000000000004250 106
store8 9060000000000004251 111
store8 9060000000000004252 44
store8 9060000000000004253 32
store8 9060000000000004254 118
store8 9060000000000004255 101
store8 9060000000000004256 114
store8 9060000000000004257 100
store8 9060000000000004258 101
store8 9060000000000004259 44
store8 9060000000000004260 32
store8 9060000000000004261 97
store8 9060000000000004262 122
store8 9060000000000004263 117
store8 9060000000000004264 108
store8 9060000000000004265 44
store8 9060000000000004266 32
store8 9060000000000004267 97
store8 9060000000000004268 109
store8 9060000000000004269 97
store8 9060000000000004270 114
store8 9060000000000004271 105
store8 9060000000000004272 108
store8 9060000000000004273 108
store8 9060000000000004274 111
store8 9060000000000004275 44
store8 9060000000000004276 32
store8 9060000000000004277 118
store8 9060000000000004278 105
store8 9060000000000004279 111
store8 9060000000000004280 108
store8 9060000000000004281 101
store8 9060000000000004282 116
store8 9060000000000004283 97
store8 9060000000000004284 44
store8 9060000000000004285 32
store8 9060000000000004286 110
store8 9060000000000004287 97
store8 9060000000000004288 114
store8 9060000000000004289 97
store8 9060000000000004290 110
store8 9060000000000004291 106
store8 9060000000000004292 97
store8 9060000000000000128 1
store8 9060000000000000129 8
store8 9060000000000000130 2
store8 9060000000000000131 0
store8 9060000000000000133 2
store8 9060000000000004384 3
store8 9060000000000004385 2
store8 9060000000000004386 88
store8 9060000000000000136 118
store8 9060000000000000137 97
store8 9060000000000000138 114
store8 9060000000000000139 105
store8 9060000000000000140 97
store8 9060000000000000141 98
store8 9060000000000000142 108
store8 9060000000000000143 101
store8 9060000000000004392 85
store8 9060000000000004393 110
store8 9060000000000004394 97
store8 9060000000000004395 32
store8 9060000000000004396 118
store8 9060000000000004397 97
store8 9060000000000004398 114
store8 9060000000000004399 105
store8 9060000000000004400 97
store8 9060000000000004401 98
store8 9060000000000004402 108
store8 9060000000000004403 101
store8 9060000000000004404 32
store8 9060000000000004405 114
store8 9060000000000004406 101
store8 9060000000000004407 112
store8 9060000000000004408 114
store8 9060000000000004409 101
store8 9060000000000004410 115
store8 9060000000000004411 101
store8 9060000000000004412 110
store8 9060000000000004413 116
store8 9060000000000004414 97
store8 9060000000000004415 32
store8 9060000000000004416 117
store8 9060000000000004417 110
store8 9060000000000004418 32
store8 9060000000000004419 118
store8 9060000000000004420 97
store8 9060000000000004421 108
store8 9060000000000004422 111
store8 9060000000000004423 114
store8 9060000000000004424 32
store8 9060000000000004425 113
store8 9060000000000004426 117
store8 9060000000000004427 101
store8 9060000000000004428 32
store8 9060000000000004429 112
store8 9060000000000004430 117
store8 9060000000000004431 101
store8 9060000000000004432 100
store8 9060000000000004433 101
store8 9060000000000004434 32
store8 9060000000000004435 99
store8 9060000000000004436 97
store8 9060000000000004437 109
store8 9060000000000004438 98
store8 9060000000000004439 105
store8 9060000000000004440 97
store8 9060000000000004441 114
store8 9060000000000004442 32
store8 9060000000000004443 100
store8 9060000000000004444 117
store8 9060000000000004445 114
store8 9060000000000004446 97
store8 9060000000000004447 110
store8 9060000000000004448 116
store8 9060000000000004449 101
store8 9060000000000004450 32
store8 9060000000000004451 108
store8 9060000000000004452 97
store8 9060000000000004453 32
store8 9060000000000004454 101
store8 9060000000000004455 106
store8 9060000000000004456 101
store8 9060000000000004457 99
store8 9060000000000004458 117
store8 9060000000000004459 99
store8 9060000000000004460 105
store8 9060000000000004461 195
store8 9060000000000004462 179
store8 9060000000000004463 110
store8 9060000000000004464 32
store8 9060000000000004465 100
store8 9060000000000004466 101
store8 9060000000000004467 32
store8 9060000000000004468 117
store8 9060000000000004469 110
store8 9060000000000004470 32
store8 9060000000000004471 112
store8 9060000000000004472 114
store8 9060000000000004473 111
store8 9060000000000004474 103
store8 9060000000000004475 114
store8 9060000000000004476 97
store8 9060000000000004477 109
store8 9060000000000004478 97
store8 9060000000000004479 46
label x2up_halt
halt
