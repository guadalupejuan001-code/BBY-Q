#!reverse-pc-machine-v1
# Explicit supervised teaching. No implicit learning from ordinary conversation.
# P=9050000000000000000. Bank at +4096, 128 records of 96 bytes.
# Teacher: +16 kind1phrase/2prefix/3suffix/4both,+17 intent1..17,
# +18 needs-context boolean,+19 raw length,+272 raw bytes.
# +20 correction mode0/1,+21 expected old intent,+22 expected old context.
# Record: kind,intent,context,reserved,length,+5 normalized phrase(max80).
# Scratch and teacher mailbox are cleared after successful teaching.
load8 r0 9050000000000000000
cmp r0 0
je xt_blank
cmp r0 88
jne xt_invalid
load8 r0 9050000000000000001
cmp r0 1
jne xt_invalid
jmp xt_validate
label xt_blank
# No pre-existing state may be overwritten by initialization.
set r0 0
label xt_blank_header
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne xt_invalid
add r0 1
cmp r0 16
jlt xt_blank_header
set r0 32
label xt_blank_context
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne xt_invalid
add r0 1
cmp r0 144
jlt xt_blank_context
set r0 4096
label xt_blank_bank
set r7 9050000000000000000
add r7 r0
load8 r3 $r7
cmp r3 0
jne xt_invalid
add r0 1
cmp r0 16384
jlt xt_blank_bank
label xt_validate
load8 r0 9050000000000000020
cmp r0 1
jgt xt_invalid
cmp r0 0
je xt_fields
load8 r0 9050000000000000016
cmp r0 1
jne xt_invalid
load8 r0 9050000000000000021
cmp r0 1
jlt xt_invalid
cmp r0 17
jgt xt_invalid
load8 r0 9050000000000000022
cmp r0 1
jgt xt_invalid
label xt_fields
load8 r0 9050000000000000016
cmp r0 1
jlt xt_invalid
cmp r0 4
jgt xt_invalid
load8 r1 9050000000000000017
load8 r2 9050000000000000018
cmp r2 1
jgt xt_invalid
cmp r0 1
jne xt_modifier
cmp r1 1
jlt xt_invalid
cmp r1 17
jgt xt_invalid
jmp xt_prepare
label xt_modifier
cmp r1 0
jne xt_invalid
cmp r2 0
jne xt_invalid
label xt_prepare
set r8 9050000000000000272
load8 r9 9050000000000000019
jmp xtn_begin
label xt_normalized
load8 r0 9050000000000000257
cmp r0 1
jne xt_invalid
load8 r12 9050000000000000256
cmp r12 80
jgt xt_invalid
load8 r6 9050000000000000002
cmp r6 128
jgt xt_invalid
set r10 0
label xt_lookup
cmp r10 r6
jge xt_allocate
set r15 9050000000000004096
mov r7 r10
mul r7 96
add r15 r7
load8 r3 $r15
load8 r4 9050000000000000016
cmp r3 r4
jne xt_next
mov r7 r15
add r7 4
load8 r3 $r7
cmp r3 r12
jne xt_next
set r0 0
label xt_compare
cmp r0 r12
jge xt_duplicate
mov r7 r15
add r7 5
add r7 r0
load8 r3 $r7
set r7 9050000000000000528
add r7 r0
load8 r4 $r7
cmp r3 r4
jne xt_next
add r0 1
jmp xt_compare
label xt_duplicate
# A contradictory lesson fails atomically; it never silently changes meaning.
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000017
cmp r3 r4
jne xt_correct
add r7 1
load8 r3 $r7
load8 r4 9050000000000000018
cmp r3 r4
jne xt_correct
jmp xt_clean
label xt_correct
# Corrections require an explicit old-label lease supplied by a teacher.
load8 r0 9050000000000000020
cmp r0 1
jne xt_invalid
mov r7 r15
add r7 1
load8 r3 $r7
load8 r4 9050000000000000021
cmp r3 r4
jne xt_invalid
add r7 1
load8 r3 $r7
load8 r4 9050000000000000022
cmp r3 r4
jne xt_invalid
load8 r3 9050000000000000018
store8 $r7 r3
sub r7 1
load8 r3 9050000000000000017
store8 $r7 r3
jmp xt_clean
label xt_next
add r10 1
jmp xt_lookup
label xt_allocate
load8 r0 9050000000000000020
cmp r0 0
jne xt_invalid
cmp r6 128
jge xt_invalid
set r15 9050000000000004096
mov r7 r6
mul r7 96
add r15 r7
# Check the complete unallocated record before any persistent write.
set r0 0
label xt_free
mov r7 r15
add r7 r0
load8 r3 $r7
cmp r3 0
jne xt_invalid
add r0 1
cmp r0 96
jlt xt_free
load8 r3 9050000000000000016
store8 $r15 r3
mov r7 r15
add r7 1
load8 r3 9050000000000000017
store8 $r7 r3
add r7 1
load8 r3 9050000000000000018
store8 $r7 r3
add r7 2
store8 $r7 r12
set r0 0
label xt_copy
cmp r0 r12
jge xt_publish
set r7 9050000000000000528
add r7 r0
load8 r3 $r7
mov r7 r15
add r7 5
add r7 r0
store8 $r7 r3
add r0 1
jmp xt_copy
label xt_publish
add r6 1
store8 9050000000000000002 r6
store8 9050000000000000000 88
store8 9050000000000000001 1
label xt_clean
set r0 16
label xt_clean_mailbox
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 32
jlt xt_clean_mailbox
set r0 256
label xt_clean_scratch
set r7 9050000000000000000
add r7 r0
store8 $r7 0
add r0 1
cmp r0 1024
jlt xt_clean_scratch
halt
label xt_invalid
div r0 0

label xtn_begin
# Native normalization shared by teaching and inference. r8 raw base, r9 length.
# Output P+528, length P+256, valid P+257. Keeps negation and word order.
# U+00A0, U+2007 and U+202F are word separators, like ASCII space.
# Quotes, slashes, semicolons and other unknown UTF-8 decline matching.
set r0 0
set r1 0
set r2 0
store8 9050000000000000257 0
cmp r9 1
jlt xtn_done
cmp r9 255
jgt xtn_done
label xtn_each
cmp r0 r9
jge xtn_valid
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 194
je xtn_inverted
cmp r3 195
je xtn_accent
cmp r3 226
je xtn_unicode_space
cmp r3 32
je xtn_space
cmp r3 44
je xtn_space
cmp r3 46
je xtn_space
cmp r3 33
je xtn_space
cmp r3 63
je xtn_space
cmp r3 65
jlt xtn_ascii
cmp r3 90
jgt xtn_ascii
add r3 32
label xtn_ascii
cmp r3 97
jlt xtn_digit
cmp r3 122
jle xtn_append
label xtn_digit
cmp r3 48
jlt xtn_done
cmp r3 57
jgt xtn_done
jmp xtn_append
label xtn_inverted
add r0 1
cmp r0 r9
jge xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 160
je xtn_space
cmp r3 191
je xtn_space
cmp r3 161
je xtn_space
jmp xtn_done
label xtn_unicode_space
add r0 1
cmp r0 r9
jge xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 128
jne xtn_done
add r0 1
cmp r0 r9
jge xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 135
je xtn_space
cmp r3 175
je xtn_space
jmp xtn_done
label xtn_accent
add r0 1
cmp r0 r9
jge xtn_done
mov r7 r8
add r7 r0
load8 r3 $r7
cmp r3 129
je xtn_a
cmp r3 161
je xtn_a
cmp r3 137
je xtn_e
cmp r3 169
je xtn_e
cmp r3 141
je xtn_i
cmp r3 173
je xtn_i
cmp r3 147
je xtn_o
cmp r3 179
je xtn_o
cmp r3 154
je xtn_u
cmp r3 186
je xtn_u
cmp r3 145
je xtn_n
cmp r3 177
je xtn_n
jmp xtn_done
label xtn_a
set r3 97
jmp xtn_append
label xtn_e
set r3 101
jmp xtn_append
label xtn_i
set r3 105
jmp xtn_append
label xtn_o
set r3 111
jmp xtn_append
label xtn_u
set r3 117
jmp xtn_append
label xtn_n
set r3 110
jmp xtn_append
label xtn_space
cmp r1 0
je xtn_next
set r2 1
jmp xtn_next
label xtn_append
cmp r2 0
je xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 32
add r1 1
set r2 0
label xtn_letter
set r7 9050000000000000528
add r7 r1
store8 $r7 r3
add r1 1
label xtn_next
add r0 1
jmp xtn_each
label xtn_valid
cmp r1 0
je xtn_done
store8 9050000000000000256 r1
store8 9050000000000000257 1
label xtn_done
jmp xt_normalized
