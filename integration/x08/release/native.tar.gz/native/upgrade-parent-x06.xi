#!reverse-pc-machine-v1
load8 r0 9100000000000000000
cmp r0 0
je x6up_empty
cmp r0 86
jne x6up_refuse
load8 r0 9100000000000000001
cmp r0 1
jne x6up_refuse
load8 r0 9100000000000000002
cmp r0 1
jgt x6up_refuse
jmp x6up_scratch
label x6up_empty
set r7 9100000000000000000
set r0 8192
label x6up_plan_scan
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
sub r0 16
cmp r0 0
jgt x6up_plan_scan
set r0 8192
sub r7 1
label x6up_scratch
set r7 9100000000000100000
set r0 4096
label x6up_scratch_scan
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
sub r0 16
cmp r0 0
jgt x6up_scratch_scan
set r0 4096
sub r7 1
set r7 9100000000000120000
set r0 8192
label x6up_work_scan
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
sub r0 16
cmp r0 0
jgt x6up_work_scan
set r0 8192
sub r7 1
load8 r0 9100000000000200000
cmp r0 0
je x6up_empty_frame
cmp r0 86
jne x6up_refuse
load8 r0 9100000000000200001
cmp r0 2
jne x6up_refuse
set r7 9100000000000200002
set r0 16624
label x6up_frame_scan
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
sub r0 16
cmp r0 0
jgt x6up_frame_scan
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
set r0 16638
sub r7 1
jmp x6up_ok
label x6up_empty_frame
set r7 9100000000000200000
set r0 16640
label x6up_empty_frame_scan
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x6up_refuse
add r7 1
sub r0 16
cmp r0 0
jgt x6up_empty_frame_scan
set r0 16640
sub r7 1
label x6up_ok
jmp x6up_upgrade
label x6up_refuse
set r0 0
mod r0 0

label x6up_upgrade
load8 r0 9090000000000000000
cmp r0 85
jne x6up_refuse
load8 r0 9090000000000000001
cmp r0 1
jne x6up_refuse
load8 r0 9090000000000000000
cmp r0 0
je x5up_empty
cmp r0 85
jne x5up_refuse
load8 r0 9090000000000000001
cmp r0 1
jne x5up_refuse
load8 r0 9090000000000000002
cmp r0 5
jgt x5up_refuse
jmp x5up_scratch
label x5up_empty
set r7 9090000000000000000
set r0 8192
label x5up_scan
load8 r3 $r7
cmp r3 0
jne x5up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x5up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x5up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x5up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x5up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x5up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x5up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x5up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x5up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x5up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x5up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x5up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x5up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x5up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x5up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x5up_refuse
add r7 1
sub r0 16
cmp r0 0
jgt x5up_scan
set r0 8192
sub r7 1
label x5up_scratch
set r7 9090000000000100000
set r0 8192
label x5up_scratch_scan
load8 r3 $r7
cmp r3 0
jne x5up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x5up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x5up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x5up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x5up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x5up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x5up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x5up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x5up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x5up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x5up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x5up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x5up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x5up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x5up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x5up_refuse
add r7 1
sub r0 16
cmp r0 0
jgt x5up_scratch_scan
set r0 8192
sub r7 1
jmp x5up_prior_guard
label x5up_refuse
set r0 0
mod r0 0

label x5up_prior_guard
load8 r0 9080000000000000000
cmp r0 0
je x4up_empty
cmp r0 84
jne x4up_refuse
load8 r0 9080000000000000001
cmp r0 1
jne x4up_refuse
load8 r0 9080000000000000002
cmp r0 24
jgt x4up_refuse
load8 r0 9080000000000000003
cmp r0 64
jgt x4up_refuse
jmp x4up_scratch
label x4up_empty
set r7 9080000000000000000
set r0 2048
label x4up_scan
load8 r3 $r7
cmp r3 0
jne x4up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x4up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x4up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x4up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x4up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x4up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x4up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x4up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x4up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x4up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x4up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x4up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x4up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x4up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x4up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x4up_refuse
add r7 1
sub r0 16
cmp r0 0
jgt x4up_scan
set r0 2048
sub r7 1
label x4up_scratch
set r7 9080000000000100000
set r0 12288
label x4up_scratch_scan
load8 r3 $r7
cmp r3 0
jne x4up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x4up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x4up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x4up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x4up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x4up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x4up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x4up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x4up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x4up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x4up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x4up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x4up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x4up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x4up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x4up_refuse
add r7 1
sub r0 16
cmp r0 0
jgt x4up_scratch_scan
set r0 12288
sub r7 1
jmp x4up_prior_guard
label x4up_refuse
set r0 0
mod r0 0

label x4up_prior_guard
load8 r0 9070000000000000000
cmp r0 0
je x3up_empty
cmp r0 83
jne x3up_refuse
load8 r0 9070000000000000001
cmp r0 1
jne x3up_refuse
load8 r0 9070000000000000002
cmp r0 128
jgt x3up_refuse
load8 r0 9070000000000000012
cmp r0 16
jgt x3up_refuse
jmp x3up_scratch
label x3up_empty
set r7 9070000000000000000
set r0 32768
label x3up_scan
load8 r3 $r7
cmp r3 0
jne x3up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x3up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x3up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x3up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x3up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x3up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x3up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x3up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x3up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x3up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x3up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x3up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x3up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x3up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x3up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x3up_refuse
add r7 1
sub r0 16
cmp r0 0
jgt x3up_scan
set r0 32768
sub r7 1
label x3up_scratch
set r7 9070000000000100000
set r0 1024
label x3up_scratch_scan
load8 r3 $r7
cmp r3 0
jne x3up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x3up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x3up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x3up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x3up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x3up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x3up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x3up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x3up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x3up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x3up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x3up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x3up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x3up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x3up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x3up_refuse
add r7 1
sub r0 16
cmp r0 0
jgt x3up_scratch_scan
set r0 1024
sub r7 1
jmp x3up_prior_guard
label x3up_refuse
set r0 0
mod r0 0

label x3up_prior_guard
load8 r0 9060000000000000000
cmp r0 0
je x2up_unowned
cmp r0 82
jne x2up_refuse
load8 r0 9060000000000000001
cmp r0 1
jne x2up_refuse
load8 r0 9060000000000000002
cmp r0 32
jgt x2up_refuse
load8 r0 9060000000000000003
cmp r0 128
jgt x2up_refuse
jmp x2up_scratch
label x2up_unowned
set r7 9060000000000000000
set r0 24576
label x2up_bank_scan
load8 r3 $r7
cmp r3 0
jne x2up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x2up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x2up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x2up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x2up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x2up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x2up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x2up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x2up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x2up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x2up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x2up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x2up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x2up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x2up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x2up_refuse
add r7 1
sub r0 16
cmp r0 0
jgt x2up_bank_scan
set r0 24576
sub r7 1
label x2up_scratch
set r7 9060000000000100000
set r0 2048
label x2up_scratch_scan
load8 r3 $r7
cmp r3 0
jne x2up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x2up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x2up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x2up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x2up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x2up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x2up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x2up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x2up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x2up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x2up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x2up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x2up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x2up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x2up_refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne x2up_refuse
add r7 1
sub r0 16
cmp r0 0
jgt x2up_scratch_scan
set r0 2048
sub r7 1
jmp x2up_prior_guard
label x2up_refuse
set r0 0
mod r0 0

label x2up_prior_guard
# Read-only namespace ownership guard. Run BEFORE transporting any lesson.
load8 r0 9050000000000000000
cmp r0 0
je xg_empty
cmp r0 88
jne xg_invalid
load8 r0 9050000000000000001
cmp r0 1
jne xg_invalid
load8 r0 9050000000000000002
cmp r0 128
jgt xg_invalid
jmp x6up_finish
label xg_empty
set r7 9050000000000000000
set r0 16384
label xg_each
load8 r3 $r7
cmp r3 0
jne xg_invalid
add r7 1
load8 r3 $r7
cmp r3 0
jne xg_invalid
add r7 1
load8 r3 $r7
cmp r3 0
jne xg_invalid
add r7 1
load8 r3 $r7
cmp r3 0
jne xg_invalid
add r7 1
load8 r3 $r7
cmp r3 0
jne xg_invalid
add r7 1
load8 r3 $r7
cmp r3 0
jne xg_invalid
add r7 1
load8 r3 $r7
cmp r3 0
jne xg_invalid
add r7 1
load8 r3 $r7
cmp r3 0
jne xg_invalid
add r7 1
load8 r3 $r7
cmp r3 0
jne xg_invalid
add r7 1
load8 r3 $r7
cmp r3 0
jne xg_invalid
add r7 1
load8 r3 $r7
cmp r3 0
jne xg_invalid
add r7 1
load8 r3 $r7
cmp r3 0
jne xg_invalid
add r7 1
load8 r3 $r7
cmp r3 0
jne xg_invalid
add r7 1
load8 r3 $r7
cmp r3 0
jne xg_invalid
add r7 1
load8 r3 $r7
cmp r3 0
jne xg_invalid
add r7 1
load8 r3 $r7
cmp r3 0
jne xg_invalid
add r7 1
sub r0 16
cmp r0 0
jgt xg_each
set r0 16384
sub r7 1
jmp x6up_finish
label xg_invalid
div r0 0

label x6up_finish
store8 9100000000000000000 86
store8 9100000000000000001 1
store8 9100000000000200000 86
store8 9100000000000200001 2
halt
