#!reverse-pc-machine-v1
load8 r0 9110000000000000000
cmp r0 87
jne refuse
load8 r0 9110000000000000001
cmp r0 1
jne refuse
load8 r0 9110000000000000002
load8 r1 9110000000000000003
mul r1 256
add r0 r1
cmp r0 512
jgt refuse
set r7 9110000000000500000
set r0 8192
label scratch
load8 r3 $r7
cmp r3 0
jne refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne refuse
add r7 1
load8 r3 $r7
cmp r3 0
jne refuse
add r7 1
sub r0 16
cmp r0 0
jgt scratch
halt
label refuse
set r0 0
mod r0 0
